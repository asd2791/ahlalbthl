/*    */ package Setings;
/*    */ 
/*    */ import JointInfo.HeaderRenderer;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.DefaultTableCellRenderer;
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ import javax.swing.table.JTableHeader;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TablesSeting
/*    */ {
/*    */   public JTable ColomonSize(JTable table, int[] ColomonsSize) {
/* 16 */     for (int i = 0; i < ColomonsSize.length; i++) {
/* 17 */       table.getColumnModel().getColumn(i).setPreferredWidth(ColomonsSize[i]);
/*    */     }
/*    */     
/* 20 */     return table;
/*    */   }
/*    */   public DefaultTableModel ColomonName(JTable table, String[] ColomonsNames) {
/* 23 */     DefaultTableModel dtm = new DefaultTableModel();
/* 24 */     table.setModel(dtm);
/* 25 */     for (int i = 0; i < ColomonsNames.length; i++) {
/* 26 */       dtm.addColumn(ColomonsNames[i]);
/*    */     }
/* 28 */     return dtm;
/*    */   }
/*    */ 
/*    */   
/*    */   public static JTable CENTERRHaiderTable(JTable table) {
/* 33 */     JTableHeader header = table.getTableHeader();
/* 34 */     header.setDefaultRenderer((TableCellRenderer)new HeaderRenderer(table));
/* 35 */     return table;
/*    */   }
/*    */   
/*    */   public static JTable CENTERTableCorrect(JTable table) {
/* 39 */     DefaultTableCellRenderer CENTERRenderer = new DefaultTableCellRenderer();
/* 40 */     CENTERRenderer.setHorizontalAlignment(0);
/* 41 */     for (int i = 1; i < table.getColumnCount() - 1; i++) {
/* 42 */       table.getColumnModel().getColumn(i).setCellRenderer(CENTERRenderer);
/*    */     }
/*    */ 
/*    */     
/* 46 */     return table;
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\Setings\TablesSeting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */