/*     */ package Main;
/*     */ 
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ public class Ahl_Albthl extends JFrame {
/*     */   private JButton jButton1;
/*     */   private JButton jButton2;
/*     */   private JButton jButton3;
/*     */   
/*     */   public Ahl_Albthl() {
/*  22 */     initComponents();
/*  23 */     setLocationRelativeTo(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setUIFont(Font f) {
/*  28 */     Enumeration keys = UIManager.getDefaults().keys();
/*  29 */     while (keys.hasMoreElements()) {
/*  30 */       Object key = keys.nextElement();
/*  31 */       Object value = UIManager.get(key);
/*  32 */       if (value != null && value instanceof javax.swing.plaf.FontUIResource) {
/*  33 */         UIManager.put(key, f);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  45 */     this.jButton1 = new JButton();
/*  46 */     this.jButton2 = new JButton();
/*  47 */     this.jButton3 = new JButton();
/*     */     
/*  49 */     setDefaultCloseOperation(3);
/*     */     
/*  51 */     this.jButton1.setText("البرامج الإنسانية");
/*  52 */     this.jButton1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  54 */             Ahl_Albthl.this.jButton1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  58 */     this.jButton2.setText("المشاريع الهندسية");
/*  59 */     this.jButton2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  61 */             Ahl_Albthl.this.jButton2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  65 */     this.jButton3.setText("إعدادت عامة");
/*  66 */     this.jButton3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  68 */             Ahl_Albthl.this.jButton3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  72 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  73 */     getContentPane().setLayout(layout);
/*  74 */     layout.setHorizontalGroup(layout
/*  75 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  76 */         .addGroup(layout.createSequentialGroup()
/*  77 */           .addContainerGap(253, 32767)
/*  78 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/*  79 */             .addComponent(this.jButton1, GroupLayout.Alignment.TRAILING, -1, -1, 32767)
/*  80 */             .addComponent(this.jButton2, GroupLayout.Alignment.TRAILING, -1, 192, 32767)
/*  81 */             .addComponent(this.jButton3, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/*  82 */           .addContainerGap()));
/*     */     
/*  84 */     layout.setVerticalGroup(layout
/*  85 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  86 */         .addGroup(layout.createSequentialGroup()
/*  87 */           .addGap(73, 73, 73)
/*  88 */           .addComponent(this.jButton1, -2, 49, -2)
/*  89 */           .addGap(27, 27, 27)
/*  90 */           .addComponent(this.jButton2, -2, 49, -2)
/*  91 */           .addGap(27, 27, 27)
/*  92 */           .addComponent(this.jButton3, -2, 45, -2)
/*  93 */           .addContainerGap(30, 32767)));
/*     */ 
/*     */     
/*  96 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 101 */     (new HumanitarianMain()).setVisible(true);
/* 102 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 107 */     (new EngineeringMain()).setVisible(true);
/* 108 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jButton3ActionPerformed(ActionEvent evt) {
/* 113 */     (new SetingsMain()).setVisible(true);
/* 114 */     dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 123 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 124 */         if ("Nimbus".equals(info.getName())) {
/* 125 */           UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*     */           break;
/*     */         } 
/*     */       } 
/* 129 */     } catch (ClassNotFoundException ex) {
/* 130 */       Logger.getLogger(Ahl_Albthl.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 131 */     } catch (InstantiationException ex) {
/* 132 */       Logger.getLogger(Ahl_Albthl.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 133 */     } catch (IllegalAccessException ex) {
/* 134 */       Logger.getLogger(Ahl_Albthl.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 135 */     } catch (UnsupportedLookAndFeelException ex) {
/* 136 */       Logger.getLogger(Ahl_Albthl.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 154 */             (new Ahl_Albthl()).setVisible(true);
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\Main\Ahl_Albthl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */