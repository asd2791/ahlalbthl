/*    */ package Main;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LanguageText
/*    */ {
/*    */   public static void setLanguage(String lang, JTextField txt) {
/* 14 */     Locale[] locales = Locale.getAvailableLocales();
/* 15 */     for (int i = 0; i < locales.length; i++) {
/* 16 */       Locale locale = locales[i];
/* 17 */       if (locale.getLanguage().equals(lang)) {
/* 18 */         txt.getInputContext().selectInputMethod(locale);
/*    */       
/*    */       }
/* 21 */       else if (locale.getLanguage().equals(lang)) {
/* 22 */         txt.getInputContext().selectInputMethod(locale);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\Main\LanguageText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */