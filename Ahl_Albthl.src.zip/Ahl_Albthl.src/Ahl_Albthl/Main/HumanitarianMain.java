/*     */ package Main;
/*     */ 
/*     */ import GUEs.GUEDisabled;
/*     */ import GUEs.GUEOrphans;
/*     */ import GUEs.GUEPoor;
/*     */ import GUEs.GUEWidows;
/*     */ import GUEs.OverallReports;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ 
/*     */ public class HumanitarianMain extends JFrame {
/*     */   private JButton jButton1;
/*     */   
/*     */   public HumanitarianMain() {
/*  27 */     initComponents();
/*  28 */     setLocationRelativeTo(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private JButton jButton2;
/*     */   
/*     */   private JButton jButton3;
/*     */   private JButton jButton4;
/*     */   private JButton jButton5;
/*     */   private JLabel jLabel1;
/*     */   
/*     */   private void initComponents() {
/*  40 */     this.jButton1 = new JButton();
/*  41 */     this.jButton2 = new JButton();
/*  42 */     this.jButton3 = new JButton();
/*  43 */     this.jButton4 = new JButton();
/*  44 */     this.jLabel1 = new JLabel();
/*  45 */     this.jButton5 = new JButton();
/*     */     
/*  47 */     setDefaultCloseOperation(3);
/*  48 */     setIconImage(getToolkit().getImage(getClass().getResource("/images/logo-.png")));
/*     */     
/*  50 */     this.jButton1.setIcon(new ImageIcon(getClass().getResource("/images/tag_orange.png")));
/*  51 */     this.jButton1.setText("الأيتام");
/*  52 */     this.jButton1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  54 */             HumanitarianMain.this.jButton1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  58 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/images/tag_violet.png")));
/*  59 */     this.jButton2.setText("الأرامل");
/*  60 */     this.jButton2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  62 */             HumanitarianMain.this.jButton2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  66 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/images/tag_blue.png")));
/*  67 */     this.jButton3.setText("الفقراء والمساكين");
/*  68 */     this.jButton3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  70 */             HumanitarianMain.this.jButton3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  74 */     this.jButton4.setIcon(new ImageIcon(getClass().getResource("/images/tag_green.png")));
/*  75 */     this.jButton4.setText("المعاقين");
/*  76 */     this.jButton4.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  78 */             HumanitarianMain.this.jButton4ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  82 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/images/logo-.png")));
/*     */     
/*  84 */     this.jButton5.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/*  85 */     this.jButton5.setText("التقارير العامة");
/*  86 */     this.jButton5.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  88 */             HumanitarianMain.this.jButton5ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  92 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  93 */     getContentPane().setLayout(layout);
/*  94 */     layout.setHorizontalGroup(layout
/*  95 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  96 */         .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/*  97 */           .addContainerGap()
/*  98 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  99 */             .addComponent(this.jButton4, -2, 174, -2)
/* 100 */             .addComponent(this.jButton3, -2, 174, -2))
/* 101 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767)
/* 102 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 103 */             .addGroup(layout.createSequentialGroup()
/* 104 */               .addGap(12, 12, 12)
/* 105 */               .addComponent(this.jButton5, -2, 259, -2))
/* 106 */             .addGroup(layout.createSequentialGroup()
/* 107 */               .addComponent(this.jLabel1)
/* 108 */               .addGap(18, 18, 18)
/* 109 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 110 */                 .addComponent(this.jButton1, -2, 174, -2)
/* 111 */                 .addComponent(this.jButton2, -2, 174, -2))))
/* 112 */           .addContainerGap()));
/*     */     
/* 114 */     layout.setVerticalGroup(layout
/* 115 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 116 */         .addGroup(layout.createSequentialGroup()
/* 117 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 118 */             .addGroup(layout.createSequentialGroup()
/* 119 */               .addGap(64, 64, 64)
/* 120 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 121 */                 .addComponent(this.jButton1, -2, 44, -2)
/* 122 */                 .addComponent(this.jButton4, -2, 44, -2))
/* 123 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 124 */                 .addGroup(layout.createSequentialGroup()
/* 125 */                   .addGap(89, 89, 89)
/* 126 */                   .addComponent(this.jButton2, -2, 44, -2))
/* 127 */                 .addGroup(layout.createSequentialGroup()
/* 128 */                   .addGap(88, 88, 88)
/* 129 */                   .addComponent(this.jButton3, -2, 44, -2))))
/* 130 */             .addGroup(layout.createSequentialGroup()
/* 131 */               .addGap(35, 35, 35)
/* 132 */               .addComponent(this.jLabel1)))
/* 133 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 134 */           .addComponent(this.jButton5, -2, 44, -2)
/* 135 */           .addContainerGap(32, 32767)));
/*     */ 
/*     */     
/* 138 */     pack();
/*     */   }
/*     */   
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 143 */       setCursor(new Cursor(3));
/* 144 */       (new GUEOrphans()).setVisible(true);
/* 145 */       dispose();
/*     */     } finally {
/* 147 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton4ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 153 */       setCursor(new Cursor(3));
/* 154 */       (new GUEDisabled()).setVisible(true);
/* 155 */       dispose();
/*     */     } finally {
/* 157 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 163 */       setCursor(new Cursor(3));
/* 164 */       (new GUEWidows()).setVisible(true);
/* 165 */       dispose();
/*     */     } finally {
/* 167 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton3ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 173 */       setCursor(new Cursor(3));
/* 174 */       (new GUEPoor()).setVisible(true);
/* 175 */       dispose();
/*     */     } finally {
/* 177 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton5ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 183 */       setCursor(new Cursor(3));
/* 184 */       (new OverallReports()).setVisible(true);
/* 185 */       dispose();
/*     */     } finally {
/* 187 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 196 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 197 */         if ("Nimbus".equals(info.getName())) {
/* 198 */           UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*     */           break;
/*     */         } 
/*     */       } 
/* 202 */     } catch (ClassNotFoundException ex) {
/* 203 */       Logger.getLogger(HumanitarianMain.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 204 */     } catch (InstantiationException ex) {
/* 205 */       Logger.getLogger(HumanitarianMain.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 206 */     } catch (IllegalAccessException ex) {
/* 207 */       Logger.getLogger(HumanitarianMain.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 208 */     } catch (UnsupportedLookAndFeelException ex) {
/* 209 */       Logger.getLogger(HumanitarianMain.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */     
/* 212 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 214 */             (new HumanitarianMain()).setVisible(true);
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\Main\HumanitarianMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */