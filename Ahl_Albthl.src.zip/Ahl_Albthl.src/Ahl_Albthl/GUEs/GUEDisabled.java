/*      */ package GUEs;
/*      */ import JointInfo.ChekCompletData;
/*      */ import JointInfo.InfoExpense;
/*      */ import JointInfo.InfoGrantees;
/*      */ import JointInfo.InfoPayment;
/*      */ import JointInfo.InfoSponsors;
/*      */ import JointInfo.MessageInfo;
/*      */ import Setings.TablesSeting;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.FocusAdapter;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Hashtable;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.swing.DefaultCellEditor;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import reportsengine.ReportsManager;
/*      */ 
/*      */ public class GUEDisabled extends JFrame {
/*   47 */   private InfoGrantees gran = new InfoGrantees();
/*   48 */   private InfoPayment pay = new InfoPayment();
/*   49 */   private InfoSponsors spo = new InfoSponsors();
/*   50 */   private InfoExpense expe1 = new InfoExpense();
/*      */   private ArrayList<InfoGrantees> grantee;
/*      */   private ArrayList<InfoSponsors> sponsors;
/*   53 */   private String[] ColomonsNames = new String[] { "حالة الأسرة", "عدد الأسرة", "رقم الحساب", "وسيلة الاتصال", "ولي الأمر", "المدينة", "تاريخ الميلاد", "رقم الهوية", "نوع الهوية", "الاسم", "الرقم" };
/*   54 */   private int[] ColomonsSize = new int[] { 60, 30, 10, 60, 30, 30, 30, 30, 60, 60, 20 };
/*   55 */   private String[] SerchAddColomonsNames = new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "إضافة كفيل", "اسم المعاق", "الرقم" };
/*   56 */   private String[] SerchAddColomonsNames2 = new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "إضافة كفيل", "عدد الأسرة", "حالة الأسرة", "اسم المعاق", "الرقم" };
/*   57 */   private String[] SerchChangColomonsNames = new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "تغيير الكفيل", "اسم المعاق", "الرقم" };
/*   58 */   private String[] ColomonsSponsorsPaymentNames = new String[] { "دفع مبلغ", "اسم المعاق", "رقم المعاق", "اسم الكفيل", "رقم الكفيل" };
/*   59 */   private String[] ColomonsGranteesExpenseNames = new String[] { "صرف مبلغ", "اسم الكفيل", "رقم الكفيل", "اسم المعاق", "رقم المعاق" };
/*   60 */   private String[] SerchStopColomonsNames = new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "إيقاف الكفالة", "اسم المعاق", "الرقم" };
/*   61 */   private String[] PaymentColomonsNames = new String[] { "طباعة", "تحرير", "تاريخ الدفع", "المبلغ", "اسم الكفيل", "الرقم" };
/*   62 */   private String[] ExpenseColomonsNames = new String[] { "طباعة", "تحرير", "تاريخ الصرف", "المبلغ المصروف", "اسم المستلم", "الرقم" };
/*   63 */   private String[] TablePaymentColomonsNames = new String[] { "طباعة فاتورة", "تحرير", "التاريخ", "المبلغ", "اسم الكفيل", "الرقم التسلسلي" };
/*   64 */   private String[] TableExpensesColomonsNames = new String[] { "طباعة فاتورة", "تحرير", "تاريخ الصرف", "المبلغ المصروف", "اسم المستلم", "الرقم" };
/*   65 */   private int[] PaymentColomonsSize = new int[] { 100, 60, 160, 60, 160, 20 };
/*   66 */   private int[] ExpenseColomonsSize = new int[] { 100, 60, 160, 60, 160, 20 };
/*   67 */   private int[] SerchColomonsSize = new int[] { 60, 160, 120, 160, 10 };
/*   68 */   private int[] SerchColomonsSize2 = new int[] { 60, 160, 120, 120, 160, 160, 30 };
/*   69 */   private int[] SponsorsPaymentSize = new int[] { 110, 160, 50, 160, 50 };
/*   70 */   private int[] SponsorsExpenseSize = new int[] { 110, 160, 50, 160, 50 };
/*   71 */   private Searching ser = new Searching();
/*   72 */   private String[] nColomnGrantees = new String[] { "GranteesName" };
/*   73 */   private String[] nColomnGrantees2 = new String[] { "GranteesName", "GranteeConnect", "RegestryID", "SponsorsName" };
/*   74 */   private String[] nColomnGrantees3 = new String[] { "GranteesName", "FamilyStuets" };
/*   75 */   private String nTableGrantees = "Grantees";
/*   76 */   private String[] nColomnSponsors = new String[] { "SponsorsName", "SponsorsConnect", "RegestryID", "GranteesName" };
/*   77 */   private String nTableSponsors = "Sponsors";
/*   78 */   private int WhatPress = 0;
/*   79 */   private final int PressSerch = 1;
/*   80 */   private final int PressAllVew = 2;
/*   81 */   private int sel = -1;
/*      */   private JTextField[] textsGranteeEdite;
/*      */   private JTextField[] textsAddSponsor;
/*      */   private JTextField[] textsChangeSponsor;
/*      */   private JTextField[] textsDeleteGrantee;
/*      */   private JTextField[] textsStopSponsor;
/*      */   private JTextField[] textsPayment;
/*      */   private JTextField[] textsExpenses;
/*   89 */   private Color MyYellow = new Color(255, 255, 153);
/*   90 */   private Color MyGray = new Color(204, 204, 204);
/*   91 */   private Color MyWhite = new Color(255, 255, 255); private JComboBox BoxFamilyStuts; private JComboBox BoxFamilyStutsEdit; private JComboBox BoxFamilyStutsSerch; private JComboBox BoxRegestreType; private JComboBox BoxRegestreTypeEdit; private JButton ButtonAddGrantee; private JButton ButtonAddGrantee2; private static JButton ButtonAddSponsor; private JButton ButtonEditGrantee; private static JButton ButtonExpensesSend; private JButton ButtonGranteeSerch; private JButton ButtonGranteeSerchDelete; private JButton ButtonGranteeSerchEdite; private JButton ButtonGranteeSerchStop; private static JButton ButtonPaymentSend; private JButton ButtonReport; private JButton ButtonReport1; private JButton ButtonSerchGE; private JButton ButtonSerchSP; private static JButton ButtonStopSponsor; private JButton ButtonViwoAdd; private JButton ButtonViwoDelet; private JButton ButtonViwoEdite; private JButton ButtonViwoStop; private JButton ButtongetAllGE; private JButton ButtongetAllSP; private JTable TableAddGrantee; private JTable TableDeletGrantee; private JTable TableEditGrantee; private JTable TableExpenses; private JTable TableGranteeExpenses; private JTable TablePayment; private JTable TableSerchGrantee; private JTable TableSerchGranteeStop; private JTable TableSponsorsPayment; private JTextField TextAccountNumberAdd; private JTextField TextAccountNumberEdit; private static JTextField TextAccountNumberSponsorAdd; private static JTextField TextContactGranteeMain; private static JTextField TextContactSponsorAdd; private static JTextField TextContactSponsorMain; private JTextField TextCrownGrantee; private JTextField TextCrownGranteeEdit; private JTextField TextDateBirth; private JTextField TextDateBirthEdit; private JTextField TextExpenseDay; private JTextField TextExpenseMonth; private JTextField TextExpenseValue; private JTextField TextExpenseYear; private JTextField TextFamilyCount; private JTextField TextFamilyCountEdit; private JTextField TextGranteeConnect; private JTextField TextGranteeConnectEdit; private JTextField TextGranteeIDDelet; private JTextField TextGranteeIDEdit; private JTextField TextGranteeIDExpenses; private JTextField TextGranteeIDPayment; private static JTextField TextGranteeIDSercheAdd; private static JTextField TextGranteeIDSercheStop; private JTextField TextGranteeName; private JTextField TextGranteeNameDelet; private JTextField TextGranteeNameEdit; private JTextField TextGranteeNameExpenses; private JTextField TextGranteeNameInExpenses; private JTextField TextGranteeNameInSponsors; private JTextField TextGranteeNamePayment; private JTextField TextGranteeNameSerche; private static JTextField TextGranteeNameSercheAdd; private static JTextField TextGranteeNameSercheStop; private static JTextField TextGranteeNameSercheStop2; private JTextField TextNameSercheDelet; private JTextField TextNameSercheEdite; private JTextField TextPaymentDay; private JTextField TextPaymentMonth; private JTextField TextPaymentValue; private JTextField TextPaymentYear; private JTextField TextRecipientName; private static JTextField TextRegestryGranteeMain; private JTextField TextRegestryID; private JTextField TextRegestryIDEdit; private static JTextField TextRegestrySponsorAdd; private static JTextField TextRegestrySponsorMain; private static JTextField TextSponsorDateAdd; private static JTextField TextSponsorNOExpenses; private static JTextField TextSponsorNOPayment; private static JTextField TextSponsorNameAdd; private static JTextField TextSponsorNameExpenses; private static JTextField TextSponsorNameMain; private static JTextField TextSponsorNameMainExpenses; private static JTextField TextSponsorNamePayment; private static JTextField TextSponsorNameStop; private static JTextField TextSponsorValueAdd; private JButton home; private JButton jButton1; private JButton jButton2; private JLabel jLabel1; private JLabel jLabel10;
/*      */   
/*      */   public GUEDisabled() {
/*   94 */     initComponents();
/*   95 */     setLocationRelativeTo((Component)null);
/*   96 */     this.jTabbedPane1.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     
/*   98 */     ShowGranteesTable();
/*   99 */     this.textsGranteeEdite = new JTextField[] { this.TextGranteeNameEdit, this.TextRegestryIDEdit, this.TextDateBirthEdit, this.textCityNameEdit, this.TextCrownGranteeEdit, this.TextGranteeConnectEdit, this.TextAccountNumberEdit, this.TextFamilyCountEdit };
/*  100 */     this.textsAddSponsor = new JTextField[] { TextSponsorDateAdd, TextSponsorNameAdd, TextContactSponsorAdd, TextSponsorValueAdd, TextRegestrySponsorAdd, TextAccountNumberSponsorAdd };
/*  101 */     this.textsDeleteGrantee = new JTextField[] { this.TextGranteeIDDelet, this.TextGranteeNameDelet };
/*  102 */     this.textsStopSponsor = new JTextField[] { TextGranteeIDSercheStop, TextGranteeNameSercheStop, TextSponsorNameStop };
/*  103 */     this.textsPayment = new JTextField[] { TextSponsorNOPayment, TextSponsorNamePayment, this.TextGranteeIDPayment, this.TextGranteeNamePayment };
/*  104 */     this.textsExpenses = new JTextField[] { this.TextGranteeIDExpenses, this.TextGranteeNameExpenses, TextSponsorNOExpenses, TextSponsorNameExpenses };
/*      */     
/*  106 */     this.jScrollPane5.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */   }
/*      */   private JLabel jLabel11; private JLabel jLabel12; private JLabel jLabel13; private JLabel jLabel14; private JLabel jLabel15; private JLabel jLabel16; private JLabel jLabel17; private JLabel jLabel18; private JLabel jLabel19; private JLabel jLabel2; private JLabel jLabel20; private JLabel jLabel21; private JLabel jLabel22; private JLabel jLabel23; private JLabel jLabel24; private JLabel jLabel25; private JLabel jLabel26; private JLabel jLabel27; private JLabel jLabel28; private JLabel jLabel29; private JLabel jLabel3; private JLabel jLabel30; private JLabel jLabel31; private JLabel jLabel32; private JLabel jLabel33; private JLabel jLabel34; private JLabel jLabel35; private JLabel jLabel36; private JLabel jLabel37; private JLabel jLabel38; private JLabel jLabel39; private JLabel jLabel4; private JLabel jLabel40; private JLabel jLabel41; private JLabel jLabel42; private JLabel jLabel43; private JLabel jLabel44; private JLabel jLabel45; private JLabel jLabel46; private JLabel jLabel47; private JLabel jLabel48; private JLabel jLabel49; private JLabel jLabel5; private JLabel jLabel50; private JLabel jLabel51; private JLabel jLabel52; private JLabel jLabel53; private JLabel jLabel54; private JLabel jLabel55; private JLabel jLabel56; private JLabel jLabel57; private JLabel jLabel58; private JLabel jLabel59; private JLabel jLabel6; private JLabel jLabel60; private JLabel jLabel61; private JLabel jLabel62; private JLabel jLabel63; private JLabel jLabel64; private JLabel jLabel65; private JLabel jLabel66; private JLabel jLabel67; private JLabel jLabel68; private JLabel jLabel69; private JLabel jLabel7; private JLabel jLabel70; private JLabel jLabel71; private JLabel jLabel73; private JLabel jLabel74; private JLabel jLabel75; private JLabel jLabel76; private JLabel jLabel8; private JLabel jLabel9; private JPanel jPanel1; private JPanel jPanel11; private JPanel jPanel12; private JPanel jPanel13; private JPanel jPanel14; private JPanel jPanel2; private JPanel jPanel3; private JPanel jPanel4; private JPanel jPanel5; private JPanel jPanel6; private JPanel jPanel7; private JPanel jPanel8; private JScrollPane jScrollPane1; private JScrollPane jScrollPane10; private JScrollPane jScrollPane2; private JScrollPane jScrollPane3; private JScrollPane jScrollPane4; private JScrollPane jScrollPane5; private JScrollPane jScrollPane6; private JScrollPane jScrollPane7; private JScrollPane jScrollPane8; private JScrollPane jScrollPane9; private JTabbedPane jTabbedPane1; private JTextField textCityName; private JTextField textCityNameEdit;
/*      */   public void OpenGUI(JTextField[] textsClose, JTextField textFocus, JButton button, Color MyColor, boolean TextEnabled, boolean ButtonEnabled) {
/*  110 */     for (int i = 0; i < textsClose.length; i++) {
/*  111 */       textsClose[i].setText("");
/*  112 */       textsClose[i].setEnabled(TextEnabled);
/*  113 */       textsClose[i].setBackground(MyColor);
/*      */     } 
/*  115 */     textFocus.requestFocus();
/*  116 */     button.setEnabled(ButtonEnabled);
/*      */   }
/*      */   
/*      */   public void CloseGUI(JTextField[] textsClose, JButton button, Color MyColor, boolean MyEnabled) {
/*  120 */     for (int i = 0; i < textsClose.length; i++) {
/*  121 */       textsClose[i].setText("");
/*  122 */       textsClose[i].setEnabled(MyEnabled);
/*  123 */       textsClose[i].setBackground(MyColor);
/*      */     } 
/*  125 */     button.setEnabled(MyEnabled);
/*      */   }
/*      */   public void replaceTablesAndTexts() {
/*  128 */     RemoveTable(this.TableSerchGrantee, this.SerchAddColomonsNames2);
/*  129 */     RemoveTable(this.TableEditGrantee, this.ColomonsNames);
/*  130 */     RemoveTable(this.TableDeletGrantee, this.ColomonsNames);
/*  131 */     RemoveTable(this.TableSerchGranteeStop, this.SerchStopColomonsNames);
/*  132 */     RemoveTable(this.TableSponsorsPayment, this.ColomonsSponsorsPaymentNames);
/*  133 */     RemoveTable(this.TableGranteeExpenses, this.ColomonsGranteesExpenseNames);
/*  134 */     RemoveTable(this.TablePayment, this.TablePaymentColomonsNames);
/*  135 */     RemoveTable(this.TableExpenses, this.TableExpensesColomonsNames);
/*      */     
/*  137 */     CloseGUI(this.textsGranteeEdite, this.ButtonEditGrantee, this.MyGray, false);
/*  138 */     CloseGUI(this.textsDeleteGrantee, this.ButtonAddGrantee2, this.MyYellow, false);
/*  139 */     CloseGUI(this.textsAddSponsor, ButtonAddSponsor, this.MyGray, false);
/*  140 */     CloseGUI(this.textsStopSponsor, ButtonStopSponsor, this.MyYellow, false);
/*  141 */     CloseGUI(this.textsPayment, ButtonPaymentSend, this.MyYellow, false);
/*  142 */     CloseGUI(this.textsExpenses, ButtonExpensesSend, this.MyYellow, false);
/*      */     
/*  144 */     TextGranteeIDSercheAdd.setText("");
/*  145 */     TextGranteeNameSercheAdd.setText("");
/*      */     
/*  147 */     this.TextGranteeIDEdit.setText("");
/*  148 */     this.BoxFamilyStutsSerch.setSelectedIndex(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void ShowPayments() {
/*      */     try {
/*  154 */       InfoPayment pay2 = new InfoPayment(0, this.TextGranteeIDPayment.getText().trim(), "", "", "", 0, 0, 0, "", "", "", "");
/*      */ 
/*      */ 
/*      */       
/*  158 */       ArrayList<InfoPayment> payment = pay2.getAllPayments();
/*  159 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TablePayment, this.PaymentColomonsNames);
/*  160 */       this.TablePayment = (new TablesSeting()).ColomonSize(this.TablePayment, this.PaymentColomonsSize);
/*  161 */       this.TablePayment.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererSupPayment());
/*  162 */       this.TablePayment.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererSupPayment(new JCheckBox()));
/*      */       
/*  164 */       this.TablePayment.getColumnModel().getColumn(1).setCellRenderer(new ClientsTableButtonRendererSupPayment());
/*  165 */       this.TablePayment.getColumnModel().getColumn(1).setCellEditor(new ClientsTableRendererSupPayment(new JCheckBox()));
/*  166 */       for (int i = 0; i < payment.size(); i++) {
/*      */         
/*  168 */         Object[] ary = { "طباعة فاتورة", "تحرير", ((InfoPayment)payment.get(i)).getPaymentYear() + "-" + ((InfoPayment)payment.get(i)).getPaymentMonth() + "-" + ((InfoPayment)payment.get(i)).getPaymentDay(), ((InfoPayment)payment.get(i)).getValuePayment(), ((InfoPayment)payment.get(i)).getSponsorsName(), Integer.valueOf(((InfoPayment)payment.get(i)).getId()) };
/*  169 */         dtm.addRow(ary);
/*      */       } 
/*  171 */     } catch (Exception ex) {
/*  172 */       Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void ShowExpenses() {
/*      */     try {
/*  179 */       InfoExpense expe = new InfoExpense(0, this.TextGranteeIDExpenses.getText().trim(), "", "", 0, 0, 0, "", "", "", "", "", 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  186 */       ArrayList<InfoExpense> expense = expe.getAllExpenses();
/*  187 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableExpenses, this.ExpenseColomonsNames);
/*  188 */       this.TableExpenses = (new TablesSeting()).ColomonSize(this.TableExpenses, this.ExpenseColomonsSize);
/*  189 */       this.TableExpenses.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererSupExpense());
/*  190 */       this.TableExpenses.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererSupExpense(new JCheckBox()));
/*      */       
/*  192 */       this.TableExpenses.getColumnModel().getColumn(1).setCellRenderer(new ClientsTableButtonRendererSupExpense());
/*  193 */       this.TableExpenses.getColumnModel().getColumn(1).setCellEditor(new ClientsTableRendererSupExpense(new JCheckBox()));
/*  194 */       for (int i = 0; i < expense.size(); i++) {
/*      */         
/*  196 */         Object[] ary = { "طباعة فاتورة", "تحرير", ((InfoExpense)expense.get(i)).getExpenseYear() + "-" + ((InfoExpense)expense.get(i)).getExpenseMonth() + "-" + ((InfoExpense)expense.get(i)).getExpenseDay(), ((InfoExpense)expense.get(i)).getValueExpense(), ((InfoExpense)expense.get(i)).getRecipientName(), Integer.valueOf(((InfoExpense)expense.get(i)).getId()) };
/*  197 */         dtm.addRow(ary);
/*      */       } 
/*  199 */     } catch (Exception ex) {
/*  200 */       Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ShowGranteesTable() {
/*  206 */     DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableAddGrantee, this.ColomonsNames);
/*  207 */     this.TableAddGrantee = (new TablesSeting()).ColomonSize(this.TableAddGrantee, this.ColomonsSize);
/*      */     try {
/*  209 */       this.grantee = this.gran.getAllGrantees("2");
/*  210 */       for (int i = 0; i < this.grantee.size(); i++) {
/*      */         
/*  212 */         Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getGranteeAccount(), ((InfoGrantees)this.grantee.get(i)).getGranteeConnect(), ((InfoGrantees)this.grantee.get(i)).getCrownGrantee(), ((InfoGrantees)this.grantee.get(i)).getCityName(), ((InfoGrantees)this.grantee.get(i)).getDateBirth(), ((InfoGrantees)this.grantee.get(i)).getRegestryID(), ((InfoGrantees)this.grantee.get(i)).getRegestryType(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/*      */         
/*  214 */         dtm.addRow(ary);
/*      */       } 
/*  216 */     } catch (Exception ex) {
/*  217 */       Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initComponents() {
/*  230 */     this.jTabbedPane1 = new JTabbedPane();
/*  231 */     this.jPanel1 = new JPanel();
/*  232 */     this.TextDateBirth = new JTextField();
/*  233 */     this.jLabel8 = new JLabel();
/*  234 */     this.jLabel7 = new JLabel();
/*  235 */     this.BoxRegestreType = new JComboBox();
/*  236 */     this.jLabel13 = new JLabel();
/*  237 */     this.TextRegestryID = new JTextField();
/*  238 */     this.jLabel14 = new JLabel();
/*  239 */     this.TextGranteeName = new JTextField();
/*  240 */     this.jLabel1 = new JLabel();
/*  241 */     this.TextCrownGrantee = new JTextField();
/*  242 */     this.jLabel9 = new JLabel();
/*  243 */     this.ButtonAddGrantee = new JButton();
/*  244 */     this.jLabel21 = new JLabel();
/*  245 */     this.TextGranteeConnect = new JTextField();
/*  246 */     this.jLabel32 = new JLabel();
/*  247 */     this.TextAccountNumberAdd = new JTextField();
/*  248 */     this.textCityName = new JTextField();
/*  249 */     this.TextFamilyCount = new JTextField();
/*  250 */     this.jLabel34 = new JLabel();
/*  251 */     this.BoxFamilyStuts = new JComboBox();
/*  252 */     this.jLabel35 = new JLabel();
/*  253 */     this.jScrollPane5 = new JScrollPane();
/*  254 */     this.jPanel7 = new JPanel();
/*  255 */     this.jScrollPane1 = new JScrollPane();
/*  256 */     this.TableAddGrantee = new JTable();
/*  257 */     this.jPanel6 = new JPanel();
/*  258 */     this.TextDateBirthEdit = new JTextField();
/*  259 */     this.jLabel10 = new JLabel();
/*  260 */     this.jLabel11 = new JLabel();
/*  261 */     this.BoxRegestreTypeEdit = new JComboBox();
/*  262 */     this.jLabel15 = new JLabel();
/*  263 */     this.TextRegestryIDEdit = new JTextField();
/*  264 */     this.jLabel16 = new JLabel();
/*  265 */     this.TextGranteeNameEdit = new JTextField();
/*  266 */     this.jLabel2 = new JLabel();
/*  267 */     this.TextCrownGranteeEdit = new JTextField();
/*  268 */     this.jLabel12 = new JLabel();
/*  269 */     this.ButtonEditGrantee = new JButton();
/*  270 */     this.jLabel17 = new JLabel();
/*  271 */     this.TextGranteeIDEdit = new JTextField();
/*  272 */     this.jLabel19 = new JLabel();
/*  273 */     this.TextGranteeConnectEdit = new JTextField();
/*  274 */     this.jLabel22 = new JLabel();
/*  275 */     this.TextAccountNumberEdit = new JTextField();
/*  276 */     this.jLabel31 = new JLabel();
/*  277 */     this.jPanel13 = new JPanel();
/*  278 */     this.jLabel52 = new JLabel();
/*  279 */     this.TextNameSercheEdite = new JTextField();
/*  280 */     this.ButtonGranteeSerchEdite = new JButton();
/*  281 */     this.jLabel51 = new JLabel();
/*  282 */     this.ButtonViwoEdite = new JButton();
/*  283 */     this.jScrollPane2 = new JScrollPane();
/*  284 */     this.TableEditGrantee = new JTable();
/*  285 */     this.jButton2 = new JButton();
/*  286 */     this.textCityNameEdit = new JTextField();
/*  287 */     this.jLabel3 = new JLabel();
/*  288 */     this.jLabel36 = new JLabel();
/*  289 */     this.TextFamilyCountEdit = new JTextField();
/*  290 */     this.BoxFamilyStutsEdit = new JComboBox();
/*  291 */     this.jLabel43 = new JLabel();
/*  292 */     this.jPanel2 = new JPanel();
/*  293 */     this.ButtonAddGrantee2 = new JButton();
/*  294 */     this.TextGranteeIDDelet = new JTextField();
/*  295 */     this.jLabel5 = new JLabel();
/*  296 */     this.TextGranteeNameDelet = new JTextField();
/*  297 */     this.jLabel6 = new JLabel();
/*  298 */     this.jLabel18 = new JLabel();
/*  299 */     this.jPanel14 = new JPanel();
/*  300 */     this.ButtonViwoDelet = new JButton();
/*  301 */     this.jLabel50 = new JLabel();
/*  302 */     this.ButtonGranteeSerchDelete = new JButton();
/*  303 */     this.TextNameSercheDelet = new JTextField();
/*  304 */     this.jLabel49 = new JLabel();
/*  305 */     this.jScrollPane3 = new JScrollPane();
/*  306 */     this.TableDeletGrantee = new JTable();
/*  307 */     this.jPanel3 = new JPanel();
/*  308 */     this.TextGranteeNameSerche = new JTextField();
/*  309 */     this.jLabel20 = new JLabel();
/*  310 */     this.ButtonGranteeSerch = new JButton();
/*  311 */     this.jScrollPane4 = new JScrollPane();
/*  312 */     this.TableSerchGrantee = new JTable();
/*  313 */     this.jPanel5 = new JPanel();
/*  314 */     this.jLabel23 = new JLabel();
/*  315 */     TextGranteeNameSercheAdd = new JTextField();
/*  316 */     this.jLabel24 = new JLabel();
/*  317 */     TextGranteeIDSercheAdd = new JTextField();
/*  318 */     TextSponsorNameAdd = new JTextField();
/*  319 */     this.jLabel25 = new JLabel();
/*  320 */     TextSponsorDateAdd = new JTextField();
/*  321 */     this.jLabel26 = new JLabel();
/*  322 */     TextContactSponsorAdd = new JTextField();
/*  323 */     this.jLabel27 = new JLabel();
/*  324 */     ButtonAddSponsor = new JButton();
/*  325 */     TextSponsorValueAdd = new JTextField();
/*  326 */     this.jLabel28 = new JLabel();
/*  327 */     TextRegestrySponsorAdd = new JTextField();
/*  328 */     this.jLabel29 = new JLabel();
/*  329 */     TextAccountNumberSponsorAdd = new JTextField();
/*  330 */     this.jLabel30 = new JLabel();
/*  331 */     this.ButtonViwoAdd = new JButton();
/*  332 */     this.jLabel33 = new JLabel();
/*  333 */     this.jButton1 = new JButton();
/*  334 */     this.BoxFamilyStutsSerch = new JComboBox();
/*  335 */     this.jLabel4 = new JLabel();
/*  336 */     this.jPanel11 = new JPanel();
/*  337 */     this.ButtonViwoStop = new JButton();
/*  338 */     this.jLabel44 = new JLabel();
/*  339 */     this.ButtonGranteeSerchStop = new JButton();
/*  340 */     TextGranteeNameSercheStop2 = new JTextField();
/*  341 */     this.jLabel45 = new JLabel();
/*  342 */     this.jScrollPane6 = new JScrollPane();
/*  343 */     this.TableSerchGranteeStop = new JTable();
/*  344 */     this.jPanel12 = new JPanel();
/*  345 */     this.jLabel46 = new JLabel();
/*  346 */     TextGranteeNameSercheStop = new JTextField();
/*  347 */     this.jLabel47 = new JLabel();
/*  348 */     TextGranteeIDSercheStop = new JTextField();
/*  349 */     TextSponsorNameStop = new JTextField();
/*  350 */     this.jLabel48 = new JLabel();
/*  351 */     ButtonStopSponsor = new JButton();
/*  352 */     this.jPanel4 = new JPanel();
/*  353 */     TextSponsorNameMain = new JTextField();
/*  354 */     TextContactSponsorMain = new JTextField();
/*  355 */     TextRegestrySponsorMain = new JTextField();
/*  356 */     this.jLabel53 = new JLabel();
/*  357 */     this.jLabel54 = new JLabel();
/*  358 */     this.jLabel55 = new JLabel();
/*  359 */     this.ButtonSerchSP = new JButton();
/*  360 */     this.ButtongetAllSP = new JButton();
/*  361 */     this.jScrollPane7 = new JScrollPane();
/*  362 */     this.TableSponsorsPayment = new JTable();
/*  363 */     this.TextGranteeNameInSponsors = new JTextField();
/*  364 */     this.jLabel56 = new JLabel();
/*  365 */     this.jLabel57 = new JLabel();
/*  366 */     TextSponsorNOPayment = new JTextField();
/*  367 */     this.jLabel58 = new JLabel();
/*  368 */     TextSponsorNamePayment = new JTextField();
/*  369 */     ButtonPaymentSend = new JButton();
/*  370 */     this.jLabel59 = new JLabel();
/*  371 */     this.TextPaymentValue = new JTextField();
/*  372 */     this.TextGranteeIDPayment = new JTextField();
/*  373 */     this.jLabel60 = new JLabel();
/*  374 */     this.jLabel61 = new JLabel();
/*  375 */     this.TextGranteeNamePayment = new JTextField();
/*  376 */     this.jLabel62 = new JLabel();
/*  377 */     this.TextPaymentMonth = new JTextField();
/*  378 */     this.jScrollPane8 = new JScrollPane();
/*  379 */     this.TablePayment = new JTable();
/*  380 */     this.ButtonReport = new JButton();
/*  381 */     this.jLabel74 = new JLabel();
/*  382 */     this.TextPaymentYear = new JTextField();
/*  383 */     this.TextPaymentDay = new JTextField();
/*  384 */     this.jLabel37 = new JLabel();
/*  385 */     this.jLabel38 = new JLabel();
/*  386 */     this.jLabel39 = new JLabel();
/*  387 */     this.jPanel8 = new JPanel();
/*  388 */     TextSponsorNameMainExpenses = new JTextField();
/*  389 */     TextContactGranteeMain = new JTextField();
/*  390 */     TextRegestryGranteeMain = new JTextField();
/*  391 */     this.jLabel63 = new JLabel();
/*  392 */     this.jLabel64 = new JLabel();
/*  393 */     this.jLabel65 = new JLabel();
/*  394 */     this.ButtonSerchGE = new JButton();
/*  395 */     this.ButtongetAllGE = new JButton();
/*  396 */     this.jScrollPane9 = new JScrollPane();
/*  397 */     this.TableGranteeExpenses = new JTable();
/*  398 */     this.TextGranteeNameInExpenses = new JTextField();
/*  399 */     this.jLabel66 = new JLabel();
/*  400 */     this.jLabel67 = new JLabel();
/*  401 */     TextSponsorNOExpenses = new JTextField();
/*  402 */     this.jLabel68 = new JLabel();
/*  403 */     TextSponsorNameExpenses = new JTextField();
/*  404 */     ButtonExpensesSend = new JButton();
/*  405 */     this.jLabel69 = new JLabel();
/*  406 */     this.TextExpenseValue = new JTextField();
/*  407 */     this.TextGranteeIDExpenses = new JTextField();
/*  408 */     this.jLabel70 = new JLabel();
/*  409 */     this.jLabel71 = new JLabel();
/*  410 */     this.TextGranteeNameExpenses = new JTextField();
/*  411 */     this.jScrollPane10 = new JScrollPane();
/*  412 */     this.TableExpenses = new JTable();
/*  413 */     this.TextRecipientName = new JTextField();
/*  414 */     this.jLabel73 = new JLabel();
/*  415 */     this.ButtonReport1 = new JButton();
/*  416 */     this.jLabel75 = new JLabel();
/*  417 */     this.jLabel40 = new JLabel();
/*  418 */     this.jLabel41 = new JLabel();
/*  419 */     this.jLabel42 = new JLabel();
/*  420 */     this.TextExpenseDay = new JTextField();
/*  421 */     this.TextExpenseMonth = new JTextField();
/*  422 */     this.TextExpenseYear = new JTextField();
/*  423 */     this.jLabel76 = new JLabel();
/*  424 */     this.home = new JButton();
/*      */     
/*  426 */     setDefaultCloseOperation(3);
/*  427 */     setIconImage(getToolkit().getImage(getClass().getResource("/images/logo-.png")));
/*      */     
/*  429 */     this.jTabbedPane1.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*  431 */             GUEDisabled.this.jTabbedPane1MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/*  435 */     this.jPanel1.setLayout((LayoutManager)null);
/*      */     
/*  437 */     this.TextDateBirth.setFont(new Font("Times New Roman", 1, 18));
/*  438 */     this.TextDateBirth.setHorizontalAlignment(4);
/*  439 */     this.TextDateBirth.setNextFocusableComponent(this.textCityName);
/*  440 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  442 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  445 */     this.TextDateBirth.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  447 */             GUEDisabled.this.TextDateBirthKeyPressed(evt);
/*      */           }
/*      */         });
/*  450 */     this.jPanel1.add(this.TextDateBirth);
/*  451 */     this.TextDateBirth.setBounds(800, 140, 190, 37);
/*      */     
/*  453 */     this.jLabel8.setText("تاريخ الميلاد:");
/*  454 */     this.jPanel1.add(this.jLabel8);
/*  455 */     this.jLabel8.setBounds(868, 104, 150, 30);
/*      */     
/*  457 */     this.jLabel7.setText("المدينة:");
/*  458 */     this.jPanel1.add(this.jLabel7);
/*  459 */     this.jLabel7.setBounds(575, 100, 130, 30);
/*      */     
/*  461 */     this.BoxRegestreType.setModel(new DefaultComboBoxModel<>(new String[] { "جواز السفر", "الهوية الوطنية", "إثبات عادي", "بطاقة", "رخصة إقامة", "أخرى" }));
/*  462 */     this.BoxRegestreType.setNextFocusableComponent(this.TextRegestryID);
/*  463 */     this.BoxRegestreType.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  465 */             GUEDisabled.this.BoxRegestreTypeKeyPressed(evt);
/*      */           }
/*      */         });
/*  468 */     this.jPanel1.add(this.BoxRegestreType);
/*  469 */     this.BoxRegestreType.setBounds(530, 50, 162, 37);
/*      */     
/*  471 */     this.jLabel13.setText("نوع الهوية");
/*  472 */     this.jPanel1.add(this.jLabel13);
/*  473 */     this.jLabel13.setBounds(547, 4, 140, 30);
/*      */     
/*  475 */     this.TextRegestryID.setFont(new Font("Times New Roman", 1, 18));
/*  476 */     this.TextRegestryID.setHorizontalAlignment(4);
/*  477 */     this.TextRegestryID.setNextFocusableComponent(this.TextDateBirth);
/*  478 */     this.TextRegestryID.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  480 */             GUEDisabled.this.TextRegestryIDKeyPressed(evt);
/*      */           }
/*      */         });
/*  483 */     this.jPanel1.add(this.TextRegestryID);
/*  484 */     this.TextRegestryID.setBounds(290, 50, 180, 34);
/*      */     
/*  486 */     this.jLabel14.setText("رقم الهوية");
/*  487 */     this.jPanel1.add(this.jLabel14);
/*  488 */     this.jLabel14.setBounds(340, 4, 170, 30);
/*      */     
/*  490 */     this.TextGranteeName.setFont(new Font("Times New Roman", 1, 18));
/*  491 */     this.TextGranteeName.setHorizontalAlignment(4);
/*  492 */     this.TextGranteeName.setNextFocusableComponent(this.BoxRegestreType);
/*  493 */     this.TextGranteeName.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  495 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  498 */     this.TextGranteeName.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  500 */             GUEDisabled.this.TextGranteeNameKeyPressed(evt);
/*      */           }
/*      */         });
/*  503 */     this.jPanel1.add(this.TextGranteeName);
/*  504 */     this.TextGranteeName.setBounds(720, 50, 275, 40);
/*      */     
/*  506 */     this.jLabel1.setText("اسم المعاق:");
/*  507 */     this.jPanel1.add(this.jLabel1);
/*  508 */     this.jLabel1.setBounds(830, 14, 170, 30);
/*      */     
/*  510 */     this.TextCrownGrantee.setFont(new Font("Times New Roman", 1, 18));
/*  511 */     this.TextCrownGrantee.setHorizontalAlignment(4);
/*  512 */     this.TextCrownGrantee.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  514 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  517 */     this.TextCrownGrantee.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  519 */             GUEDisabled.this.TextCrownGranteeKeyPressed(evt);
/*      */           }
/*      */         });
/*  522 */     this.jPanel1.add(this.TextCrownGrantee);
/*  523 */     this.TextCrownGrantee.setBounds(290, 140, 190, 37);
/*      */     
/*  525 */     this.jLabel9.setText("ولي أمر المعاق :");
/*  526 */     this.jPanel1.add(this.jLabel9);
/*  527 */     this.jLabel9.setBounds(330, 104, 160, 30);
/*      */     
/*  529 */     this.ButtonAddGrantee.setIcon(new ImageIcon(getClass().getResource("/images/save_diskette_floppy_disk.png")));
/*  530 */     this.ButtonAddGrantee.setText("إضافة");
/*  531 */     this.ButtonAddGrantee.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  533 */             GUEDisabled.this.ButtonAddGranteeActionPerformed(evt);
/*      */           }
/*      */         });
/*  536 */     this.ButtonAddGrantee.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  538 */             GUEDisabled.this.ButtonAddGranteeKeyPressed(evt);
/*      */           }
/*      */         });
/*  541 */     this.jPanel1.add(this.ButtonAddGrantee);
/*  542 */     this.ButtonAddGrantee.setBounds(540, 300, 190, 40);
/*      */     
/*  544 */     this.jLabel21.setText("وسيلة الاتصال :");
/*  545 */     this.jPanel1.add(this.jLabel21);
/*  546 */     this.jLabel21.setBounds(850, 184, 140, 30);
/*      */     
/*  548 */     this.TextGranteeConnect.setFont(new Font("Times New Roman", 1, 18));
/*  549 */     this.TextGranteeConnect.setHorizontalAlignment(4);
/*  550 */     this.TextGranteeConnect.setNextFocusableComponent(this.textCityName);
/*  551 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  553 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  556 */     this.TextGranteeConnect.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  558 */             GUEDisabled.this.TextGranteeConnectKeyPressed(evt);
/*      */           }
/*      */         });
/*  561 */     this.jPanel1.add(this.TextGranteeConnect);
/*  562 */     this.TextGranteeConnect.setBounds(800, 220, 190, 37);
/*      */     
/*  564 */     this.jLabel32.setText("رقم الحساب :");
/*  565 */     this.jPanel1.add(this.jLabel32);
/*  566 */     this.jLabel32.setBounds(590, 184, 180, 30);
/*      */     
/*  568 */     this.TextAccountNumberAdd.setFont(new Font("Times New Roman", 1, 18));
/*  569 */     this.TextAccountNumberAdd.setHorizontalAlignment(4);
/*  570 */     this.TextAccountNumberAdd.setNextFocusableComponent(this.textCityName);
/*  571 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  573 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  576 */     this.TextAccountNumberAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  578 */             GUEDisabled.this.TextAccountNumberAddKeyPressed(evt);
/*      */           }
/*      */         });
/*  581 */     this.jPanel1.add(this.TextAccountNumberAdd);
/*  582 */     this.TextAccountNumberAdd.setBounds(530, 220, 220, 37);
/*      */     
/*  584 */     this.textCityName.setFont(new Font("Times New Roman", 1, 18));
/*  585 */     this.textCityName.setHorizontalAlignment(4);
/*  586 */     this.textCityName.setNextFocusableComponent(this.textCityName);
/*  587 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  589 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  592 */     this.textCityName.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  594 */             GUEDisabled.this.textCityNameKeyPressed(evt);
/*      */           }
/*      */         });
/*  597 */     this.jPanel1.add(this.textCityName);
/*  598 */     this.textCityName.setBounds(520, 140, 190, 37);
/*      */     
/*  600 */     this.TextFamilyCount.setFont(new Font("Times New Roman", 1, 18));
/*  601 */     this.TextFamilyCount.setHorizontalAlignment(4);
/*  602 */     this.TextFamilyCount.setNextFocusableComponent(this.textCityName);
/*  603 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  605 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  608 */     this.TextFamilyCount.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  610 */             GUEDisabled.this.TextFamilyCountKeyPressed(evt);
/*      */           }
/*      */         });
/*  613 */     this.jPanel1.add(this.TextFamilyCount);
/*  614 */     this.TextFamilyCount.setBounds(310, 220, 110, 37);
/*      */     
/*  616 */     this.jLabel34.setText("عدد أفراد الأسرة :");
/*  617 */     this.jPanel1.add(this.jLabel34);
/*  618 */     this.jLabel34.setBounds(320, 180, 180, 30);
/*      */     
/*  620 */     this.BoxFamilyStuts.setModel(new DefaultComboBoxModel<>(new String[] { "أسرة ضعفها بسيط", "أسرة ضعفها متوسط", "أسرة ضعفها شديد" }));
/*  621 */     this.BoxFamilyStuts.setNextFocusableComponent(this.TextRegestryID);
/*  622 */     this.BoxFamilyStuts.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  624 */             GUEDisabled.this.BoxFamilyStutsKeyPressed(evt);
/*      */           }
/*      */         });
/*  627 */     this.jPanel1.add(this.BoxFamilyStuts);
/*  628 */     this.BoxFamilyStuts.setBounds(800, 300, 162, 37);
/*      */     
/*  630 */     this.jLabel35.setText("حالة الأسرة :");
/*  631 */     this.jPanel1.add(this.jLabel35);
/*  632 */     this.jLabel35.setBounds(820, 270, 140, 30);
/*      */     
/*  634 */     this.TableAddGrantee.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "Title 1", "Title 2", "Title 3", "Title 4" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  642 */     this.jScrollPane1.setViewportView(this.TableAddGrantee);
/*      */     
/*  644 */     GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
/*  645 */     this.jPanel7.setLayout(jPanel7Layout);
/*  646 */     jPanel7Layout.setHorizontalGroup(jPanel7Layout
/*  647 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  648 */         .addComponent(this.jScrollPane1, GroupLayout.Alignment.TRAILING, -1, 1207, 32767));
/*      */     
/*  650 */     jPanel7Layout.setVerticalGroup(jPanel7Layout
/*  651 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  652 */         .addComponent(this.jScrollPane1, -2, 100, -2));
/*      */ 
/*      */     
/*  655 */     this.jScrollPane5.setViewportView(this.jPanel7);
/*      */     
/*  657 */     this.jPanel1.add(this.jScrollPane5);
/*  658 */     this.jScrollPane5.setBounds(120, 370, 920, 140);
/*      */     
/*  660 */     this.jTabbedPane1.addTab("إضافة معاق", this.jPanel1);
/*      */     
/*  662 */     this.jPanel6.setLayout((LayoutManager)null);
/*      */     
/*  664 */     this.TextDateBirthEdit.setFont(new Font("Times New Roman", 1, 18));
/*  665 */     this.TextDateBirthEdit.setHorizontalAlignment(4);
/*  666 */     this.TextDateBirthEdit.setNextFocusableComponent(this.textCityName);
/*  667 */     this.TextDateBirthEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  669 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  672 */     this.TextDateBirthEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  674 */             GUEDisabled.this.TextDateBirthEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  677 */     this.jPanel6.add(this.TextDateBirthEdit);
/*  678 */     this.TextDateBirthEdit.setBounds(760, 400, 190, 37);
/*      */     
/*  680 */     this.jLabel10.setText("تاريخ الميلاد:");
/*  681 */     this.jPanel6.add(this.jLabel10);
/*  682 */     this.jLabel10.setBounds(900, 374, 140, 20);
/*      */     
/*  684 */     this.jLabel11.setText("المدينة:");
/*  685 */     this.jPanel6.add(this.jLabel11);
/*  686 */     this.jLabel11.setBounds(530, 360, 150, 30);
/*      */     
/*  688 */     this.BoxRegestreTypeEdit.setModel(new DefaultComboBoxModel<>(new String[] { "جواز السفر", "الهوية الوطنية", "إثبات عادي", "بطاقة", "رخصة إقامة", "أخرى" }));
/*  689 */     this.BoxRegestreTypeEdit.setNextFocusableComponent(this.TextRegestryID);
/*  690 */     this.BoxRegestreTypeEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  692 */             GUEDisabled.this.BoxRegestreTypeEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  695 */     this.jPanel6.add(this.BoxRegestreTypeEdit);
/*  696 */     this.BoxRegestreTypeEdit.setBounds(400, 310, 162, 37);
/*      */     
/*  698 */     this.jLabel15.setText("نوع الهوية");
/*  699 */     this.jPanel6.add(this.jLabel15);
/*  700 */     this.jLabel15.setBounds(447, 274, 110, 30);
/*      */     
/*  702 */     this.TextRegestryIDEdit.setFont(new Font("Times New Roman", 1, 18));
/*  703 */     this.TextRegestryIDEdit.setHorizontalAlignment(4);
/*  704 */     this.TextRegestryIDEdit.setNextFocusableComponent(this.TextDateBirth);
/*  705 */     this.TextRegestryIDEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  707 */             GUEDisabled.this.TextRegestryIDEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  710 */     this.jPanel6.add(this.TextRegestryIDEdit);
/*  711 */     this.TextRegestryIDEdit.setBounds(200, 310, 170, 34);
/*      */     
/*  713 */     this.jLabel16.setText("رقم الهوية");
/*  714 */     this.jPanel6.add(this.jLabel16);
/*  715 */     this.jLabel16.setBounds(245, 274, 130, 20);
/*      */     
/*  717 */     this.TextGranteeNameEdit.setFont(new Font("Times New Roman", 1, 18));
/*  718 */     this.TextGranteeNameEdit.setHorizontalAlignment(4);
/*  719 */     this.TextGranteeNameEdit.setNextFocusableComponent(this.BoxRegestreType);
/*  720 */     this.TextGranteeNameEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  722 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  725 */     this.TextGranteeNameEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  727 */             GUEDisabled.this.TextGranteeNameEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  730 */     this.jPanel6.add(this.TextGranteeNameEdit);
/*  731 */     this.TextGranteeNameEdit.setBounds(580, 310, 275, 40);
/*      */     
/*  733 */     this.jLabel2.setText("اسم المعاق:");
/*  734 */     this.jPanel6.add(this.jLabel2);
/*  735 */     this.jLabel2.setBounds(665, 284, 190, 20);
/*      */     
/*  737 */     this.TextCrownGranteeEdit.setFont(new Font("Times New Roman", 1, 18));
/*  738 */     this.TextCrownGranteeEdit.setHorizontalAlignment(4);
/*  739 */     this.TextCrownGranteeEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  741 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  744 */     this.TextCrownGranteeEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  746 */             GUEDisabled.this.TextCrownGranteeEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  749 */     this.jPanel6.add(this.TextCrownGranteeEdit);
/*  750 */     this.TextCrownGranteeEdit.setBounds(230, 400, 190, 37);
/*      */     
/*  752 */     this.jLabel12.setText("ولي أمر اليتيم :");
/*  753 */     this.jPanel6.add(this.jLabel12);
/*  754 */     this.jLabel12.setBounds(220, 310, 56, 15);
/*      */     
/*  756 */     this.ButtonEditGrantee.setIcon(new ImageIcon(getClass().getResource("/images/options.png")));
/*  757 */     this.ButtonEditGrantee.setText("تعديل");
/*  758 */     this.ButtonEditGrantee.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  760 */             GUEDisabled.this.ButtonEditGranteeActionPerformed(evt);
/*      */           }
/*      */         });
/*  763 */     this.ButtonEditGrantee.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  765 */             GUEDisabled.this.ButtonEditGranteeKeyPressed(evt);
/*      */           }
/*      */         });
/*  768 */     this.jPanel6.add(this.ButtonEditGrantee);
/*  769 */     this.ButtonEditGrantee.setBounds(150, 480, 180, 40);
/*      */     
/*  771 */     this.jLabel17.setFont(new Font("Tahoma", 1, 14));
/*  772 */     this.jLabel17.setForeground(new Color(255, 0, 0));
/*  773 */     this.jLabel17.setText("اضغط على المعاق في الجدول لتعديل بياناته");
/*  774 */     this.jPanel6.add(this.jLabel17);
/*  775 */     this.jLabel17.setBounds(490, 240, 510, 30);
/*      */     
/*  777 */     this.TextGranteeIDEdit.setBackground(new Color(255, 255, 153));
/*  778 */     this.TextGranteeIDEdit.setEnabled(false);
/*  779 */     this.jPanel6.add(this.TextGranteeIDEdit);
/*  780 */     this.TextGranteeIDEdit.setBounds(870, 310, 80, 40);
/*      */     
/*  782 */     this.jLabel19.setText("رقم المعاق:");
/*  783 */     this.jPanel6.add(this.jLabel19);
/*  784 */     this.jLabel19.setBounds(900, 274, 110, 30);
/*      */     
/*  786 */     this.TextGranteeConnectEdit.setFont(new Font("Times New Roman", 1, 18));
/*  787 */     this.TextGranteeConnectEdit.setHorizontalAlignment(4);
/*  788 */     this.TextGranteeConnectEdit.setNextFocusableComponent(this.textCityName);
/*  789 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  791 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  794 */     this.TextGranteeConnectEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  796 */             GUEDisabled.this.TextGranteeConnectEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  799 */     this.jPanel6.add(this.TextGranteeConnectEdit);
/*  800 */     this.TextGranteeConnectEdit.setBounds(0, 400, 190, 37);
/*      */     
/*  802 */     this.jLabel22.setText("وسيلة الاتصال :");
/*  803 */     this.jPanel6.add(this.jLabel22);
/*  804 */     this.jLabel22.setBounds(60, 370, 190, 20);
/*      */     
/*  806 */     this.TextAccountNumberEdit.setFont(new Font("Times New Roman", 1, 18));
/*  807 */     this.TextAccountNumberEdit.setHorizontalAlignment(4);
/*  808 */     this.TextAccountNumberEdit.setNextFocusableComponent(this.textCityName);
/*  809 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  811 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  814 */     this.TextAccountNumberEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  816 */             GUEDisabled.this.TextAccountNumberEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  819 */     this.jPanel6.add(this.TextAccountNumberEdit);
/*  820 */     this.TextAccountNumberEdit.setBounds(770, 480, 190, 37);
/*      */     
/*  822 */     this.jLabel31.setText("رقم الحساب :");
/*  823 */     this.jPanel6.add(this.jLabel31);
/*  824 */     this.jLabel31.setBounds(810, 450, 160, 20);
/*      */     
/*  826 */     this.jPanel13.setBorder(BorderFactory.createTitledBorder(null, "أدخل اسم المعاق أو اضغط عرض الكل", 3, 0));
/*  827 */     this.jPanel13.setCursor(new Cursor(0));
/*      */     
/*  829 */     this.jLabel52.setText("اسم المعاق:");
/*      */     
/*  831 */     this.TextNameSercheEdite.setFont(new Font("Times New Roman", 1, 18));
/*  832 */     this.TextNameSercheEdite.setHorizontalAlignment(4);
/*  833 */     this.TextNameSercheEdite.setNextFocusableComponent(this.BoxRegestreType);
/*  834 */     this.TextGranteeName.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  836 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  839 */     this.TextNameSercheEdite.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  841 */             GUEDisabled.this.TextNameSercheEditeKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/*  845 */     this.ButtonGranteeSerchEdite.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/*  846 */     this.ButtonGranteeSerchEdite.setText("بحث");
/*  847 */     this.ButtonGranteeSerchEdite.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  849 */             GUEDisabled.this.ButtonGranteeSerchEditeActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/*  853 */     this.jLabel51.setFont(new Font("Tahoma", 0, 18));
/*  854 */     this.jLabel51.setText("أو");
/*      */     
/*  856 */     this.ButtonViwoEdite.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/*  857 */     this.ButtonViwoEdite.setText("عرض الكل");
/*  858 */     this.ButtonViwoEdite.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  860 */             GUEDisabled.this.ButtonViwoEditeActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/*  864 */     this.TableEditGrantee.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null, null, null, null, null, null }, , { null, null, null, null, null, null, null, null, null, null, null }, , { null, null, null, null, null, null, null, null, null, null, null }, , { null, null, null, null, null, null, null, null, null, null, null },  }, (Object[])new String[] { "حالة الأسرة", "عدد أفراد الأسرة", "رقم الحساب", "وسيلة الاتصال", "ولي الأمر", "المدينة", "تاريخ الميلاد", "رقم الهوية", "نوع الهوية", "الاسم", "الرقم" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  875 */     this.TableEditGrantee.addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent evt) {
/*  877 */             GUEDisabled.this.TableEditGranteeMousePressed(evt);
/*      */           }
/*      */         });
/*  880 */     this.jScrollPane2.setViewportView(this.TableEditGrantee);
/*      */     
/*  882 */     this.jButton2.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/*  883 */     this.jButton2.setText("تقرير");
/*  884 */     this.jButton2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  886 */             GUEDisabled.this.jButton2ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/*  890 */     GroupLayout jPanel13Layout = new GroupLayout(this.jPanel13);
/*  891 */     this.jPanel13.setLayout(jPanel13Layout);
/*  892 */     jPanel13Layout.setHorizontalGroup(jPanel13Layout
/*  893 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  894 */         .addGroup(jPanel13Layout.createSequentialGroup()
/*  895 */           .addContainerGap()
/*  896 */           .addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  897 */             .addGroup(GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
/*  898 */               .addGap(0, 252, 32767)
/*  899 */               .addComponent(this.ButtonViwoEdite, -2, 133, -2)
/*  900 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/*  901 */               .addComponent(this.jLabel51, -2, 48, -2)
/*  902 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/*  903 */               .addComponent(this.ButtonGranteeSerchEdite)
/*  904 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/*  905 */               .addComponent(this.TextNameSercheEdite, -2, 260, -2)
/*  906 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/*  907 */               .addComponent(this.jLabel52, -2, 143, -2))
/*  908 */             .addComponent(this.jScrollPane2))
/*  909 */           .addContainerGap())
/*  910 */         .addGroup(jPanel13Layout.createSequentialGroup()
/*  911 */           .addGap(340, 340, 340)
/*  912 */           .addComponent(this.jButton2, -2, 307, -2)
/*  913 */           .addContainerGap(-1, 32767)));
/*      */     
/*  915 */     jPanel13Layout.setVerticalGroup(jPanel13Layout
/*  916 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  917 */         .addGroup(jPanel13Layout.createSequentialGroup()
/*  918 */           .addContainerGap()
/*  919 */           .addGroup(jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/*  920 */             .addGroup(GroupLayout.Alignment.TRAILING, jPanel13Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/*  921 */               .addComponent(this.ButtonViwoEdite, -2, 41, -2)
/*  922 */               .addComponent(this.jLabel51)
/*  923 */               .addComponent(this.ButtonGranteeSerchEdite)
/*  924 */               .addComponent(this.TextNameSercheEdite, -2, -1, -2))
/*  925 */             .addComponent(this.jLabel52, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/*  926 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/*  927 */           .addComponent(this.jScrollPane2, -2, 91, -2)
/*  928 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/*  929 */           .addComponent(this.jButton2, -1, -1, 32767)));
/*      */ 
/*      */     
/*  932 */     this.jPanel6.add(this.jPanel13);
/*  933 */     this.jPanel13.setBounds(10, 10, 1000, 230);
/*      */     
/*  935 */     this.textCityNameEdit.setFont(new Font("Times New Roman", 1, 18));
/*  936 */     this.textCityNameEdit.setHorizontalAlignment(4);
/*  937 */     this.textCityNameEdit.setNextFocusableComponent(this.textCityName);
/*  938 */     this.TextDateBirthEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  940 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  943 */     this.textCityNameEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  945 */             GUEDisabled.this.textCityNameEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  948 */     this.jPanel6.add(this.textCityNameEdit);
/*  949 */     this.textCityNameEdit.setBounds(450, 400, 190, 37);
/*      */     
/*  951 */     this.jLabel3.setText("ولي الأمر :");
/*  952 */     this.jPanel6.add(this.jLabel3);
/*  953 */     this.jLabel3.setBounds(300, 370, 170, 20);
/*      */     
/*  955 */     this.jLabel36.setText("عدد أفراد الأسرة :");
/*  956 */     this.jPanel6.add(this.jLabel36);
/*  957 */     this.jLabel36.setBounds(600, 440, 180, 30);
/*      */     
/*  959 */     this.TextFamilyCountEdit.setFont(new Font("Times New Roman", 1, 18));
/*  960 */     this.TextFamilyCountEdit.setHorizontalAlignment(4);
/*  961 */     this.TextFamilyCountEdit.setNextFocusableComponent(this.textCityName);
/*  962 */     this.TextDateBirth.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/*  964 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/*  967 */     this.TextFamilyCountEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  969 */             GUEDisabled.this.TextFamilyCountEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  972 */     this.jPanel6.add(this.TextFamilyCountEdit);
/*  973 */     this.TextFamilyCountEdit.setBounds(590, 480, 110, 37);
/*      */     
/*  975 */     this.BoxFamilyStutsEdit.setModel(new DefaultComboBoxModel<>(new String[] { "أسرة ضعفها بسيط", "أسرة ضعفها متوسط", "أسرة ضعفها شديد" }));
/*  976 */     this.BoxFamilyStutsEdit.setNextFocusableComponent(this.TextRegestryID);
/*  977 */     this.BoxFamilyStutsEdit.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*  979 */             GUEDisabled.this.BoxFamilyStutsEditKeyPressed(evt);
/*      */           }
/*      */         });
/*  982 */     this.jPanel6.add(this.BoxFamilyStutsEdit);
/*  983 */     this.BoxFamilyStutsEdit.setBounds(380, 480, 162, 37);
/*      */     
/*  985 */     this.jLabel43.setText("حالة الأسرة :");
/*  986 */     this.jPanel6.add(this.jLabel43);
/*  987 */     this.jLabel43.setBounds(420, 450, 140, 20);
/*      */     
/*  989 */     this.jTabbedPane1.addTab("تعديل معاق", this.jPanel6);
/*      */     
/*  991 */     this.jPanel2.setLayout((LayoutManager)null);
/*      */     
/*  993 */     this.ButtonAddGrantee2.setIcon(new ImageIcon(getClass().getResource("/images/delete_2.png")));
/*  994 */     this.ButtonAddGrantee2.setText("حذف");
/*  995 */     this.ButtonAddGrantee2.setEnabled(false);
/*  996 */     this.ButtonAddGrantee2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*  998 */             GUEDisabled.this.ButtonAddGrantee2ActionPerformed(evt);
/*      */           }
/*      */         });
/* 1001 */     this.jPanel2.add(this.ButtonAddGrantee2);
/* 1002 */     this.ButtonAddGrantee2.setBounds(630, 323, 117, 40);
/*      */     
/* 1004 */     this.TextGranteeIDDelet.setBackground(new Color(255, 255, 153));
/* 1005 */     this.TextGranteeIDDelet.setEnabled(false);
/* 1006 */     this.jPanel2.add(this.TextGranteeIDDelet);
/* 1007 */     this.TextGranteeIDDelet.setBounds(469, 323, 89, 40);
/*      */     
/* 1009 */     this.jLabel5.setText("الرقم :");
/* 1010 */     this.jPanel2.add(this.jLabel5);
/* 1011 */     this.jLabel5.setBounds(497, 282, 110, 30);
/*      */     
/* 1013 */     this.TextGranteeNameDelet.setBackground(new Color(255, 255, 153));
/* 1014 */     this.TextGranteeNameDelet.setFont(new Font("Times New Roman", 1, 18));
/* 1015 */     this.TextGranteeNameDelet.setHorizontalAlignment(4);
/* 1016 */     this.TextGranteeNameDelet.setEnabled(false);
/* 1017 */     this.TextGranteeNameDelet.setNextFocusableComponent(this.BoxRegestreType);
/* 1018 */     this.jPanel2.add(this.TextGranteeNameDelet);
/* 1019 */     this.TextGranteeNameDelet.setBounds(154, 323, 275, 40);
/*      */     
/* 1021 */     this.jLabel6.setText("اسم المعاق:");
/* 1022 */     this.jPanel2.add(this.jLabel6);
/* 1023 */     this.jLabel6.setBounds(344, 287, 120, 30);
/*      */     
/* 1025 */     this.jLabel18.setFont(new Font("Tahoma", 1, 14));
/* 1026 */     this.jLabel18.setForeground(new Color(255, 0, 0));
/* 1027 */     this.jLabel18.setText("اضغط على المعاق في الجدول لحذفه بياناته ثم اضغط على \"حذف\"");
/* 1028 */     this.jPanel2.add(this.jLabel18);
/* 1029 */     this.jLabel18.setBounds(209, 241, 800, 30);
/*      */     
/* 1031 */     this.jPanel14.setBorder(BorderFactory.createTitledBorder(null, "أدخل اسم المعاق أو اضغط عرض الكل", 3, 0));
/*      */     
/* 1033 */     this.ButtonViwoDelet.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/* 1034 */     this.ButtonViwoDelet.setText("عرض الكل");
/* 1035 */     this.ButtonViwoDelet.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1037 */             GUEDisabled.this.ButtonViwoDeletActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1041 */     this.jLabel50.setFont(new Font("Tahoma", 0, 18));
/* 1042 */     this.jLabel50.setText("أو");
/*      */     
/* 1044 */     this.ButtonGranteeSerchDelete.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/* 1045 */     this.ButtonGranteeSerchDelete.setText("بحث");
/* 1046 */     this.ButtonGranteeSerchDelete.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1048 */             GUEDisabled.this.ButtonGranteeSerchDeleteActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1052 */     this.TextNameSercheDelet.setFont(new Font("Times New Roman", 1, 18));
/* 1053 */     this.TextNameSercheDelet.setHorizontalAlignment(4);
/* 1054 */     this.TextGranteeName.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 1056 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/* 1059 */     this.TextNameSercheDelet.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1061 */             GUEDisabled.this.TextNameSercheDeletKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1065 */     this.jLabel49.setText("اسم المعاق:");
/*      */     
/* 1067 */     this.TableDeletGrantee.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null }, , { null, null, null, null }, , { null, null, null, null }, , { null, null, null, null },  }, (Object[])new String[] { "Title 1", "Title 2", "Title 3", "Title 4" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1078 */     this.TableDeletGrantee.addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent evt) {
/* 1080 */             GUEDisabled.this.TableDeletGranteeMousePressed(evt);
/*      */           }
/*      */         });
/* 1083 */     this.jScrollPane3.setViewportView(this.TableDeletGrantee);
/*      */     
/* 1085 */     GroupLayout jPanel14Layout = new GroupLayout(this.jPanel14);
/* 1086 */     this.jPanel14.setLayout(jPanel14Layout);
/* 1087 */     jPanel14Layout.setHorizontalGroup(jPanel14Layout
/* 1088 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1089 */         .addGroup(jPanel14Layout.createSequentialGroup()
/* 1090 */           .addContainerGap()
/* 1091 */           .addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1092 */             .addGroup(jPanel14Layout.createSequentialGroup()
/* 1093 */               .addGap(0, 341, 32767)
/* 1094 */               .addComponent(this.ButtonViwoDelet)
/* 1095 */               .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 1096 */               .addComponent(this.jLabel50, -2, 36, -2)
/* 1097 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1098 */               .addComponent(this.ButtonGranteeSerchDelete, -2, 109, -2)
/* 1099 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1100 */               .addComponent(this.TextNameSercheDelet, -2, 275, -2)
/* 1101 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1102 */               .addComponent(this.jLabel49, -2, 104, -2))
/* 1103 */             .addComponent(this.jScrollPane3))
/* 1104 */           .addContainerGap()));
/*      */     
/* 1106 */     jPanel14Layout.setVerticalGroup(jPanel14Layout
/* 1107 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1108 */         .addGroup(jPanel14Layout.createSequentialGroup()
/* 1109 */           .addGap(23, 23, 23)
/* 1110 */           .addGroup(jPanel14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1111 */             .addComponent(this.ButtonViwoDelet)
/* 1112 */             .addComponent(this.jLabel50)
/* 1113 */             .addComponent(this.ButtonGranteeSerchDelete)
/* 1114 */             .addComponent(this.TextNameSercheDelet, -2, 31, -2)
/* 1115 */             .addComponent(this.jLabel49, -2, 41, -2))
/* 1116 */           .addGap(18, 18, 18)
/* 1117 */           .addComponent(this.jScrollPane3, -2, 95, -2)
/* 1118 */           .addContainerGap(15, 32767)));
/*      */ 
/*      */     
/* 1121 */     this.jPanel2.add(this.jPanel14);
/* 1122 */     this.jPanel14.setBounds(13, 20, 1030, 215);
/*      */     
/* 1124 */     this.jTabbedPane1.addTab("حذف معاق", this.jPanel2);
/*      */     
/* 1126 */     this.jPanel3.setLayout((LayoutManager)null);
/*      */     
/* 1128 */     this.TextGranteeNameSerche.setFont(new Font("Times New Roman", 1, 18));
/* 1129 */     this.TextGranteeNameSerche.setHorizontalAlignment(4);
/* 1130 */     this.TextGranteeNameSerche.setNextFocusableComponent(this.BoxRegestreType);
/* 1131 */     this.TextGranteeName.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 1133 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/* 1136 */     this.TextGranteeNameSerche.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1138 */             GUEDisabled.this.TextGranteeNameSercheKeyPressed(evt);
/*      */           }
/*      */         });
/* 1141 */     this.jPanel3.add(this.TextGranteeNameSerche);
/* 1142 */     this.TextGranteeNameSerche.setBounds(660, 30, 240, 31);
/*      */     
/* 1144 */     this.jLabel20.setText("اسم المعاق:");
/* 1145 */     this.jPanel3.add(this.jLabel20);
/* 1146 */     this.jLabel20.setBounds(900, 30, 150, 30);
/*      */     
/* 1148 */     this.ButtonGranteeSerch.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/* 1149 */     this.ButtonGranteeSerch.setText("بحث");
/* 1150 */     this.ButtonGranteeSerch.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1152 */             GUEDisabled.this.ButtonGranteeSerchActionPerformed(evt);
/*      */           }
/*      */         });
/* 1155 */     this.jPanel3.add(this.ButtonGranteeSerch);
/* 1156 */     this.ButtonGranteeSerch.setBounds(200, 30, 110, 40);
/*      */     
/* 1158 */     this.TableSerchGrantee.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "إضافة كفيل", "عدد الأسرة", "حالة الأسرة", "اسم المعاق", "الرقم" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1166 */     this.TableSerchGrantee.setRowHeight(30);
/* 1167 */     this.jScrollPane4.setViewportView(this.TableSerchGrantee);
/*      */     
/* 1169 */     this.jPanel3.add(this.jScrollPane4);
/* 1170 */     this.jScrollPane4.setBounds(24, 90, 1020, 140);
/*      */     
/* 1172 */     this.jPanel5.setBorder(BorderFactory.createTitledBorder(null, "إضافة كفيل", 3, 0));
/* 1173 */     this.jPanel5.setLayout((LayoutManager)null);
/*      */     
/* 1175 */     this.jLabel23.setText("اسم المعاق:");
/* 1176 */     this.jPanel5.add(this.jLabel23);
/* 1177 */     this.jLabel23.setBounds(609, 17, 205, 25);
/*      */     
/* 1179 */     TextGranteeNameSercheAdd.setBackground(new Color(255, 255, 153));
/* 1180 */     TextGranteeNameSercheAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1181 */     TextGranteeNameSercheAdd.setHorizontalAlignment(4);
/* 1182 */     TextGranteeNameSercheAdd.setEnabled(false);
/* 1183 */     TextGranteeNameSercheAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1184 */     this.jPanel5.add(TextGranteeNameSercheAdd);
/* 1185 */     TextGranteeNameSercheAdd.setBounds(504, 48, 275, 40);
/*      */     
/* 1187 */     this.jLabel24.setText("الرقم :");
/* 1188 */     this.jPanel5.add(this.jLabel24);
/* 1189 */     this.jLabel24.setBounds(864, 17, 71, 25);
/*      */     
/* 1191 */     TextGranteeIDSercheAdd.setBackground(new Color(255, 255, 153));
/* 1192 */     TextGranteeIDSercheAdd.setEnabled(false);
/* 1193 */     this.jPanel5.add(TextGranteeIDSercheAdd);
/* 1194 */     TextGranteeIDSercheAdd.setBounds(846, 48, 89, 40);
/*      */     
/* 1196 */     TextSponsorNameAdd.setBackground(new Color(204, 204, 204));
/* 1197 */     TextSponsorNameAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1198 */     TextSponsorNameAdd.setHorizontalAlignment(4);
/* 1199 */     TextSponsorNameAdd.setEnabled(false);
/* 1200 */     TextSponsorNameAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1201 */     TextSponsorNameAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1203 */             GUEDisabled.this.TextSponsorNameAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1206 */     this.jPanel5.add(TextSponsorNameAdd);
/* 1207 */     TextSponsorNameAdd.setBounds(210, 50, 275, 40);
/*      */     
/* 1209 */     this.jLabel25.setText("اسم الكفيل :");
/* 1210 */     this.jPanel5.add(this.jLabel25);
/* 1211 */     this.jLabel25.setBounds(340, 20, 166, 20);
/*      */     
/* 1213 */     TextSponsorDateAdd.setBackground(new Color(204, 204, 204));
/* 1214 */     TextSponsorDateAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1215 */     TextSponsorDateAdd.setHorizontalAlignment(4);
/* 1216 */     TextSponsorDateAdd.setEnabled(false);
/* 1217 */     TextSponsorDateAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1218 */     TextSponsorDateAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1220 */             GUEDisabled.this.TextSponsorDateAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1223 */     this.jPanel5.add(TextSponsorDateAdd);
/* 1224 */     TextSponsorDateAdd.setBounds(20, 50, 170, 40);
/*      */     
/* 1226 */     this.jLabel26.setText("تاريخ الكفالة :");
/* 1227 */     this.jPanel5.add(this.jLabel26);
/* 1228 */     this.jLabel26.setBounds(80, 20, 178, 23);
/*      */     
/* 1230 */     TextContactSponsorAdd.setBackground(new Color(204, 204, 204));
/* 1231 */     TextContactSponsorAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1232 */     TextContactSponsorAdd.setHorizontalAlignment(4);
/* 1233 */     TextContactSponsorAdd.setEnabled(false);
/* 1234 */     TextContactSponsorAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1235 */     TextContactSponsorAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1237 */             GUEDisabled.this.TextContactSponsorAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1240 */     this.jPanel5.add(TextContactSponsorAdd);
/* 1241 */     TextContactSponsorAdd.setBounds(770, 130, 186, 40);
/*      */     
/* 1243 */     this.jLabel27.setText("هاتف أو جوال الكفيل:");
/* 1244 */     this.jPanel5.add(this.jLabel27);
/* 1245 */     this.jLabel27.setBounds(800, 100, 160, 24);
/*      */     
/* 1247 */     ButtonAddSponsor.setIcon(new ImageIcon(getClass().getResource("/images/save_diskette_floppy_disk.png")));
/* 1248 */     ButtonAddSponsor.setText("إضافة");
/* 1249 */     ButtonAddSponsor.setEnabled(false);
/* 1250 */     ButtonAddSponsor.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1252 */             GUEDisabled.this.ButtonAddSponsorActionPerformed(evt);
/*      */           }
/*      */         });
/* 1255 */     ButtonAddSponsor.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1257 */             GUEDisabled.this.ButtonAddSponsorKeyPressed(evt);
/*      */           }
/*      */         });
/* 1260 */     this.jPanel5.add(ButtonAddSponsor);
/* 1261 */     ButtonAddSponsor.setBounds(60, 130, 180, 42);
/*      */     
/* 1263 */     TextSponsorValueAdd.setBackground(new Color(204, 204, 204));
/* 1264 */     TextSponsorValueAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1265 */     TextSponsorValueAdd.setHorizontalAlignment(4);
/* 1266 */     TextSponsorValueAdd.setEnabled(false);
/* 1267 */     TextSponsorValueAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1268 */     TextSponsorValueAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1270 */             GUEDisabled.this.TextSponsorValueAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1273 */     this.jPanel5.add(TextSponsorValueAdd);
/* 1274 */     TextSponsorValueAdd.setBounds(680, 130, 83, 40);
/*      */     
/* 1276 */     this.jLabel28.setText("قيمة الكفالة :");
/* 1277 */     this.jPanel5.add(this.jLabel28);
/* 1278 */     this.jLabel28.setBounds(680, 100, 110, 22);
/*      */     
/* 1280 */     TextRegestrySponsorAdd.setBackground(new Color(204, 204, 204));
/* 1281 */     TextRegestrySponsorAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1282 */     TextRegestrySponsorAdd.setHorizontalAlignment(4);
/* 1283 */     TextRegestrySponsorAdd.setEnabled(false);
/* 1284 */     TextRegestrySponsorAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1285 */     TextRegestrySponsorAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1287 */             GUEDisabled.this.TextRegestrySponsorAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1290 */     this.jPanel5.add(TextRegestrySponsorAdd);
/* 1291 */     TextRegestrySponsorAdd.setBounds(480, 130, 190, 40);
/*      */     
/* 1293 */     this.jLabel29.setText("رقم هوية الكفيل :");
/* 1294 */     this.jPanel5.add(this.jLabel29);
/* 1295 */     this.jLabel29.setBounds(500, 100, 170, 22);
/*      */     
/* 1297 */     TextAccountNumberSponsorAdd.setBackground(new Color(204, 204, 204));
/* 1298 */     TextAccountNumberSponsorAdd.setFont(new Font("Times New Roman", 1, 18));
/* 1299 */     TextAccountNumberSponsorAdd.setHorizontalAlignment(4);
/* 1300 */     TextAccountNumberSponsorAdd.setEnabled(false);
/* 1301 */     TextAccountNumberSponsorAdd.setNextFocusableComponent(this.BoxRegestreType);
/* 1302 */     TextAccountNumberSponsorAdd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1304 */             GUEDisabled.this.TextAccountNumberSponsorAddKeyPressed(evt);
/*      */           }
/*      */         });
/* 1307 */     this.jPanel5.add(TextAccountNumberSponsorAdd);
/* 1308 */     TextAccountNumberSponsorAdd.setBounds(270, 130, 203, 42);
/*      */     
/* 1310 */     this.jLabel30.setText("رقم حساب الكفيل :");
/* 1311 */     this.jPanel5.add(this.jLabel30);
/* 1312 */     this.jLabel30.setBounds(300, 100, 160, 22);
/*      */     
/* 1314 */     this.jPanel3.add(this.jPanel5);
/* 1315 */     this.jPanel5.setBounds(40, 330, 1000, 200);
/*      */     
/* 1317 */     this.ButtonViwoAdd.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/* 1318 */     this.ButtonViwoAdd.setText("عرض الكل");
/* 1319 */     this.ButtonViwoAdd.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1321 */             GUEDisabled.this.ButtonViwoAddActionPerformed(evt);
/*      */           }
/*      */         });
/* 1324 */     this.jPanel3.add(this.ButtonViwoAdd);
/* 1325 */     this.ButtonViwoAdd.setBounds(3, 30, 150, 40);
/*      */     
/* 1327 */     this.jLabel33.setFont(new Font("Tahoma", 0, 18));
/* 1328 */     this.jLabel33.setText("أو");
/* 1329 */     this.jPanel3.add(this.jLabel33);
/* 1330 */     this.jLabel33.setBounds(160, 40, 30, 22);
/*      */     
/* 1332 */     this.jButton1.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/* 1333 */     this.jButton1.setText("تقرير");
/* 1334 */     this.jButton1.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1336 */             GUEDisabled.this.jButton1ActionPerformed(evt);
/*      */           }
/*      */         });
/* 1339 */     this.jPanel3.add(this.jButton1);
/* 1340 */     this.jButton1.setBounds(450, 260, 320, 42);
/*      */     
/* 1342 */     this.BoxFamilyStutsSerch.setModel(new DefaultComboBoxModel<>(new String[] { "الجميع", "أسرة ضعفها بسيط", "أسرة ضعفها متوسط", "أسرة ضعفها شديد" }));
/* 1343 */     this.BoxFamilyStutsSerch.setNextFocusableComponent(this.TextRegestryID);
/* 1344 */     this.BoxFamilyStutsSerch.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1346 */             GUEDisabled.this.BoxFamilyStutsSerchKeyPressed(evt);
/*      */           }
/*      */         });
/* 1349 */     this.jPanel3.add(this.BoxFamilyStutsSerch);
/* 1350 */     this.BoxFamilyStutsSerch.setBounds(340, 30, 162, 37);
/*      */     
/* 1352 */     this.jLabel4.setText("حالة الأسرة:");
/* 1353 */     this.jPanel3.add(this.jLabel4);
/* 1354 */     this.jLabel4.setBounds(510, 30, 130, 30);
/*      */     
/* 1356 */     this.jTabbedPane1.addTab("بحث و إضافة كفيل معاق", this.jPanel3);
/*      */     
/* 1358 */     this.jPanel11.setLayout((LayoutManager)null);
/*      */     
/* 1360 */     this.ButtonViwoStop.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/* 1361 */     this.ButtonViwoStop.setText("عرض الكل");
/* 1362 */     this.ButtonViwoStop.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1364 */             GUEDisabled.this.ButtonViwoStopActionPerformed(evt);
/*      */           }
/*      */         });
/* 1367 */     this.jPanel11.add(this.ButtonViwoStop);
/* 1368 */     this.ButtonViwoStop.setBounds(400, 40, 120, 40);
/*      */     
/* 1370 */     this.jLabel44.setFont(new Font("Tahoma", 0, 18));
/* 1371 */     this.jLabel44.setText("أو");
/* 1372 */     this.jPanel11.add(this.jLabel44);
/* 1373 */     this.jLabel44.setBounds(530, 50, 40, 22);
/*      */     
/* 1375 */     this.ButtonGranteeSerchStop.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/* 1376 */     this.ButtonGranteeSerchStop.setText("بحث");
/* 1377 */     this.ButtonGranteeSerchStop.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1379 */             GUEDisabled.this.ButtonGranteeSerchStopActionPerformed(evt);
/*      */           }
/*      */         });
/* 1382 */     this.jPanel11.add(this.ButtonGranteeSerchStop);
/* 1383 */     this.ButtonGranteeSerchStop.setBounds(580, 40, 110, 40);
/*      */     
/* 1385 */     TextGranteeNameSercheStop2.setFont(new Font("Times New Roman", 1, 18));
/* 1386 */     TextGranteeNameSercheStop2.setHorizontalAlignment(4);
/* 1387 */     TextGranteeNameSercheStop2.setNextFocusableComponent(this.BoxRegestreType);
/* 1388 */     this.TextGranteeName.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 1390 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/* 1393 */     TextGranteeNameSercheStop2.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1395 */             GUEDisabled.this.TextGranteeNameSercheStop2KeyPressed(evt);
/*      */           }
/*      */         });
/* 1398 */     this.jPanel11.add(TextGranteeNameSercheStop2);
/* 1399 */     TextGranteeNameSercheStop2.setBounds(710, 50, 275, 31);
/*      */     
/* 1401 */     this.jLabel45.setText("اسم المعاق:");
/* 1402 */     this.jPanel11.add(this.jLabel45);
/* 1403 */     this.jLabel45.setBounds(810, 14, 230, 30);
/*      */     
/* 1405 */     this.TableSerchGranteeStop.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "رقم الكفيل", "اسم الكفيل الحالي", "إيقاف الكفالة", "اسم المعاق", "الرقم" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1413 */     this.TableSerchGranteeStop.setRowHeight(30);
/* 1414 */     this.jScrollPane6.setViewportView(this.TableSerchGranteeStop);
/*      */     
/* 1416 */     this.jPanel11.add(this.jScrollPane6);
/* 1417 */     this.jScrollPane6.setBounds(320, 110, 664, 110);
/*      */     
/* 1419 */     this.jPanel12.setBorder(BorderFactory.createTitledBorder(null, "إضافة كفيل", 3, 0));
/*      */     
/* 1421 */     this.jLabel46.setText("اسم المعاق:");
/*      */     
/* 1423 */     TextGranteeNameSercheStop.setBackground(new Color(255, 255, 153));
/* 1424 */     TextGranteeNameSercheStop.setFont(new Font("Times New Roman", 1, 18));
/* 1425 */     TextGranteeNameSercheStop.setHorizontalAlignment(4);
/* 1426 */     TextGranteeNameSercheStop.setEnabled(false);
/* 1427 */     TextGranteeNameSercheStop.setNextFocusableComponent(this.BoxRegestreType);
/*      */     
/* 1429 */     this.jLabel47.setText("الرقم :");
/*      */     
/* 1431 */     TextGranteeIDSercheStop.setBackground(new Color(255, 255, 153));
/* 1432 */     TextGranteeIDSercheStop.setEnabled(false);
/*      */     
/* 1434 */     TextSponsorNameStop.setBackground(new Color(255, 255, 153));
/* 1435 */     TextSponsorNameStop.setFont(new Font("Times New Roman", 1, 18));
/* 1436 */     TextSponsorNameStop.setHorizontalAlignment(4);
/* 1437 */     TextSponsorNameStop.setEnabled(false);
/* 1438 */     TextSponsorNameStop.setNextFocusableComponent(this.BoxRegestreType);
/* 1439 */     TextSponsorNameStop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1441 */             GUEDisabled.this.TextSponsorNameStopKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1445 */     this.jLabel48.setText("اسم الكفيل الحالي :");
/*      */     
/* 1447 */     ButtonStopSponsor.setIcon(new ImageIcon(getClass().getResource("/images/stop_2.png")));
/* 1448 */     ButtonStopSponsor.setText("إيقاف");
/* 1449 */     ButtonStopSponsor.setEnabled(false);
/* 1450 */     ButtonStopSponsor.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1452 */             GUEDisabled.this.ButtonStopSponsorActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1456 */     GroupLayout jPanel12Layout = new GroupLayout(this.jPanel12);
/* 1457 */     this.jPanel12.setLayout(jPanel12Layout);
/* 1458 */     jPanel12Layout.setHorizontalGroup(jPanel12Layout
/* 1459 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1460 */         .addGroup(jPanel12Layout.createSequentialGroup()
/* 1461 */           .addContainerGap(499, 32767)
/* 1462 */           .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1463 */             .addGroup(GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
/* 1464 */               .addComponent(ButtonStopSponsor, -1, 118, 32767)
/* 1465 */               .addGap(38, 38, 38)
/* 1466 */               .addComponent(TextSponsorNameStop, -2, 275, -2))
/* 1467 */             .addGroup(GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
/* 1468 */               .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 1469 */                 .addComponent(TextGranteeNameSercheStop, -2, 275, -2)
/* 1470 */                 .addComponent(this.jLabel46, -2, 190, -2))
/* 1471 */               .addGap(67, 67, 67)
/* 1472 */               .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1473 */                 .addComponent(TextGranteeIDSercheStop, GroupLayout.Alignment.TRAILING, -1, 89, 32767)
/* 1474 */                 .addComponent(this.jLabel47, -1, -1, 32767)))
/* 1475 */             .addComponent(this.jLabel48, GroupLayout.Alignment.TRAILING, -2, 218, -2))
/* 1476 */           .addGap(25, 25, 25)));
/*      */     
/* 1478 */     jPanel12Layout.setVerticalGroup(jPanel12Layout
/* 1479 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1480 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
/* 1481 */           .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1482 */             .addComponent(this.jLabel47, -2, 25, -2)
/* 1483 */             .addComponent(this.jLabel46, -2, 25, -2))
/* 1484 */           .addGap(6, 6, 6)
/* 1485 */           .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 1486 */             .addComponent(TextGranteeIDSercheStop)
/* 1487 */             .addComponent(TextGranteeNameSercheStop, -2, 40, -2))
/* 1488 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1489 */           .addComponent(this.jLabel48, -2, 26, -2)
/* 1490 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1491 */           .addGroup(jPanel12Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1492 */             .addComponent(TextSponsorNameStop, -2, 40, -2)
/* 1493 */             .addComponent(ButtonStopSponsor, -2, 41, -2))
/* 1494 */           .addContainerGap(32, 32767)));
/*      */ 
/*      */     
/* 1497 */     this.jPanel11.add(this.jPanel12);
/* 1498 */     this.jPanel12.setBounds(26, 237, 967, 205);
/*      */     
/* 1500 */     this.jTabbedPane1.addTab("إيقاف كفالة معاق", this.jPanel11);
/*      */     
/* 1502 */     this.jPanel4.setLayout((LayoutManager)null);
/*      */     
/* 1504 */     TextSponsorNameMain.setFont(new Font("Times New Roman", 1, 18));
/* 1505 */     TextSponsorNameMain.setHorizontalAlignment(4);
/* 1506 */     TextSponsorNameMain.setNextFocusableComponent(this.BoxRegestreType);
/* 1507 */     TextSponsorNameMain.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1509 */             GUEDisabled.this.TextSponsorNameMainKeyPressed(evt);
/*      */           }
/*      */         });
/* 1512 */     this.jPanel4.add(TextSponsorNameMain);
/* 1513 */     TextSponsorNameMain.setBounds(830, 50, 209, 40);
/*      */     
/* 1515 */     TextContactSponsorMain.setFont(new Font("Times New Roman", 1, 18));
/* 1516 */     TextContactSponsorMain.setHorizontalAlignment(4);
/* 1517 */     TextContactSponsorMain.setNextFocusableComponent(this.BoxRegestreType);
/* 1518 */     TextContactSponsorMain.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1520 */             GUEDisabled.this.TextContactSponsorMainKeyPressed(evt);
/*      */           }
/*      */         });
/* 1523 */     this.jPanel4.add(TextContactSponsorMain);
/* 1524 */     TextContactSponsorMain.setBounds(680, 50, 141, 40);
/*      */     
/* 1526 */     TextRegestrySponsorMain.setFont(new Font("Times New Roman", 1, 18));
/* 1527 */     TextRegestrySponsorMain.setHorizontalAlignment(4);
/* 1528 */     TextRegestrySponsorMain.setNextFocusableComponent(this.BoxRegestreType);
/* 1529 */     TextRegestrySponsorMain.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1531 */             GUEDisabled.this.TextRegestrySponsorMainKeyPressed(evt);
/*      */           }
/*      */         });
/* 1534 */     this.jPanel4.add(TextRegestrySponsorMain);
/* 1535 */     TextRegestrySponsorMain.setBounds(500, 50, 160, 38);
/*      */     
/* 1537 */     this.jLabel53.setText("هاتف أو جوال الكفيل:");
/* 1538 */     this.jPanel4.add(this.jLabel53);
/* 1539 */     this.jLabel53.setBounds(680, 4, 190, 30);
/*      */     
/* 1541 */     this.jLabel54.setText("رقم هوية الكفيل :");
/* 1542 */     this.jPanel4.add(this.jLabel54);
/* 1543 */     this.jLabel54.setBounds(500, 4, 170, 30);
/*      */     
/* 1545 */     this.jLabel55.setText("اسم الكفيل :");
/* 1546 */     this.jPanel4.add(this.jLabel55);
/* 1547 */     this.jLabel55.setBounds(880, 4, 160, 30);
/*      */     
/* 1549 */     this.ButtonSerchSP.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/* 1550 */     this.ButtonSerchSP.setText("بحث");
/* 1551 */     this.ButtonSerchSP.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1553 */             GUEDisabled.this.ButtonSerchSPActionPerformed(evt);
/*      */           }
/*      */         });
/* 1556 */     this.jPanel4.add(this.ButtonSerchSP);
/* 1557 */     this.ButtonSerchSP.setBounds(164, 50, 100, 40);
/*      */     
/* 1559 */     this.ButtongetAllSP.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/* 1560 */     this.ButtongetAllSP.setText("عرض الكل");
/* 1561 */     this.ButtongetAllSP.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1563 */             GUEDisabled.this.ButtongetAllSPActionPerformed(evt);
/*      */           }
/*      */         });
/* 1566 */     this.jPanel4.add(this.ButtongetAllSP);
/* 1567 */     this.ButtongetAllSP.setBounds(10, 50, 120, 42);
/*      */     
/* 1569 */     this.TableSponsorsPayment.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "دفع مبلغ", "اسم المعاق", "رقم المعاق", "اسم الكفيل", "رقم الكفيل" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1577 */     this.TableSponsorsPayment.setRowHeight(30);
/* 1578 */     this.jScrollPane7.setViewportView(this.TableSponsorsPayment);
/*      */     
/* 1580 */     this.jPanel4.add(this.jScrollPane7);
/* 1581 */     this.jScrollPane7.setBounds(130, 120, 833, 104);
/*      */     
/* 1583 */     this.TextGranteeNameInSponsors.setFont(new Font("Times New Roman", 1, 18));
/* 1584 */     this.TextGranteeNameInSponsors.setHorizontalAlignment(4);
/* 1585 */     this.TextGranteeNameInSponsors.setNextFocusableComponent(this.BoxRegestreType);
/* 1586 */     this.TextGranteeNameEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 1588 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/* 1591 */     this.TextGranteeNameInSponsors.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1593 */             GUEDisabled.this.TextGranteeNameInSponsorsKeyPressed(evt);
/*      */           }
/*      */         });
/* 1596 */     this.jPanel4.add(this.TextGranteeNameInSponsors);
/* 1597 */     this.TextGranteeNameInSponsors.setBounds(280, 50, 209, 40);
/*      */     
/* 1599 */     this.jLabel56.setText("اسم المعاق:");
/* 1600 */     this.jPanel4.add(this.jLabel56);
/* 1601 */     this.jLabel56.setBounds(330, 14, 160, 20);
/*      */     
/* 1603 */     this.jLabel57.setText("رقم الكفيل:");
/* 1604 */     this.jPanel4.add(this.jLabel57);
/* 1605 */     this.jLabel57.setBounds(950, 250, 110, 30);
/*      */     
/* 1607 */     TextSponsorNOPayment.setBackground(new Color(255, 255, 153));
/* 1608 */     TextSponsorNOPayment.setEnabled(false);
/* 1609 */     this.jPanel4.add(TextSponsorNOPayment);
/* 1610 */     TextSponsorNOPayment.setBounds(940, 290, 90, 40);
/*      */     
/* 1612 */     this.jLabel58.setText("اسم الكفيل :");
/* 1613 */     this.jPanel4.add(this.jLabel58);
/* 1614 */     this.jLabel58.setBounds(780, 250, 160, 30);
/*      */     
/* 1616 */     TextSponsorNamePayment.setBackground(new Color(255, 255, 153));
/* 1617 */     TextSponsorNamePayment.setFont(new Font("Times New Roman", 1, 18));
/* 1618 */     TextSponsorNamePayment.setHorizontalAlignment(4);
/* 1619 */     TextSponsorNamePayment.setEnabled(false);
/* 1620 */     TextSponsorNamePayment.setNextFocusableComponent(this.BoxRegestreType);
/* 1621 */     TextSponsorNamePayment.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1623 */             GUEDisabled.this.TextSponsorNamePaymentKeyPressed(evt);
/*      */           }
/*      */         });
/* 1626 */     this.jPanel4.add(TextSponsorNamePayment);
/* 1627 */     TextSponsorNamePayment.setBounds(750, 290, 180, 40);
/*      */     
/* 1629 */     ButtonPaymentSend.setIcon(new ImageIcon(getClass().getResource("/images/Untitled - Copy.png")));
/* 1630 */     ButtonPaymentSend.setText("دفع");
/* 1631 */     ButtonPaymentSend.setEnabled(false);
/* 1632 */     ButtonPaymentSend.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1634 */             GUEDisabled.this.ButtonPaymentSendActionPerformed(evt);
/*      */           }
/*      */         });
/* 1637 */     this.jPanel4.add(ButtonPaymentSend);
/* 1638 */     ButtonPaymentSend.setBounds(-2, 290, 130, 41);
/*      */     
/* 1640 */     this.jLabel59.setText("قيمة المبلغ المدفوع :");
/* 1641 */     this.jPanel4.add(this.jLabel59);
/* 1642 */     this.jLabel59.setBounds(370, 250, 140, 30);
/*      */     
/* 1644 */     this.TextPaymentValue.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1646 */             GUEDisabled.this.TextPaymentValueKeyPressed(evt);
/*      */           }
/*      */         });
/* 1649 */     this.jPanel4.add(this.TextPaymentValue);
/* 1650 */     this.TextPaymentValue.setBounds(350, 290, 130, 41);
/*      */     
/* 1652 */     this.TextGranteeIDPayment.setBackground(new Color(255, 255, 153));
/* 1653 */     this.TextGranteeIDPayment.setEnabled(false);
/* 1654 */     this.jPanel4.add(this.TextGranteeIDPayment);
/* 1655 */     this.TextGranteeIDPayment.setBounds(690, 290, 53, 40);
/*      */     
/* 1657 */     this.jLabel60.setText("رقم المعاق :");
/* 1658 */     this.jPanel4.add(this.jLabel60);
/* 1659 */     this.jLabel60.setBounds(680, 250, 90, 30);
/*      */     
/* 1661 */     this.jLabel61.setText("اسم المعاق:");
/* 1662 */     this.jPanel4.add(this.jLabel61);
/* 1663 */     this.jLabel61.setBounds(530, 250, 130, 30);
/*      */     
/* 1665 */     this.TextGranteeNamePayment.setBackground(new Color(255, 255, 153));
/* 1666 */     this.TextGranteeNamePayment.setFont(new Font("Times New Roman", 1, 18));
/* 1667 */     this.TextGranteeNamePayment.setHorizontalAlignment(4);
/* 1668 */     this.TextGranteeNamePayment.setEnabled(false);
/* 1669 */     this.TextGranteeNamePayment.setNextFocusableComponent(this.BoxRegestreType);
/* 1670 */     this.jPanel4.add(this.TextGranteeNamePayment);
/* 1671 */     this.TextGranteeNamePayment.setBounds(490, 290, 190, 40);
/*      */     
/* 1673 */     this.jLabel62.setText("ضع التاريخ رقمًا");
/* 1674 */     this.jPanel4.add(this.jLabel62);
/* 1675 */     this.jLabel62.setBounds(190, 230, 150, 30);
/*      */     
/* 1677 */     this.TextPaymentMonth.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1679 */             GUEDisabled.this.TextPaymentMonthKeyPressed(evt);
/*      */           }
/*      */         });
/* 1682 */     this.jPanel4.add(this.TextPaymentMonth);
/* 1683 */     this.TextPaymentMonth.setBounds(220, 290, 50, 40);
/*      */     
/* 1685 */     this.TablePayment.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "طباعة فاتورة", "تحرير", "التاريخ", "المبلغ", "اسم الكفيل", "الرقم التسلسلي" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1693 */     this.TablePayment.setRowHeight(30);
/* 1694 */     this.jScrollPane8.setViewportView(this.TablePayment);
/*      */     
/* 1696 */     this.jPanel4.add(this.jScrollPane8);
/* 1697 */     this.jScrollPane8.setBounds(97, 346, 680, 104);
/*      */     
/* 1699 */     this.ButtonReport.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/* 1700 */     this.ButtonReport.setText("تقرير بكامل مدفوعات الكفيل");
/* 1701 */     this.ButtonReport.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1703 */             GUEDisabled.this.ButtonReportActionPerformed(evt);
/*      */           }
/*      */         });
/* 1706 */     this.jPanel4.add(this.ButtonReport);
/* 1707 */     this.ButtonReport.setBounds(230, 460, 400, 50);
/*      */     
/* 1709 */     this.jLabel74.setFont(new Font("Tahoma", 0, 18));
/* 1710 */     this.jLabel74.setText("أو");
/* 1711 */     this.jPanel4.add(this.jLabel74);
/* 1712 */     this.jLabel74.setBounds(140, 60, 20, 22);
/*      */     
/* 1714 */     this.TextPaymentYear.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1716 */             GUEDisabled.this.TextPaymentYearKeyPressed(evt);
/*      */           }
/*      */         });
/* 1719 */     this.jPanel4.add(this.TextPaymentYear);
/* 1720 */     this.TextPaymentYear.setBounds(140, 290, 70, 40);
/*      */     
/* 1722 */     this.TextPaymentDay.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1724 */             GUEDisabled.this.TextPaymentDayKeyPressed(evt);
/*      */           }
/*      */         });
/* 1727 */     this.jPanel4.add(this.TextPaymentDay);
/* 1728 */     this.TextPaymentDay.setBounds(280, 290, 50, 40);
/*      */     
/* 1730 */     this.jLabel37.setText("عام");
/* 1731 */     this.jPanel4.add(this.jLabel37);
/* 1732 */     this.jLabel37.setBounds(150, 260, 70, 15);
/*      */     
/* 1734 */     this.jLabel38.setText("شهر");
/* 1735 */     this.jPanel4.add(this.jLabel38);
/* 1736 */     this.jLabel38.setBounds(230, 260, 50, 15);
/*      */     
/* 1738 */     this.jLabel39.setText("يوم");
/* 1739 */     this.jPanel4.add(this.jLabel39);
/* 1740 */     this.jLabel39.setBounds(290, 260, 70, 15);
/*      */     
/* 1742 */     this.jTabbedPane1.addTab("الكفلاء و الدفع", this.jPanel4);
/*      */     
/* 1744 */     this.jPanel8.setLayout((LayoutManager)null);
/*      */     
/* 1746 */     TextSponsorNameMainExpenses.setFont(new Font("Times New Roman", 1, 18));
/* 1747 */     TextSponsorNameMainExpenses.setHorizontalAlignment(4);
/* 1748 */     TextSponsorNameMainExpenses.setNextFocusableComponent(this.BoxRegestreType);
/* 1749 */     TextSponsorNameMainExpenses.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1751 */             GUEDisabled.this.TextSponsorNameMainExpensesKeyPressed(evt);
/*      */           }
/*      */         });
/* 1754 */     this.jPanel8.add(TextSponsorNameMainExpenses);
/* 1755 */     TextSponsorNameMainExpenses.setBounds(290, 50, 209, 40);
/*      */     
/* 1757 */     TextContactGranteeMain.setFont(new Font("Times New Roman", 1, 18));
/* 1758 */     TextContactGranteeMain.setHorizontalAlignment(4);
/* 1759 */     TextContactGranteeMain.setNextFocusableComponent(this.BoxRegestreType);
/* 1760 */     TextContactGranteeMain.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1762 */             GUEDisabled.this.TextContactGranteeMainKeyPressed(evt);
/*      */           }
/*      */         });
/* 1765 */     this.jPanel8.add(TextContactGranteeMain);
/* 1766 */     TextContactGranteeMain.setBounds(680, 50, 141, 40);
/*      */     
/* 1768 */     TextRegestryGranteeMain.setFont(new Font("Times New Roman", 1, 18));
/* 1769 */     TextRegestryGranteeMain.setHorizontalAlignment(4);
/* 1770 */     TextRegestryGranteeMain.setNextFocusableComponent(this.BoxRegestreType);
/* 1771 */     TextRegestryGranteeMain.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1773 */             GUEDisabled.this.TextRegestryGranteeMainKeyPressed(evt);
/*      */           }
/*      */         });
/* 1776 */     this.jPanel8.add(TextRegestryGranteeMain);
/* 1777 */     TextRegestryGranteeMain.setBounds(510, 50, 160, 38);
/*      */     
/* 1779 */     this.jLabel63.setText("هاتف المعاق:");
/* 1780 */     this.jPanel8.add(this.jLabel63);
/* 1781 */     this.jLabel63.setBounds(700, 4, 130, 30);
/*      */     
/* 1783 */     this.jLabel64.setText("رقم هوية المعاق :");
/* 1784 */     this.jPanel8.add(this.jLabel64);
/* 1785 */     this.jLabel64.setBounds(540, 4, 130, 30);
/*      */     
/* 1787 */     this.jLabel65.setText("اسم الكفيل :");
/* 1788 */     this.jPanel8.add(this.jLabel65);
/* 1789 */     this.jLabel65.setBounds(360, 4, 170, 30);
/*      */     
/* 1791 */     this.ButtonSerchGE.setIcon(new ImageIcon(getClass().getResource("/images/search_lense.png")));
/* 1792 */     this.ButtonSerchGE.setText("بحث");
/* 1793 */     this.ButtonSerchGE.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1795 */             GUEDisabled.this.ButtonSerchGEActionPerformed(evt);
/*      */           }
/*      */         });
/* 1798 */     this.jPanel8.add(this.ButtonSerchGE);
/* 1799 */     this.ButtonSerchGE.setBounds(180, 50, 100, 40);
/*      */     
/* 1801 */     this.ButtongetAllGE.setIcon(new ImageIcon(getClass().getResource("/images/bak.png")));
/* 1802 */     this.ButtongetAllGE.setText("عرض الكل");
/* 1803 */     this.ButtongetAllGE.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1805 */             GUEDisabled.this.ButtongetAllGEActionPerformed(evt);
/*      */           }
/*      */         });
/* 1808 */     this.jPanel8.add(this.ButtongetAllGE);
/* 1809 */     this.ButtongetAllGE.setBounds(10, 50, 120, 42);
/*      */     
/* 1811 */     this.TableGranteeExpenses.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "صرف مبلغ", "اسم الكفيل", "رقم الكفيل", "اسم المعاق", "رقم المعاق" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1819 */     this.TableGranteeExpenses.setRowHeight(30);
/* 1820 */     this.jScrollPane9.setViewportView(this.TableGranteeExpenses);
/*      */     
/* 1822 */     this.jPanel8.add(this.jScrollPane9);
/* 1823 */     this.jScrollPane9.setBounds(70, 120, 898, 104);
/*      */     
/* 1825 */     this.TextGranteeNameInExpenses.setFont(new Font("Times New Roman", 1, 18));
/* 1826 */     this.TextGranteeNameInExpenses.setHorizontalAlignment(4);
/* 1827 */     this.TextGranteeNameInExpenses.setNextFocusableComponent(this.BoxRegestreType);
/* 1828 */     this.TextGranteeNameEdit.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 1830 */             GUEDisabled.this.TextToArabicFocusGained(evt);
/*      */           }
/*      */         });
/* 1833 */     this.TextGranteeNameInExpenses.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1835 */             GUEDisabled.this.TextGranteeNameInExpensesKeyPressed(evt);
/*      */           }
/*      */         });
/* 1838 */     this.jPanel8.add(this.TextGranteeNameInExpenses);
/* 1839 */     this.TextGranteeNameInExpenses.setBounds(840, 50, 209, 40);
/*      */     
/* 1841 */     this.jLabel66.setText("اسم المعاق:");
/* 1842 */     this.jPanel8.add(this.jLabel66);
/* 1843 */     this.jLabel66.setBounds(880, 14, 170, 20);
/*      */     
/* 1845 */     this.jLabel67.setText("رقم الكفيل:");
/* 1846 */     this.jPanel8.add(this.jLabel67);
/* 1847 */     this.jLabel67.setBounds(700, 260, 100, 20);
/*      */     
/* 1849 */     TextSponsorNOExpenses.setBackground(new Color(255, 255, 153));
/* 1850 */     TextSponsorNOExpenses.setEnabled(false);
/* 1851 */     this.jPanel8.add(TextSponsorNOExpenses);
/* 1852 */     TextSponsorNOExpenses.setBounds(700, 290, 60, 40);
/*      */     
/* 1854 */     this.jLabel68.setText("اسم الكفيل :");
/* 1855 */     this.jPanel8.add(this.jLabel68);
/* 1856 */     this.jLabel68.setBounds(550, 260, 140, 20);
/*      */     
/* 1858 */     TextSponsorNameExpenses.setBackground(new Color(255, 255, 153));
/* 1859 */     TextSponsorNameExpenses.setFont(new Font("Times New Roman", 1, 18));
/* 1860 */     TextSponsorNameExpenses.setHorizontalAlignment(4);
/* 1861 */     TextSponsorNameExpenses.setEnabled(false);
/* 1862 */     TextSponsorNameExpenses.setNextFocusableComponent(this.BoxRegestreType);
/* 1863 */     TextSponsorNameExpenses.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1865 */             GUEDisabled.this.TextSponsorNameExpensesKeyPressed(evt);
/*      */           }
/*      */         });
/* 1868 */     this.jPanel8.add(TextSponsorNameExpenses);
/* 1869 */     TextSponsorNameExpenses.setBounds(500, 290, 190, 40);
/*      */     
/* 1871 */     ButtonExpensesSend.setIcon(new ImageIcon(getClass().getResource("/images/Untitled - Copy.png")));
/* 1872 */     ButtonExpensesSend.setText("صرف");
/* 1873 */     ButtonExpensesSend.setEnabled(false);
/* 1874 */     ButtonExpensesSend.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1876 */             GUEDisabled.this.ButtonExpensesSendActionPerformed(evt);
/*      */           }
/*      */         });
/* 1879 */     this.jPanel8.add(ButtonExpensesSend);
/* 1880 */     ButtonExpensesSend.setBounds(810, 360, 210, 41);
/*      */     
/* 1882 */     this.jLabel69.setText("قيمة المبلغ المصروف :");
/* 1883 */     this.jPanel8.add(this.jLabel69);
/* 1884 */     this.jLabel69.setBounds(390, 250, 160, 30);
/*      */     
/* 1886 */     this.TextExpenseValue.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1888 */             GUEDisabled.this.TextExpenseValueKeyPressed(evt);
/*      */           }
/*      */         });
/* 1891 */     this.jPanel8.add(this.TextExpenseValue);
/* 1892 */     this.TextExpenseValue.setBounds(390, 290, 98, 41);
/*      */     
/* 1894 */     this.TextGranteeIDExpenses.setBackground(new Color(255, 255, 153));
/* 1895 */     this.TextGranteeIDExpenses.setEnabled(false);
/* 1896 */     this.jPanel8.add(this.TextGranteeIDExpenses);
/* 1897 */     this.TextGranteeIDExpenses.setBounds(960, 290, 90, 40);
/*      */     
/* 1899 */     this.jLabel70.setText("رقم المعاق :");
/* 1900 */     this.jPanel8.add(this.jLabel70);
/* 1901 */     this.jLabel70.setBounds(990, 250, 70, 30);
/*      */     
/* 1903 */     this.jLabel71.setText("اسم المعاق:");
/* 1904 */     this.jPanel8.add(this.jLabel71);
/* 1905 */     this.jLabel71.setBounds(800, 260, 150, 20);
/*      */     
/* 1907 */     this.TextGranteeNameExpenses.setBackground(new Color(255, 255, 153));
/* 1908 */     this.TextGranteeNameExpenses.setFont(new Font("Times New Roman", 1, 18));
/* 1909 */     this.TextGranteeNameExpenses.setHorizontalAlignment(4);
/* 1910 */     this.TextGranteeNameExpenses.setEnabled(false);
/* 1911 */     this.TextGranteeNameExpenses.setNextFocusableComponent(this.BoxRegestreType);
/* 1912 */     this.jPanel8.add(this.TextGranteeNameExpenses);
/* 1913 */     this.TextGranteeNameExpenses.setBounds(770, 290, 180, 40);
/*      */     
/* 1915 */     this.TableExpenses.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "طباعة فاتورة", "تحرير", "تاريخ الصرف", "المبلغ المصروف", "اسم المستلم", "الرقم" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1923 */     this.TableExpenses.setRowHeight(30);
/* 1924 */     this.jScrollPane10.setViewportView(this.TableExpenses);
/*      */     
/* 1926 */     this.jPanel8.add(this.jScrollPane10);
/* 1927 */     this.jScrollPane10.setBounds(90, 350, 680, 104);
/*      */     
/* 1929 */     this.TextRecipientName.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1931 */             GUEDisabled.this.TextRecipientNameKeyPressed(evt);
/*      */           }
/*      */         });
/* 1934 */     this.jPanel8.add(this.TextRecipientName);
/* 1935 */     this.TextRecipientName.setBounds(10, 290, 170, 41);
/*      */     
/* 1937 */     this.jLabel73.setText("اسم المستلم :");
/* 1938 */     this.jPanel8.add(this.jLabel73);
/* 1939 */     this.jLabel73.setBounds(40, 250, 140, 30);
/*      */     
/* 1941 */     this.ButtonReport1.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/* 1942 */     this.ButtonReport1.setText("تقرير بكامل مصروفات المعاق");
/* 1943 */     this.ButtonReport1.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1945 */             GUEDisabled.this.ButtonReport1ActionPerformed(evt);
/*      */           }
/*      */         });
/* 1948 */     this.jPanel8.add(this.ButtonReport1);
/* 1949 */     this.ButtonReport1.setBounds(190, 470, 520, 50);
/*      */     
/* 1951 */     this.jLabel75.setFont(new Font("Tahoma", 0, 18));
/* 1952 */     this.jLabel75.setText("أو");
/* 1953 */     this.jPanel8.add(this.jLabel75);
/* 1954 */     this.jLabel75.setBounds(132, 60, 40, 22);
/*      */     
/* 1956 */     this.jLabel40.setText("عام");
/* 1957 */     this.jPanel8.add(this.jLabel40);
/* 1958 */     this.jLabel40.setBounds(200, 260, 70, 15);
/*      */     
/* 1960 */     this.jLabel41.setText("شهر");
/* 1961 */     this.jPanel8.add(this.jLabel41);
/* 1962 */     this.jLabel41.setBounds(280, 260, 50, 15);
/*      */     
/* 1964 */     this.jLabel42.setText("يوم");
/* 1965 */     this.jPanel8.add(this.jLabel42);
/* 1966 */     this.jLabel42.setBounds(340, 260, 70, 15);
/*      */     
/* 1968 */     this.TextExpenseDay.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1970 */             GUEDisabled.this.TextExpenseDayKeyPressed(evt);
/*      */           }
/*      */         });
/* 1973 */     this.jPanel8.add(this.TextExpenseDay);
/* 1974 */     this.TextExpenseDay.setBounds(330, 290, 50, 40);
/*      */     
/* 1976 */     this.TextExpenseMonth.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1978 */             GUEDisabled.this.TextExpenseMonthKeyPressed(evt);
/*      */           }
/*      */         });
/* 1981 */     this.jPanel8.add(this.TextExpenseMonth);
/* 1982 */     this.TextExpenseMonth.setBounds(270, 290, 50, 40);
/*      */     
/* 1984 */     this.TextExpenseYear.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1986 */             GUEDisabled.this.TextExpenseYearKeyPressed(evt);
/*      */           }
/*      */         });
/* 1989 */     this.jPanel8.add(this.TextExpenseYear);
/* 1990 */     this.TextExpenseYear.setBounds(190, 290, 70, 40);
/*      */     
/* 1992 */     this.jLabel76.setText("ضع التاريخ رقمًا");
/* 1993 */     this.jPanel8.add(this.jLabel76);
/* 1994 */     this.jLabel76.setBounds(240, 230, 150, 30);
/*      */     
/* 1996 */     this.jTabbedPane1.addTab("المعاق والصرف", this.jPanel8);
/*      */     
/* 1998 */     this.home.setIcon(new ImageIcon(getClass().getResource("/images/home.png")));
/* 1999 */     this.home.setText("البداية");
/* 2000 */     this.home.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2002 */             GUEDisabled.this.homeActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2006 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 2007 */     getContentPane().setLayout(layout);
/* 2008 */     layout.setHorizontalGroup(layout
/* 2009 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2010 */         .addGroup(layout.createSequentialGroup()
/* 2011 */           .addContainerGap()
/* 2012 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 2013 */             .addComponent(this.jTabbedPane1, -2, 1069, -2)
/* 2014 */             .addComponent(this.home, -2, 191, -2))
/* 2015 */           .addContainerGap(-1, 32767)));
/*      */     
/* 2017 */     layout.setVerticalGroup(layout
/* 2018 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2019 */         .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 2020 */           .addContainerGap(-1, 32767)
/* 2021 */           .addComponent(this.jTabbedPane1, -2, 575, -2)
/* 2022 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2023 */           .addComponent(this.home, -2, 47, -2)
/* 2024 */           .addContainerGap()));
/*      */ 
/*      */     
/* 2027 */     pack();
/*      */   }
/*      */   
/*      */   private void TextDateBirthKeyPressed(KeyEvent evt) {
/* 2031 */     int key = evt.getKeyCode();
/* 2032 */     if (key == 10) {
/* 2033 */       this.textCityName.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void BoxRegestreTypeKeyPressed(KeyEvent evt) {
/* 2038 */     int key = evt.getKeyCode();
/* 2039 */     if (key == 10) {
/* 2040 */       this.TextRegestryID.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextRegestryIDKeyPressed(KeyEvent evt) {
/* 2045 */     int key = evt.getKeyCode();
/* 2046 */     if (key == 10) {
/* 2047 */       this.TextDateBirth.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextCrownGranteeKeyPressed(KeyEvent evt) {
/* 2052 */     int key = evt.getKeyCode();
/* 2053 */     if (key == 10) {
/* 2054 */       this.TextGranteeConnect.requestFocus();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonAddGranteeActionPerformed(ActionEvent evt) {
/* 2060 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2063 */       ChekCompletData chd = new ChekCompletData();
/* 2064 */       String[] IfEror = { "الرجاء إدخال اسم المعاق" };
/* 2065 */       String[] ChekTexts = { this.TextGranteeName.getText().trim() };
/* 2066 */       ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */       
/* 2068 */       String[] IfErorint = { "الرجاء إدخال عدد أفراد الأسرة رقمًا" };
/* 2069 */       String[] ChekNumbers = { this.TextFamilyCount.getText().trim() };
/* 2070 */       ArrayList<String> validInt = chd.ChekCompletDataNuumper(IfErorint, ChekNumbers);
/*      */       
/* 2072 */       if (valid.isEmpty() && validInt.isEmpty()) {
/* 2073 */         this
/*      */ 
/*      */           
/* 2076 */           .gran = new InfoGrantees(0, this.TextGranteeName.getText().trim(), this.BoxRegestreType.getSelectedItem().toString().trim(), this.TextRegestryID.getText().trim(), this.TextDateBirth.getText().trim(), this.textCityName.getText().trim(), this.TextCrownGrantee.getText().trim(), this.TextGranteeConnect.getText().trim(), this.TextAccountNumberAdd.getText().trim(), "", "", this.TextFamilyCount.getText().trim(), this.BoxFamilyStuts.getSelectedItem().toString().trim(), "2");
/* 2077 */         this.gran.AddGrantee();
/*      */         try {
/* 2079 */           String LastID = String.valueOf(this.gran.getLastID());
/* 2080 */           this.gran.AddTables(LastID);
/* 2081 */         } catch (Exception ex) {
/* 2082 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/*      */         
/* 2086 */         String eror = ""; int i;
/* 2087 */         for (i = 0; i < valid.size(); i++) {
/* 2088 */           eror = eror + (String)valid.get(i) + "<br>";
/*      */         }
/*      */ 
/*      */         
/* 2092 */         for (i = 0; i < validInt.size(); i++) {
/* 2093 */           eror = eror + (String)validInt.get(i) + "<br>";
/*      */         }
/*      */         
/* 2096 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2102 */       ShowGranteesTable();
/*      */     } finally {
/* 2104 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TextDateBirthEditKeyPressed(KeyEvent evt) {
/* 2109 */     int key = evt.getKeyCode();
/* 2110 */     if (key == 10) {
/* 2111 */       this.textCityNameEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void BoxRegestreTypeEditKeyPressed(KeyEvent evt) {
/* 2116 */     int key = evt.getKeyCode();
/* 2117 */     if (key == 10) {
/* 2118 */       this.TextRegestryIDEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextRegestryIDEditKeyPressed(KeyEvent evt) {
/* 2123 */     int key = evt.getKeyCode();
/* 2124 */     if (key == 10) {
/* 2125 */       this.TextDateBirthEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextGranteeNameEditKeyPressed(KeyEvent evt) {
/* 2130 */     int key = evt.getKeyCode();
/* 2131 */     if (key == 10) {
/* 2132 */       this.BoxRegestreTypeEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextCrownGranteeEditKeyPressed(KeyEvent evt) {
/* 2137 */     int key = evt.getKeyCode();
/* 2138 */     if (key == 10) {
/* 2139 */       this.TextGranteeConnectEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void ButtonEditGranteeActionPerformed(ActionEvent evt) {
/* 2144 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2147 */       ChekCompletData chd = new ChekCompletData();
/* 2148 */       String[] IfEror = { "الرجاء إدخال رقم المعاق بالضغط عليه في الجدول", "الرجاء إدخال اسم المعاق" };
/*      */       
/* 2150 */       String[] ChekTexts = { this.TextGranteeIDEdit.getText().trim(), this.TextGranteeNameEdit.getText().trim() };
/* 2151 */       ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */ 
/*      */       
/* 2154 */       if (valid.isEmpty()) {
/* 2155 */         this
/*      */ 
/*      */           
/* 2158 */           .gran = new InfoGrantees(Integer.valueOf(this.TextGranteeIDEdit.getText().trim()).intValue(), this.TextGranteeNameEdit.getText().trim(), this.BoxRegestreTypeEdit.getSelectedItem().toString().trim(), this.TextRegestryIDEdit.getText().trim(), this.TextDateBirthEdit.getText().trim(), this.textCityNameEdit.getText().trim(), this.TextCrownGranteeEdit.getText().trim(), this.TextGranteeConnectEdit.getText().trim(), this.TextAccountNumberEdit.getText().trim(), "", "", this.TextFamilyCountEdit.getText().trim(), this.BoxFamilyStutsEdit.getSelectedItem().toString().trim(), "");
/*      */         
/* 2160 */         this.spo = new InfoSponsors(0, this.TextGranteeIDEdit.getText().trim(), this.TextGranteeNameEdit.getText().trim(), "", "", "", "", "", "", "", "");
/*      */         
/* 2162 */         this.gran.GranteeUpdate();
/* 2163 */         this.spo.GranteeUpdateInSponsors();
/* 2164 */         ShowGranteesTable();
/* 2165 */         switch (this.WhatPress) {
/*      */           case 1:
/* 2167 */             ButtonGranteeSerchEditeActionPerformed(evt);
/*      */             break;
/*      */           case 2:
/* 2170 */             ButtonViwoEditeActionPerformed(evt);
/*      */             break;
/*      */         } 
/*      */       } else {
/* 2174 */         String eror = "";
/* 2175 */         for (int i = 0; i < valid.size(); i++) {
/* 2176 */           eror = eror + (String)valid.get(i) + "<br>";
/*      */         }
/*      */         
/* 2179 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2184 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonAddGrantee2ActionPerformed(ActionEvent evt) {
/* 2190 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2193 */       this.gran.GranteeDelete(this.TextGranteeIDDelet.getText().trim());
/* 2194 */       this.gran.DeleteTables(this.TextGranteeIDDelet.getText().trim());
/* 2195 */       ShowGranteesTable();
/* 2196 */       switch (this.WhatPress) {
/*      */         case 1:
/* 2198 */           ButtonGranteeSerchDeleteActionPerformed(evt);
/*      */           break;
/*      */         case 2:
/* 2201 */           ButtonViwoDeletActionPerformed(evt);
/*      */           break;
/*      */       } 
/* 2204 */       this.TextGranteeIDDelet.setText("");
/* 2205 */       this.TextGranteeNameDelet.setText("");
/*      */     } finally {
/* 2207 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void ButtonAddGranteeKeyPressed(KeyEvent evt) {
/* 2212 */     int key = evt.getKeyCode();
/* 2213 */     if (key == 10)
/*      */     {
/* 2215 */       this.TextGranteeName.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TableEditGranteeMousePressed(MouseEvent evt) {
/* 2220 */     OpenGUI(this.textsGranteeEdite, this.TextGranteeNameEdit, this.ButtonEditGrantee, this.MyWhite, true, true);
/*      */     
/* 2222 */     int yb = this.TableEditGrantee.getSelectedRow();
/* 2223 */     this.TextGranteeIDEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 10)));
/* 2224 */     this.TextGranteeNameEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 9)));
/* 2225 */     this.TextRegestryIDEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 7)));
/* 2226 */     this.TextDateBirthEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 6)));
/* 2227 */     this.textCityNameEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 5)));
/* 2228 */     this.TextCrownGranteeEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 4)));
/* 2229 */     this.TextGranteeConnectEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 3)));
/* 2230 */     this.TextAccountNumberEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 2)));
/* 2231 */     this.TextFamilyCountEdit.setText(String.valueOf(this.TableEditGrantee.getValueAt(yb, 1)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ButtonEditGranteeKeyPressed(KeyEvent evt) {
/* 2237 */     int key = evt.getKeyCode();
/* 2238 */     if (key == 10)
/*      */     {
/* 2240 */       this.TextGranteeNameEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextGranteeNameKeyPressed(KeyEvent evt) {
/* 2245 */     int key = evt.getKeyCode();
/* 2246 */     if (key == 10) {
/* 2247 */       this.BoxRegestreType.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextGranteeNameSercheKeyPressed(KeyEvent evt) {
/* 2252 */     int key = evt.getKeyCode();
/* 2253 */     if (key == 10) {
/* 2254 */       ButtonGranteeSerchActionPerformed((ActionEvent)null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonGranteeSerchActionPerformed(ActionEvent evt) {
/* 2260 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2263 */       if (!this.TextGranteeNameSerche.getText().trim().equals("")) {
/* 2264 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSerchGrantee, this.SerchAddColomonsNames2);
/* 2265 */         this.TableSerchGrantee = (new TablesSeting()).ColomonSize(this.TableSerchGrantee, this.SerchColomonsSize2);
/* 2266 */         this.TableSerchGrantee.getColumnModel().getColumn(2).setCellRenderer(new ClientsTableButtonRendererAdd());
/* 2267 */         this.TableSerchGrantee.getColumnModel().getColumn(2).setCellEditor(new ClientsTableRendererAdd(new JCheckBox()));
/* 2268 */         TextGranteeIDSercheAdd.setText("");
/* 2269 */         TextGranteeNameSercheAdd.setText("");
/* 2270 */         CloseGUI(this.textsAddSponsor, ButtonAddSponsor, this.MyGray, false);
/* 2271 */         this.WhatPress = 1;
/*      */         try {
/* 2273 */           this.grantee = this.gran.getGrantee(this.TextGranteeNameSerche.getText().trim(), this.ser.stringSe(this.nTableGrantees, this.nColomnGrantees3, new String[] { this.TextGranteeNameSerche.getText().trim(), this.BoxFamilyStutsSerch.getSelectedItem().toString().trim() }), "2");
/* 2274 */           for (int i = 0; i < this.grantee.size(); i++) {
/* 2275 */             Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), "إضغط لإضافة كفيل", ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2276 */             dtm.addRow(ary);
/*      */           }
/*      */         
/* 2279 */         } catch (Exception ex) {
/* 2280 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 2283 */         String eror = "الرجاء إدخال كلمة البحث";
/* 2284 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2289 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TextGranteeConnectKeyPressed(KeyEvent evt) {
/* 2294 */     int key = evt.getKeyCode();
/* 2295 */     if (key == 10) {
/* 2296 */       this.TextAccountNumberAdd.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextGranteeConnectEditKeyPressed(KeyEvent evt) {
/* 2301 */     int key = evt.getKeyCode();
/* 2302 */     if (key == 10) {
/* 2303 */       this.TextAccountNumberEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void ButtonAddSponsorActionPerformed(ActionEvent evt) {
/* 2308 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2311 */       ChekCompletData chd = new ChekCompletData();
/* 2312 */       String[] IfEror = { "الرجاء إدخال اسم اختيار المعاق بالنقر على الجدول", "الرجاء إدخال اسم الكفيل" };
/*      */       
/* 2314 */       String[] ChekTexts = { TextGranteeNameSercheAdd.getText().trim(), TextSponsorNameAdd.getText().trim() };
/* 2315 */       ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */ 
/*      */       
/* 2318 */       if (valid.isEmpty()) {
/* 2319 */         this
/*      */           
/* 2321 */           .spo = new InfoSponsors(0, TextGranteeIDSercheAdd.getText().trim(), TextGranteeNameSercheAdd.getText().trim(), TextSponsorNameAdd.getText().trim(), TextSponsorDateAdd.getText().trim(), TextContactSponsorAdd.getText().trim(), TextSponsorValueAdd.getText().trim(), TextRegestrySponsorAdd.getText().trim(), TextAccountNumberSponsorAdd.getText().trim(), "", "2");
/* 2322 */         this.spo.AddSponsors();
/* 2323 */         this.spo.SendSponsorToGranteesTable();
/* 2324 */         this.spo.AddSponsorToNamesSponsorGrantee();
/*      */         
/* 2326 */         TextGranteeIDSercheAdd.setText("");
/* 2327 */         TextGranteeNameSercheAdd.setText("");
/* 2328 */         CloseGUI(this.textsAddSponsor, ButtonAddSponsor, this.MyGray, false);
/* 2329 */         switch (this.WhatPress) {
/*      */           case 1:
/* 2331 */             ButtonGranteeSerchActionPerformed(evt);
/*      */             break;
/*      */           case 2:
/* 2334 */             ButtonViwoAddActionPerformed(evt);
/*      */             break;
/*      */         } 
/*      */       } else {
/* 2338 */         String eror = "";
/* 2339 */         for (int i = 0; i < valid.size(); i++) {
/* 2340 */           eror = eror + (String)valid.get(i) + "<br>";
/*      */         }
/*      */         
/* 2343 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       } 
/*      */ 
/*      */       
/* 2347 */       TextSponsorNameAdd.requestFocus();
/*      */     } finally {
/* 2349 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TextAccountNumberEditKeyPressed(KeyEvent evt) {
/* 2354 */     int key = evt.getKeyCode();
/* 2355 */     if (key == 10) {
/* 2356 */       this.ButtonEditGrantee.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextAccountNumberAddKeyPressed(KeyEvent evt) {
/* 2361 */     int key = evt.getKeyCode();
/* 2362 */     if (key == 10) {
/* 2363 */       this.ButtonAddGrantee.requestFocus();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonViwoAddActionPerformed(ActionEvent evt) {
/* 2369 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2372 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSerchGrantee, this.SerchAddColomonsNames2);
/* 2373 */       this.TableSerchGrantee = (new TablesSeting()).ColomonSize(this.TableSerchGrantee, this.SerchColomonsSize2);
/* 2374 */       this.TableSerchGrantee.getColumnModel().getColumn(2).setCellRenderer(new ClientsTableButtonRendererAdd());
/* 2375 */       this.TableSerchGrantee.getColumnModel().getColumn(2).setCellEditor(new ClientsTableRendererAdd(new JCheckBox()));
/* 2376 */       TextGranteeIDSercheAdd.setText("");
/* 2377 */       TextGranteeNameSercheAdd.setText("");
/* 2378 */       CloseGUI(this.textsAddSponsor, ButtonAddSponsor, this.MyGray, false);
/* 2379 */       this.WhatPress = 2;
/*      */       try {
/* 2381 */         this.grantee = this.gran.getAllGrantees("2");
/* 2382 */         for (int i = 0; i < this.grantee.size(); i++) {
/* 2383 */           Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), "إضغط لإضافة كفيل", ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2384 */           dtm.addRow(ary);
/*      */         }
/*      */       
/* 2387 */       } catch (Exception ex) {
/* 2388 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 2391 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TextSponsorNameAddKeyPressed(KeyEvent evt) {
/* 2396 */     int key = evt.getKeyCode();
/* 2397 */     if (key == 10) {
/* 2398 */       TextSponsorDateAdd.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextSponsorDateAddKeyPressed(KeyEvent evt) {
/* 2403 */     int key = evt.getKeyCode();
/* 2404 */     if (key == 10) {
/* 2405 */       TextContactSponsorAdd.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextContactSponsorAddKeyPressed(KeyEvent evt) {
/* 2410 */     int key = evt.getKeyCode();
/* 2411 */     if (key == 10) {
/* 2412 */       TextSponsorValueAdd.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextRegestrySponsorAddKeyPressed(KeyEvent evt) {
/* 2417 */     int key = evt.getKeyCode();
/* 2418 */     if (key == 10) {
/* 2419 */       TextAccountNumberSponsorAdd.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextAccountNumberSponsorAddKeyPressed(KeyEvent evt) {
/* 2424 */     int key = evt.getKeyCode();
/* 2425 */     if (key == 10) {
/* 2426 */       ButtonAddSponsor.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void ButtonAddSponsorKeyPressed(KeyEvent evt) {
/* 2431 */     int key = evt.getKeyCode();
/* 2432 */     if (key == 10)
/*      */     {
/* 2434 */       this.TextGranteeNameSerche.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextSponsorValueAddKeyPressed(KeyEvent evt) {
/* 2439 */     int key = evt.getKeyCode();
/* 2440 */     if (key == 10) {
/* 2441 */       TextRegestrySponsorAdd.requestFocus();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonViwoStopActionPerformed(ActionEvent evt) {
/* 2447 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2450 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSerchGranteeStop, this.SerchStopColomonsNames);
/* 2451 */       this.TableSerchGranteeStop = (new TablesSeting()).ColomonSize(this.TableSerchGranteeStop, this.SerchColomonsSize);
/* 2452 */       this.TableSerchGranteeStop.getColumnModel().getColumn(2).setCellRenderer(new ClientsTableButtonRendererStop());
/* 2453 */       this.TableSerchGranteeStop.getColumnModel().getColumn(2).setCellEditor(new ClientsTableRendererStop(new JCheckBox()));
/* 2454 */       CloseGUI(this.textsStopSponsor, ButtonStopSponsor, this.MyYellow, false);
/* 2455 */       this.WhatPress = 2;
/*      */       try {
/* 2457 */         this.grantee = this.gran.getAllGrantees("2");
/* 2458 */         for (int i = 0; i < this.grantee.size(); i++) {
/* 2459 */           Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), "إضغط لإيقاف هذه الكفالة", ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2460 */           dtm.addRow(ary);
/*      */         }
/*      */       
/* 2463 */       } catch (Exception ex) {
/* 2464 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 2467 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonGranteeSerchStopActionPerformed(ActionEvent evt) {
/* 2473 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2476 */       if (!TextGranteeNameSercheStop2.getText().trim().equals("")) {
/* 2477 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSerchGranteeStop, this.SerchStopColomonsNames);
/* 2478 */         this.TableSerchGranteeStop = (new TablesSeting()).ColomonSize(this.TableSerchGranteeStop, this.SerchColomonsSize);
/* 2479 */         this.TableSerchGranteeStop.getColumnModel().getColumn(2).setCellRenderer(new ClientsTableButtonRendererStop());
/* 2480 */         this.TableSerchGranteeStop.getColumnModel().getColumn(2).setCellEditor(new ClientsTableRendererStop(new JCheckBox()));
/* 2481 */         CloseGUI(this.textsStopSponsor, ButtonStopSponsor, this.MyYellow, false);
/* 2482 */         this.WhatPress = 1;
/*      */         try {
/* 2484 */           this.grantee = this.gran.getGrantee(TextGranteeNameSercheStop2.getText().trim(), this.ser.stringSe(this.nTableGrantees, this.nColomnGrantees, new String[] { TextGranteeNameSercheStop2.getText().trim() }), "2");
/* 2485 */           for (int i = 0; i < this.grantee.size(); i++) {
/* 2486 */             Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), "إضغط لإيقاف هذه الكفالة", ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2487 */             dtm.addRow(ary);
/*      */           }
/*      */         
/* 2490 */         } catch (Exception ex) {
/* 2491 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 2494 */         String eror = "الرجاء إدخال كلمة البحث";
/* 2495 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2500 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TextGranteeNameSercheStop2KeyPressed(KeyEvent evt) {
/* 2505 */     int key = evt.getKeyCode();
/* 2506 */     if (key == 10) {
/* 2507 */       ButtonGranteeSerchStopActionPerformed((ActionEvent)null);
/*      */     }
/*      */   }
/*      */   
/*      */   private void ButtonStopSponsorActionPerformed(ActionEvent evt) {
/* 2512 */     setCursor(new Cursor(3));
/*      */     try {
/* 2514 */       String eror = "هل أنت متأكد من إيقاف كفالة هذا المعاق";
/* 2515 */       int reply = (new MessageInfo()).getSelectMessage(eror, "  خطأ");
/*      */ 
/*      */ 
/*      */       
/* 2519 */       if (reply == 0) {
/* 2520 */         this.spo = new InfoSponsors(0, TextGranteeIDSercheStop.getText().trim(), "", "", "", "", "", "", "", "", "");
/* 2521 */         this.spo.RemoveSponsorInGranteesTable();
/*      */         
/* 2523 */         this.gran.DeleteTables(TextGranteeIDSercheStop.getText().trim());
/* 2524 */         this.gran.AddTables(TextGranteeIDSercheStop.getText().trim());
/* 2525 */         CloseGUI(this.textsStopSponsor, ButtonStopSponsor, this.MyYellow, false);
/* 2526 */         switch (this.WhatPress) {
/*      */           case 1:
/* 2528 */             ButtonGranteeSerchStopActionPerformed(evt);
/*      */             break;
/*      */           case 2:
/* 2531 */             ButtonViwoStopActionPerformed(evt);
/*      */             break;
/*      */         } 
/*      */         
/* 2535 */         TextGranteeNameSercheStop2.requestFocus();
/* 2536 */         setCursor(new Cursor(0));
/*      */       } else {
/* 2538 */         JOptionPane.showMessageDialog(null, "GOODBYE");
/*      */       } 
/*      */     } finally {
/* 2541 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextSponsorNameStopKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void jTabbedPane1MouseClicked(MouseEvent evt) {
/* 2552 */     switch (this.jTabbedPane1.getSelectedIndex()) {
/*      */       case 0:
/* 2554 */         if (this.sel != 0) {
/* 2555 */           replaceTablesAndTexts();
/* 2556 */           this.sel = 0;
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 2560 */         if (this.sel != 1) {
/* 2561 */           replaceTablesAndTexts();
/* 2562 */           this.sel = 1;
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 2566 */         if (this.sel != 2) {
/* 2567 */           replaceTablesAndTexts();
/* 2568 */           this.sel = 2;
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 2572 */         if (this.sel != 3) {
/* 2573 */           replaceTablesAndTexts();
/* 2574 */           this.sel = 3;
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 2578 */         if (this.sel != 4) {
/* 2579 */           replaceTablesAndTexts();
/* 2580 */           this.sel = 4;
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 2584 */         if (this.sel != 5) {
/* 2585 */           replaceTablesAndTexts();
/* 2586 */           this.sel = 5;
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 2590 */         if (this.sel != 6) {
/* 2591 */           replaceTablesAndTexts();
/* 2592 */           this.sel = 6;
/*      */         } 
/*      */         return;
/*      */       case 7:
/* 2596 */         if (this.sel != 7) {
/* 2597 */           replaceTablesAndTexts();
/* 2598 */           this.sel = 7;
/*      */         } 
/*      */         return;
/*      */     } 
/* 2602 */     this.sel = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ButtonViwoEditeActionPerformed(ActionEvent evt) {
/* 2610 */     setCursor(new Cursor(3));
/*      */ 
/*      */     
/*      */     try {
/* 2614 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableEditGrantee, this.ColomonsNames);
/* 2615 */       this.TableEditGrantee = (new TablesSeting()).ColomonSize(this.TableEditGrantee, this.ColomonsSize);
/*      */       
/* 2617 */       CloseGUI(this.textsGranteeEdite, this.ButtonEditGrantee, this.MyGray, false);
/* 2618 */       this.TextGranteeIDEdit.setText("");
/* 2619 */       this.WhatPress = 2;
/*      */       try {
/* 2621 */         this.grantee = this.gran.getAllGrantees("2");
/* 2622 */         for (int i = 0; i < this.grantee.size(); i++) {
/*      */           
/* 2624 */           Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getGranteeAccount(), ((InfoGrantees)this.grantee.get(i)).getGranteeConnect(), ((InfoGrantees)this.grantee.get(i)).getCrownGrantee(), ((InfoGrantees)this.grantee.get(i)).getCityName(), ((InfoGrantees)this.grantee.get(i)).getDateBirth(), ((InfoGrantees)this.grantee.get(i)).getRegestryID(), ((InfoGrantees)this.grantee.get(i)).getRegestryType(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/*      */           
/* 2626 */           dtm.addRow(ary);
/*      */         } 
/* 2628 */       } catch (Exception ex) {
/* 2629 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 2632 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonGranteeSerchEditeActionPerformed(ActionEvent evt) {
/* 2638 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2641 */       if (!this.TextNameSercheEdite.getText().trim().equals("")) {
/* 2642 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableEditGrantee, this.ColomonsNames);
/* 2643 */         this.TableEditGrantee = (new TablesSeting()).ColomonSize(this.TableEditGrantee, this.ColomonsSize);
/* 2644 */         CloseGUI(this.textsGranteeEdite, this.ButtonEditGrantee, this.MyGray, false);
/* 2645 */         this.WhatPress = 1;
/*      */         try {
/* 2647 */           this.grantee = this.gran.getGrantee(this.TextNameSercheEdite.getText().trim(), this.ser.stringSe(this.nTableGrantees, this.nColomnGrantees, new String[] { this.TextNameSercheEdite.getText().trim() }), "2");
/* 2648 */           for (int i = 0; i < this.grantee.size(); i++)
/*      */           {
/* 2650 */             Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getGranteeAccount(), ((InfoGrantees)this.grantee.get(i)).getGranteeConnect(), ((InfoGrantees)this.grantee.get(i)).getCrownGrantee(), ((InfoGrantees)this.grantee.get(i)).getCityName(), ((InfoGrantees)this.grantee.get(i)).getDateBirth(), ((InfoGrantees)this.grantee.get(i)).getRegestryID(), ((InfoGrantees)this.grantee.get(i)).getRegestryType(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/*      */             
/* 2652 */             dtm.addRow(ary);
/*      */           }
/*      */         
/* 2655 */         } catch (Exception ex) {
/* 2656 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 2659 */         String eror = "الرجاء إدخال كلمة البحث";
/* 2660 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2665 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextNameSercheEditeKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextGranteeNameInSponsorsKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void ButtongetAllSPActionPerformed(ActionEvent evt) {
/* 2679 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2682 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSponsorsPayment, this.ColomonsSponsorsPaymentNames);
/* 2683 */       this.TableSponsorsPayment = (new TablesSeting()).ColomonSize(this.TableSponsorsPayment, this.SponsorsPaymentSize);
/* 2684 */       this.TableSponsorsPayment.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererMainPayment());
/* 2685 */       this.TableSponsorsPayment.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererMainPayment(new JCheckBox()));
/* 2686 */       CloseGUI(this.textsPayment, ButtonPaymentSend, this.MyYellow, false);
/* 2687 */       RemoveTable(this.TablePayment, this.TablePaymentColomonsNames);
/* 2688 */       this.WhatPress = 2;
/*      */       try {
/* 2690 */         InfoSponsors spo22 = new InfoSponsors();
/* 2691 */         spo22.setType("2");
/* 2692 */         this.sponsors = spo22.getAllSponsors();
/* 2693 */         for (int i = 0; i < this.sponsors.size(); i++) {
/* 2694 */           Object[] ary = { "إضغط لدفع مبلغ", ((InfoSponsors)this.sponsors.get(i)).getGranteesName(), ((InfoSponsors)this.sponsors.get(i)).getIDGrantees(), ((InfoSponsors)this.sponsors.get(i)).getSponsorsName(), Integer.valueOf(((InfoSponsors)this.sponsors.get(i)).getId()) };
/* 2695 */           dtm.addRow(ary);
/*      */         }
/*      */       
/* 2698 */       } catch (Exception ex) {
/* 2699 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 2702 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void ButtonSerchSPActionPerformed(ActionEvent evt) {
/* 2707 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2710 */       if (!TextSponsorNameMain.getText().trim().equals("")) {
/* 2711 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableSponsorsPayment, this.ColomonsSponsorsPaymentNames);
/* 2712 */         this.TableSponsorsPayment = (new TablesSeting()).ColomonSize(this.TableSponsorsPayment, this.SponsorsPaymentSize);
/* 2713 */         this.TableSponsorsPayment.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererMainPayment());
/* 2714 */         this.TableSponsorsPayment.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererMainPayment(new JCheckBox()));
/*      */ 
/*      */         
/* 2717 */         CloseGUI(this.textsPayment, ButtonPaymentSend, this.MyYellow, false);
/* 2718 */         RemoveTable(this.TablePayment, this.TablePaymentColomonsNames);
/* 2719 */         this.WhatPress = 1;
/*      */         try {
/* 2721 */           this.sponsors = this.spo.getSponsor(TextSponsorNameMain.getText().trim(), this.ser.stringSe(this.nTableSponsors, this.nColomnSponsors, new String[] { TextSponsorNameMain.getText().trim(), TextContactSponsorMain.getText().trim(), TextRegestrySponsorMain.getText().trim(), this.TextGranteeNameInSponsors.getText().trim() }), "2");
/*      */           
/* 2723 */           for (int i = 0; i < this.sponsors.size(); i++) {
/* 2724 */             Object[] ary = { "إضغط لدفع مبلغ", ((InfoSponsors)this.sponsors.get(i)).getGranteesName(), ((InfoSponsors)this.sponsors.get(i)).getIDGrantees(), ((InfoSponsors)this.sponsors.get(i)).getSponsorsName(), Integer.valueOf(((InfoSponsors)this.sponsors.get(i)).getId()) };
/* 2725 */             dtm.addRow(ary);
/*      */           } 
/* 2727 */         } catch (Exception ex) {
/* 2728 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 2731 */         String eror = "الرجاء إدخال كلمة البحث";
/* 2732 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2737 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextRegestrySponsorMainKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextContactSponsorMainKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextSponsorNameMainKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextSponsorNamePaymentKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void ButtonPaymentSendActionPerformed(ActionEvent evt) {
/* 2759 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2762 */       ChekCompletData chd = new ChekCompletData();
/* 2763 */       String[] IfEror = { "الرجاء إدخال قيمة الدفع" };
/* 2764 */       String[] ChekTexts = { this.TextPaymentValue.getText().trim() };
/* 2765 */       ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */       
/* 2767 */       String[] IfErorint = { "أدخل اليوم رقمًا", "أدخل الشهر رقمًا", "أدخل العام رقمًا" };
/* 2768 */       String[] ChekNumbers = { this.TextPaymentDay.getText().trim(), this.TextPaymentMonth.getText().trim(), this.TextPaymentYear.getText().trim() };
/* 2769 */       ArrayList<String> validInt = chd.ChekCompletDataNuumper(IfErorint, ChekNumbers);
/*      */       
/* 2771 */       if (valid.isEmpty() && validInt.isEmpty()) {
/* 2772 */         this
/*      */           
/* 2774 */           .pay = new InfoPayment(0, this.TextGranteeIDPayment.getText().trim(), this.TextGranteeNamePayment.getText().trim(), TextSponsorNOPayment.getText().trim(), TextSponsorNamePayment.getText().trim(), Integer.valueOf(this.TextPaymentDay.getText().trim()).intValue(), Integer.valueOf(this.TextPaymentMonth.getText().trim()).intValue(), Integer.valueOf(this.TextPaymentYear.getText().trim()).intValue(), this.TextPaymentValue.getText().trim(), "", "2", "");
/* 2775 */         this.pay.AddPayment();
/* 2776 */         String LastID = String.valueOf(this.pay.getLastID());
/*      */         
/* 2778 */         this.pay.setGPID("GranteePayments" + this.TextGranteeIDPayment.getText().trim() + "_" + LastID);
/* 2779 */         this.pay.AddPublicPayment();
/* 2780 */         ShowPayments();
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2787 */         String eror = ""; int i;
/* 2788 */         for (i = 0; i < valid.size(); i++) {
/* 2789 */           eror = eror + (String)valid.get(i) + "<br>";
/*      */         }
/*      */         
/* 2792 */         for (i = 0; i < validInt.size(); i++) {
/* 2793 */           eror = eror + (String)validInt.get(i) + "<br>";
/*      */         }
/*      */         
/* 2796 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 2802 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextSponsorNameMainExpensesKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextContactGranteeMainKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void TextRegestryGranteeMainKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void ButtonSerchGEActionPerformed(ActionEvent evt) {
/* 2819 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2822 */       if (!this.TextGranteeNameInExpenses.getText().trim().equals("")) {
/* 2823 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableGranteeExpenses, this.ColomonsGranteesExpenseNames);
/* 2824 */         this.TableGranteeExpenses = (new TablesSeting()).ColomonSize(this.TableGranteeExpenses, this.SponsorsExpenseSize);
/* 2825 */         this.TableGranteeExpenses.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererMainExpenses());
/* 2826 */         this.TableGranteeExpenses.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererMainExpenses(new JCheckBox()));
/*      */ 
/*      */         
/* 2829 */         CloseGUI(this.textsExpenses, ButtonExpensesSend, this.MyYellow, false);
/* 2830 */         RemoveTable(this.TableExpenses, this.TableExpensesColomonsNames);
/* 2831 */         this.WhatPress = 1;
/*      */         try {
/* 2833 */           this.grantee = this.gran.getGrantee(this.TextGranteeNameInExpenses
/* 2834 */               .getText().trim(), this.ser.stringSe(this.nTableGrantees, this.nColomnGrantees2, new String[] { this.TextGranteeNameInExpenses.getText().trim(), TextContactGranteeMain
/* 2835 */                   .getText().trim(), TextRegestryGranteeMain
/* 2836 */                   .getText().trim(), TextSponsorNameMainExpenses
/* 2837 */                   .getText().trim() }), "2");
/*      */ 
/*      */ 
/*      */           
/* 2841 */           for (int i = 0; i < this.grantee.size(); i++) {
/* 2842 */             Object[] ary = { "إضغط لصرف مبلغ", ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2843 */             dtm.addRow(ary);
/*      */           } 
/* 2845 */         } catch (Exception ex) {
/* 2846 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 2849 */         String eror = "الرجاء إدخال كلمة البحث";
/* 2850 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2855 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void ButtongetAllGEActionPerformed(ActionEvent evt) {
/* 2860 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2863 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableGranteeExpenses, this.ColomonsGranteesExpenseNames);
/* 2864 */       this.TableGranteeExpenses = (new TablesSeting()).ColomonSize(this.TableGranteeExpenses, this.SponsorsExpenseSize);
/* 2865 */       this.TableGranteeExpenses.getColumnModel().getColumn(0).setCellRenderer(new ClientsTableButtonRendererMainExpenses());
/* 2866 */       this.TableGranteeExpenses.getColumnModel().getColumn(0).setCellEditor(new ClientsTableRendererMainExpenses(new JCheckBox()));
/* 2867 */       CloseGUI(this.textsExpenses, ButtonExpensesSend, this.MyYellow, false);
/* 2868 */       RemoveTable(this.TableExpenses, this.TableExpensesColomonsNames);
/* 2869 */       this.WhatPress = 2;
/*      */       try {
/* 2871 */         this.grantee = this.gran.getAllGrantees("2");
/* 2872 */         for (int i = 0; i < this.grantee.size(); i++) {
/* 2873 */           Object[] ary = { "إضغط لصرف مبلغ", ((InfoGrantees)this.grantee.get(i)).getSponsorsName(), ((InfoGrantees)this.grantee.get(i)).getSponsorsID(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/* 2874 */           dtm.addRow(ary);
/*      */         }
/*      */       
/* 2877 */       } catch (Exception ex) {
/* 2878 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 2881 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextGranteeNameInExpensesKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void TextSponsorNameExpensesKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void ButtonExpensesSendActionPerformed(ActionEvent evt) {
/* 2894 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2897 */       ChekCompletData chd = new ChekCompletData();
/* 2898 */       String[] IfEror = { "الرجاء إدخال قيمة المبلغ المصروف", "الرجاء إدخال اسم المستلم" };
/* 2899 */       String[] ChekTexts = { this.TextExpenseValue.getText().trim(), this.TextRecipientName.getText().trim() };
/* 2900 */       ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */       
/* 2902 */       String[] IfErorint = { "أدخل اليوم رقمًا", "أدخل الشهر رقمًا", "أدخل العام رقمًا" };
/* 2903 */       String[] ChekNumbers = { this.TextExpenseDay.getText().trim(), this.TextExpenseMonth.getText().trim(), this.TextExpenseYear.getText().trim() };
/* 2904 */       ArrayList<String> validInt = chd.ChekCompletDataNuumper(IfErorint, ChekNumbers);
/*      */       
/* 2906 */       if (valid.isEmpty() && validInt.isEmpty()) {
/* 2907 */         this.expe1 = new InfoExpense(0, this.TextGranteeIDExpenses.getText().trim(), this.TextGranteeNameExpenses.getText().trim(), TextSponsorNameExpenses.getText().trim(), Integer.valueOf(this.TextExpenseDay.getText().trim()).intValue(), Integer.valueOf(this.TextExpenseMonth.getText().trim()).intValue(), Integer.valueOf(this.TextExpenseYear.getText().trim()).intValue(), this.TextExpenseValue.getText().trim(), this.TextRecipientName.getText().trim(), "", "2", "", 0);
/* 2908 */         this.expe1.AddExpense();
/* 2909 */         String LastID = String.valueOf(this.expe1.getLastID());
/* 2910 */         String FStuts = String.valueOf(this.expe1.getFStuts());
/* 2911 */         int FCunt = Integer.valueOf(this.expe1.getFCount()).intValue();
/*      */         
/* 2913 */         this.expe1.setFamilyStuets(FStuts);
/* 2914 */         this.expe1.setFamilyCount(FCunt);
/* 2915 */         this.expe1.setGPID("GranteeExpenses" + this.TextGranteeIDExpenses.getText().trim() + "_" + LastID);
/* 2916 */         this.expe1.AddPublicExpenses();
/* 2917 */         ShowExpenses();
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2924 */         String eror = ""; int i;
/* 2925 */         for (i = 0; i < valid.size(); i++) {
/* 2926 */           eror = eror + (String)valid.get(i) + "<br>";
/*      */         }
/*      */         
/* 2929 */         for (i = 0; i < validInt.size(); i++) {
/* 2930 */           eror = eror + (String)validInt.get(i) + "<br>";
/*      */         }
/* 2932 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 2938 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void textCityNameEditKeyPressed(KeyEvent evt) {
/* 2944 */     int key = evt.getKeyCode();
/* 2945 */     if (key == 10) {
/* 2946 */       this.TextCrownGranteeEdit.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void textCityNameKeyPressed(KeyEvent evt) {
/* 2951 */     int key = evt.getKeyCode();
/* 2952 */     if (key == 10) {
/* 2953 */       this.TextCrownGrantee.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void ButtonReportActionPerformed(ActionEvent evt) {
/* 2958 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 2961 */       ArrayList<InfoPayment> pr = new ArrayList<>();
/*      */ 
/*      */       
/* 2964 */       for (int i = 0; i < this.TablePayment.getRowCount(); i++) {
/* 2965 */         InfoPayment pymR = new InfoPayment();
/* 2966 */         if (this.TextGranteeNamePayment.getText() != null && !"".equals(this.TextGranteeNamePayment.getText().trim())) {
/* 2967 */           pymR.setGranteesName(this.TextGranteeNamePayment.getText().trim());
/*      */         } else {
/* 2969 */           pymR.setGranteesName("");
/*      */         } 
/* 2971 */         if (this.TablePayment.getValueAt(i, 5) != null && !"".equals(this.TablePayment.getValueAt(i, 5).toString().trim())) {
/* 2972 */           pymR.setId(Integer.valueOf(this.TablePayment.getValueAt(i, 5).toString().trim()).intValue());
/*      */         } else {
/* 2974 */           pymR.setId(0);
/*      */         } 
/* 2976 */         if (this.TablePayment.getValueAt(i, 4) != null && !"".equals(this.TablePayment.getValueAt(i, 4).toString().trim())) {
/* 2977 */           pymR.setSponsorsName(this.TablePayment.getValueAt(i, 4).toString().trim());
/*      */         } else {
/* 2979 */           pymR.setSponsorsName("");
/*      */         } 
/* 2981 */         if (this.TablePayment.getValueAt(i, 3) != null && !"".equals(this.TablePayment.getValueAt(i, 3).toString().trim())) {
/* 2982 */           pymR.setValuePayment(this.TablePayment.getValueAt(i, 3).toString().trim());
/*      */         } else {
/* 2984 */           pymR.setValuePayment("");
/*      */         } 
/* 2986 */         if (this.TablePayment.getValueAt(i, 2) != null && !"".equals(this.TablePayment.getValueAt(i, 2).toString().trim())) {
/* 2987 */           pymR.setDatePayment(this.TablePayment.getValueAt(i, 2).toString().trim());
/*      */         } else {
/* 2989 */           pymR.setDatePayment("");
/*      */         } 
/* 2991 */         pr.add(pymR);
/*      */       } 
/* 2993 */       if (!pr.isEmpty()) {
/* 2994 */         ReportsManager.getInstance().showReport("Reports/Disabled/AllPaymentReport.jasper", new Hashtable<>(), "مدفوعات الكفيل", pr);
/*      */       }
/*      */     } finally {
/* 2997 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 3002 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 3005 */       ArrayList<InfoGrantees> io = new ArrayList<>();
/*      */ 
/*      */       
/* 3008 */       for (int i = 0; i < this.TableEditGrantee.getRowCount(); i++) {
/* 3009 */         InfoGrantees setIO = new InfoGrantees();
/* 3010 */         if (this.TableEditGrantee.getValueAt(i, 10) != null && !"".equals(this.TableEditGrantee.getValueAt(i, 10).toString().trim())) {
/* 3011 */           setIO.setId(Integer.valueOf(this.TableEditGrantee.getValueAt(i, 10).toString().trim()).intValue());
/*      */         } else {
/* 3013 */           setIO.setId(0);
/*      */         } 
/* 3015 */         if (this.TableEditGrantee.getValueAt(i, 9) != null && !"".equals(this.TableEditGrantee.getValueAt(i, 9).toString().trim())) {
/* 3016 */           setIO.setGranteeName(this.TableEditGrantee.getValueAt(i, 9).toString().trim());
/*      */         } else {
/* 3018 */           setIO.setGranteeName("");
/*      */         } 
/* 3020 */         if (this.TableEditGrantee.getValueAt(i, 6) != null && !"".equals(this.TableEditGrantee.getValueAt(i, 6).toString().trim())) {
/* 3021 */           setIO.setDateBirth(this.TableEditGrantee.getValueAt(i, 6).toString().trim());
/*      */         } else {
/* 3023 */           setIO.setDateBirth("");
/*      */         } 
/* 3025 */         if (this.TableEditGrantee.getValueAt(i, 4) != null && !"".equals(this.TableEditGrantee.getValueAt(i, 4).toString().trim())) {
/* 3026 */           setIO.setCrownGrantee(this.TableEditGrantee.getValueAt(i, 4).toString().trim());
/*      */         } else {
/* 3028 */           setIO.setCrownGrantee("");
/*      */         } 
/*      */         
/* 3031 */         io.add(setIO);
/*      */       } 
/*      */       
/* 3034 */       if (!io.isEmpty()) {
/* 3035 */         ReportsManager.getInstance().showReport("Reports/Disabled/GranteesReport.jasper", new Hashtable<>(), "قسم الأيتام", io);
/*      */       }
/*      */     } finally {
/* 3038 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 3044 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 3047 */       ArrayList<InfoSponsors> is = new ArrayList<>();
/*      */ 
/*      */       
/* 3050 */       for (int i = 0; i < this.TableSerchGrantee.getRowCount(); i++) {
/* 3051 */         InfoSponsors setIS = new InfoSponsors();
/* 3052 */         if (this.TableSerchGrantee.getValueAt(i, 6) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 6).toString().trim())) {
/* 3053 */           setIS.setIDGrantees(this.TableSerchGrantee.getValueAt(i, 6).toString().trim());
/*      */         } else {
/* 3055 */           setIS.setIDGrantees("");
/*      */         } 
/* 3057 */         if (this.TableSerchGrantee.getValueAt(i, 5) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 5).toString().trim())) {
/* 3058 */           setIS.setGranteesName(this.TableSerchGrantee.getValueAt(i, 5).toString().trim());
/*      */         } else {
/* 3060 */           setIS.setGranteesName("");
/*      */         } 
/* 3062 */         if (this.TableSerchGrantee.getValueAt(i, 4) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 4).toString().trim())) {
/* 3063 */           setIS.setFamilyStuets(this.TableSerchGrantee.getValueAt(i, 4).toString().trim());
/*      */         } else {
/* 3065 */           setIS.setFamilyStuets("");
/*      */         } 
/* 3067 */         if (this.TableSerchGrantee.getValueAt(i, 3) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 3).toString().trim())) {
/* 3068 */           setIS.setFamilyCount(this.TableSerchGrantee.getValueAt(i, 3).toString().trim());
/*      */         } else {
/* 3070 */           setIS.setFamilyCount("");
/*      */         } 
/* 3072 */         if (this.TableSerchGrantee.getValueAt(i, 1) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 1).toString().trim())) {
/* 3073 */           setIS.setSponsorsName(this.TableSerchGrantee.getValueAt(i, 1).toString().trim());
/*      */         } else {
/* 3075 */           setIS.setSponsorsName("");
/*      */         } 
/* 3077 */         if (this.TableSerchGrantee.getValueAt(i, 0) != null && !"".equals(this.TableSerchGrantee.getValueAt(i, 0).toString().trim())) {
/* 3078 */           setIS.setId(Integer.valueOf(this.TableSerchGrantee.getValueAt(i, 0).toString().trim()).intValue());
/*      */         } else {
/* 3080 */           setIS.setId(0);
/*      */         } 
/* 3082 */         is.add(setIS);
/*      */       } 
/*      */       
/* 3085 */       if (!is.isEmpty()) {
/* 3086 */         ReportsManager.getInstance().showReport("Reports/Disabled/SponsorsReport.jasper", new Hashtable<>(), "قسم المعاقين", is);
/*      */       }
/*      */     } finally {
/* 3089 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonReport1ActionPerformed(ActionEvent evt) {
/* 3095 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 3098 */       ArrayList<InfoExpense> exr = new ArrayList<>();
/*      */ 
/*      */       
/* 3101 */       for (int i = 0; i < this.TableExpenses.getRowCount(); i++) {
/* 3102 */         InfoExpense expR = new InfoExpense();
/* 3103 */         if (this.TextGranteeNameExpenses.getText() != null && !"".equals(this.TextGranteeNameExpenses.getText().trim())) {
/* 3104 */           expR.setGranteesName(this.TextGranteeNameExpenses.getText().trim());
/*      */         } else {
/* 3106 */           expR.setGranteesName("");
/*      */         } 
/* 3108 */         if (this.TableExpenses.getValueAt(i, 5) != null && !"".equals(this.TableExpenses.getValueAt(i, 5).toString().trim())) {
/* 3109 */           expR.setId(Integer.valueOf(this.TableExpenses.getValueAt(i, 5).toString().trim()).intValue());
/*      */         } else {
/* 3111 */           expR.setId(0);
/*      */         } 
/* 3113 */         if (TextSponsorNameExpenses.getText() != null && !"".equals(TextSponsorNameExpenses.getText().trim())) {
/* 3114 */           expR.setSponsorsName(TextSponsorNameExpenses.getText().trim());
/*      */         } else {
/* 3116 */           expR.setSponsorsName("");
/*      */         } 
/* 3118 */         if (this.TableExpenses.getValueAt(i, 3) != null && !"".equals(this.TableExpenses.getValueAt(i, 3).toString().trim())) {
/* 3119 */           expR.setValueExpense(this.TableExpenses.getValueAt(i, 3).toString().trim());
/*      */         } else {
/* 3121 */           expR.setValueExpense("");
/*      */         } 
/* 3123 */         if (this.TableExpenses.getValueAt(i, 2) != null && !"".equals(this.TableExpenses.getValueAt(i, 2).toString().trim())) {
/* 3124 */           expR.setDateExpense(this.TableExpenses.getValueAt(i, 2).toString().trim());
/*      */         } else {
/* 3126 */           expR.setDateExpense("");
/*      */         } 
/* 3128 */         exr.add(expR);
/*      */       } 
/* 3130 */       if (!exr.isEmpty()) {
/* 3131 */         ReportsManager.getInstance().showReport("Reports/Disabled/AllExpenseReport.jasper", new Hashtable<>(), "مدفوعات الكفيل", exr);
/*      */       }
/*      */     } finally {
/* 3134 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void homeActionPerformed(ActionEvent evt) {
/*      */     try {
/* 3140 */       setCursor(new Cursor(3));
/* 3141 */       (new HumanitarianMain()).setVisible(true);
/* 3142 */       dispose();
/*      */     } finally {
/* 3144 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void TableDeletGranteeMousePressed(MouseEvent evt) {
/* 3149 */     OpenGUI(this.textsDeleteGrantee, this.TextGranteeNameDelet, this.ButtonAddGrantee2, this.MyYellow, false, true);
/* 3150 */     int yb = this.TableDeletGrantee.getSelectedRow();
/* 3151 */     this.TextGranteeIDDelet.setText(String.valueOf(this.TableDeletGrantee.getValueAt(yb, 10)));
/* 3152 */     this.TextGranteeNameDelet.setText(String.valueOf(this.TableDeletGrantee.getValueAt(yb, 9)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextNameSercheDeletKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void ButtonGranteeSerchDeleteActionPerformed(ActionEvent evt) {
/* 3161 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 3164 */       if (!this.TextNameSercheDelet.getText().trim().equals("")) {
/* 3165 */         DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableDeletGrantee, this.ColomonsNames);
/* 3166 */         this.TableDeletGrantee = (new TablesSeting()).ColomonSize(this.TableDeletGrantee, this.ColomonsSize);
/* 3167 */         CloseGUI(this.textsDeleteGrantee, this.ButtonAddGrantee2, this.MyYellow, false);
/*      */         
/* 3169 */         this.WhatPress = 1;
/*      */         try {
/* 3171 */           this.grantee = this.gran.getGrantee(this.TextNameSercheDelet.getText().trim(), this.ser.stringSe(this.nTableGrantees, this.nColomnGrantees, new String[] { this.TextNameSercheDelet.getText().trim() }), "2");
/* 3172 */           for (int i = 0; i < this.grantee.size(); i++)
/*      */           {
/* 3174 */             Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getGranteeAccount(), ((InfoGrantees)this.grantee.get(i)).getGranteeConnect(), ((InfoGrantees)this.grantee.get(i)).getCrownGrantee(), ((InfoGrantees)this.grantee.get(i)).getCityName(), ((InfoGrantees)this.grantee.get(i)).getDateBirth(), ((InfoGrantees)this.grantee.get(i)).getRegestryID(), ((InfoGrantees)this.grantee.get(i)).getRegestryType(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/*      */             
/* 3176 */             dtm.addRow(ary);
/*      */           }
/*      */         
/* 3179 */         } catch (Exception ex) {
/* 3180 */           Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         } 
/*      */       } else {
/* 3183 */         String eror = "الرجاء إدخال كلمة البحث";
/* 3184 */         (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 3189 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void ButtonViwoDeletActionPerformed(ActionEvent evt) {
/* 3195 */     setCursor(new Cursor(3));
/*      */     
/*      */     try {
/* 3198 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableDeletGrantee, this.ColomonsNames);
/* 3199 */       this.TableDeletGrantee = (new TablesSeting()).ColomonSize(this.TableDeletGrantee, this.ColomonsSize);
/* 3200 */       CloseGUI(this.textsDeleteGrantee, this.ButtonAddGrantee2, this.MyYellow, false);
/* 3201 */       this.WhatPress = 2;
/*      */       try {
/* 3203 */         this.grantee = this.gran.getAllGrantees("2");
/* 3204 */         for (int i = 0; i < this.grantee.size(); i++) {
/*      */           
/* 3206 */           Object[] ary = { ((InfoGrantees)this.grantee.get(i)).getFamilyStuets(), ((InfoGrantees)this.grantee.get(i)).getFamilyCount(), ((InfoGrantees)this.grantee.get(i)).getGranteeAccount(), ((InfoGrantees)this.grantee.get(i)).getGranteeConnect(), ((InfoGrantees)this.grantee.get(i)).getCrownGrantee(), ((InfoGrantees)this.grantee.get(i)).getCityName(), ((InfoGrantees)this.grantee.get(i)).getDateBirth(), ((InfoGrantees)this.grantee.get(i)).getRegestryID(), ((InfoGrantees)this.grantee.get(i)).getRegestryType(), ((InfoGrantees)this.grantee.get(i)).getGranteeName(), Integer.valueOf(((InfoGrantees)this.grantee.get(i)).getId()) };
/*      */           
/* 3208 */           dtm.addRow(ary);
/*      */         } 
/* 3210 */       } catch (Exception ex) {
/* 3211 */         Logger.getLogger(GUEDisabled.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } finally {
/* 3214 */       setCursor(new Cursor(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextFamilyCountKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void BoxFamilyStutsKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void TextExpenseValueKeyPressed(KeyEvent evt) {
/* 3227 */     int key = evt.getKeyCode();
/* 3228 */     if (key == 10) {
/* 3229 */       this.TextExpenseDay.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextExpenseDayKeyPressed(KeyEvent evt) {
/* 3234 */     int key = evt.getKeyCode();
/* 3235 */     if (key == 10) {
/* 3236 */       this.TextExpenseMonth.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextExpenseMonthKeyPressed(KeyEvent evt) {
/* 3241 */     int key = evt.getKeyCode();
/* 3242 */     if (key == 10) {
/* 3243 */       this.TextExpenseYear.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextExpenseYearKeyPressed(KeyEvent evt) {
/* 3248 */     int key = evt.getKeyCode();
/* 3249 */     if (key == 10) {
/* 3250 */       this.TextRecipientName.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextRecipientNameKeyPressed(KeyEvent evt) {
/* 3255 */     int key = evt.getKeyCode();
/* 3256 */     if (key == 10) {
/* 3257 */       ButtonExpensesSend.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextPaymentValueKeyPressed(KeyEvent evt) {
/* 3262 */     int key = evt.getKeyCode();
/* 3263 */     if (key == 10) {
/* 3264 */       this.TextPaymentDay.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextPaymentDayKeyPressed(KeyEvent evt) {
/* 3269 */     int key = evt.getKeyCode();
/* 3270 */     if (key == 10) {
/* 3271 */       this.TextPaymentMonth.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextPaymentMonthKeyPressed(KeyEvent evt) {
/* 3276 */     int key = evt.getKeyCode();
/* 3277 */     if (key == 10) {
/* 3278 */       this.TextPaymentYear.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void TextPaymentYearKeyPressed(KeyEvent evt) {
/* 3283 */     int key = evt.getKeyCode();
/* 3284 */     if (key == 10) {
/* 3285 */       ButtonPaymentSend.requestFocus();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void TextFamilyCountEditKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void BoxFamilyStutsEditKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void BoxFamilyStutsSerchKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void RemoveTable(JTable table, String[] ColomonsNames) {
/* 3302 */     DefaultTableModel dtm = new DefaultTableModel();
/* 3303 */     for (int i = 0; i < ColomonsNames.length; i++) {
/* 3304 */       dtm.addColumn(ColomonsNames[i]);
/*      */     }
/* 3306 */     table.setModel(dtm);
/*      */   }
/*      */   
/*      */   private void TextToArabicFocusGained(FocusEvent evt) {
/* 3310 */     LanguageText.setLanguage("ar", this.TextRegestryID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/* 3319 */     EventQueue.invokeLater(new Runnable() {
/*      */           public void run() {
/* 3321 */             (new GUEDisabled()).setVisible(true);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class ClientsTableButtonRendererAdd
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererAdd() {
/* 3527 */       setOpaque(true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 3543 */       setText((value == null) ? "" : value.toString());
/* 3544 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererAdd extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/*      */     
/*      */     public ClientsTableRendererAdd(JCheckBox checkBox) {
/* 3557 */       super(checkBox);
/* 3558 */       this.button = new JButton();
/* 3559 */       this.button.setOpaque(true);
/* 3560 */       this.button.addActionListener(new ActionListener() {
/*      */             public void actionPerformed(ActionEvent e) {
/* 3562 */               GUEDisabled.this.setCursor(new Cursor(3));
/*      */               try {
/* 3564 */                 GUEDisabled.ClientsTableRendererAdd.this.fireEditingStopped();
/* 3565 */                 if (GUEDisabled.ClientsTableRendererAdd.this.table.getValueAt(GUEDisabled.ClientsTableRendererAdd.this.row, 0) == null || GUEDisabled.ClientsTableRendererAdd.this.table.getValueAt(GUEDisabled.ClientsTableRendererAdd.this.row, 0).toString().trim().equals("") == true) {
/* 3566 */                   GUEDisabled.TextGranteeIDSercheAdd.setText(String.valueOf(GUEDisabled.ClientsTableRendererAdd.this.table.getValueAt(GUEDisabled.ClientsTableRendererAdd.this.row, 6)));
/* 3567 */                   GUEDisabled.TextGranteeNameSercheAdd.setText(String.valueOf(GUEDisabled.ClientsTableRendererAdd.this.table.getValueAt(GUEDisabled.ClientsTableRendererAdd.this.row, 5)));
/*      */                   
/* 3569 */                   GUEDisabled.this.OpenGUI(GUEDisabled.this.textsAddSponsor, GUEDisabled.TextSponsorNameAdd, GUEDisabled.ButtonAddSponsor, GUEDisabled.this.MyWhite, true, true);
/*      */                 } else {
/* 3571 */                   GUEDisabled.TextGranteeIDSercheAdd.setText("");
/* 3572 */                   GUEDisabled.TextGranteeNameSercheAdd.setText("");
/* 3573 */                   GUEDisabled.this.CloseGUI(GUEDisabled.this.textsAddSponsor, GUEDisabled.ButtonAddSponsor, GUEDisabled.this.MyGray, false);
/* 3574 */                   String eror = "هذا المعاق لديه كفيل سابق<br>وبإمكانك إيقاف كفالته لحذف كل مايتعلق بالكفالة<br>الخاصة به ثم وضع كفيل جديد";
/*      */ 
/*      */ 
/*      */                   
/* 3578 */                   (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */                 }
/*      */               
/*      */               } finally {
/*      */                 
/* 3583 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 3590 */       this.table = table;
/* 3591 */       this.row = row;
/* 3592 */       this.col = column;
/*      */       
/* 3594 */       this.button.setForeground(Color.black);
/* 3595 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 3596 */       this.label = (value == null) ? "" : value.toString();
/* 3597 */       this.button.setText(this.label);
/* 3598 */       this.clicked = true;
/* 3599 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 3603 */       this.clicked = false;
/* 3604 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 3608 */       this.clicked = false;
/* 3609 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 3613 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */   
/*      */   class ClientsTableButtonRendererChange
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererChange() {
/* 3622 */       setOpaque(true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 3638 */       setText((value == null) ? "" : value.toString());
/* 3639 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class ClientsTableButtonRendererStop
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererStop() {
/* 3650 */       setOpaque(true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 3666 */       setText((value == null) ? "" : value.toString());
/* 3667 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererStop extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/*      */     
/*      */     public ClientsTableRendererStop(JCheckBox checkBox) {
/* 3680 */       super(checkBox);
/* 3681 */       this.button = new JButton();
/* 3682 */       this.button.setOpaque(true);
/* 3683 */       this.button.addActionListener(new ActionListener() {
/*      */             public void actionPerformed(ActionEvent e) {
/* 3685 */               GUEDisabled.ClientsTableRendererStop.this.fireEditingStopped();
/* 3686 */               GUEDisabled.this.setCursor(new Cursor(3));
/*      */               try {
/* 3688 */                 if (GUEDisabled.ClientsTableRendererStop.this.table.getValueAt(GUEDisabled.ClientsTableRendererStop.this.row, 0) == null || GUEDisabled.ClientsTableRendererStop.this.table.getValueAt(GUEDisabled.ClientsTableRendererStop.this.row, 0).toString().trim().equals("") == true) {
/*      */                   
/* 3690 */                   String eror = "هذا المعاق ليس له كفيل سابق حتى يتم إيقافه<br>";
/*      */                   
/* 3692 */                   (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */                 
/*      */                 }
/*      */                 else {
/*      */                   
/* 3697 */                   GUEDisabled.this.OpenGUI(GUEDisabled.this.textsStopSponsor, GUEDisabled.TextGranteeNameSercheStop2, GUEDisabled.ButtonStopSponsor, GUEDisabled.this.MyYellow, false, true);
/* 3698 */                   GUEDisabled.TextGranteeIDSercheStop.setText(GUEDisabled.ClientsTableRendererStop.this.table.getValueAt(GUEDisabled.ClientsTableRendererStop.this.row, 4).toString());
/* 3699 */                   GUEDisabled.TextGranteeNameSercheStop.setText(GUEDisabled.ClientsTableRendererStop.this.table.getValueAt(GUEDisabled.ClientsTableRendererStop.this.row, 3).toString());
/* 3700 */                   GUEDisabled.TextSponsorNameStop.setText(GUEDisabled.ClientsTableRendererStop.this.table.getValueAt(GUEDisabled.ClientsTableRendererStop.this.row, 1).toString());
/*      */                 } 
/*      */               } finally {
/*      */                 
/* 3704 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 3711 */       this.table = table;
/* 3712 */       this.row = row;
/* 3713 */       this.col = column;
/*      */       
/* 3715 */       this.button.setForeground(Color.black);
/* 3716 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 3717 */       this.label = (value == null) ? "" : value.toString();
/* 3718 */       this.button.setText(this.label);
/* 3719 */       this.clicked = true;
/* 3720 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 3724 */       this.clicked = false;
/* 3725 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 3729 */       this.clicked = false;
/* 3730 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 3734 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */   
/*      */   class ClientsTableButtonRendererMainPayment
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererMainPayment() {
/* 3743 */       setOpaque(true);
/*      */     }
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 3747 */       setText((value == null) ? "" : value.toString());
/* 3748 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererMainPayment extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/*      */     
/*      */     public ClientsTableRendererMainPayment(JCheckBox checkBox) {
/* 3761 */       super(checkBox);
/* 3762 */       this.button = new JButton();
/* 3763 */       this.button.setOpaque(true);
/* 3764 */       this.button.addActionListener(new ActionListener()
/*      */           {
/*      */             public void actionPerformed(ActionEvent e) {
/*      */               try {
/* 3768 */                 GUEDisabled.this.setCursor(new Cursor(3));
/* 3769 */                 GUEDisabled.ClientsTableRendererMainPayment.this.fireEditingStopped();
/* 3770 */                 if (GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 1) == null || GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 1).toString().trim().equals("") == true) {
/*      */                   
/* 3772 */                   String eror = "هذا المعاق ليس له كفيل سابق حتى يتم إيقافه<br>";
/*      */                   
/* 3774 */                   (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */                 
/*      */                 }
/*      */                 else {
/*      */                   
/* 3779 */                   GUEDisabled.this.TextPaymentValue.requestFocus();
/* 3780 */                   GUEDisabled.ButtonPaymentSend.setEnabled(true);
/*      */                   
/* 3782 */                   GUEDisabled.TextSponsorNOPayment.setText(GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 4).toString());
/* 3783 */                   GUEDisabled.TextSponsorNamePayment.setText(GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 3).toString());
/* 3784 */                   GUEDisabled.this.TextGranteeIDPayment.setText(GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 2).toString());
/* 3785 */                   GUEDisabled.this.TextGranteeNamePayment.setText(GUEDisabled.ClientsTableRendererMainPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainPayment.this.row, 1).toString());
/*      */                   
/* 3787 */                   GUEDisabled.this.ShowPayments();
/*      */                 } 
/*      */               } finally {
/*      */                 
/* 3791 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 3802 */       this.table = table;
/* 3803 */       this.row = row;
/* 3804 */       this.col = column;
/*      */       
/* 3806 */       this.button.setForeground(Color.black);
/* 3807 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 3808 */       this.label = (value == null) ? "" : value.toString();
/* 3809 */       this.button.setText(this.label);
/* 3810 */       this.clicked = true;
/* 3811 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 3815 */       this.clicked = false;
/* 3816 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 3820 */       this.clicked = false;
/* 3821 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 3825 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */   
/*      */   class ClientsTableButtonRendererSupPayment
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererSupPayment() {
/* 3834 */       setOpaque(true);
/*      */     }
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 3838 */       setText((value == null) ? "" : value.toString());
/* 3839 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererSupPayment extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/* 3850 */     private JTextField DayPay = new JTextField();
/* 3851 */     private JTextField MonthPay = new JTextField();
/* 3852 */     private JTextField YearPay = new JTextField();
/* 3853 */     private JTextField ValuePay = new JTextField();
/* 3854 */     private JFrame editFrame = new JFrame();
/*      */     
/*      */     public ClientsTableRendererSupPayment(JCheckBox checkBox) {
/* 3857 */       super(checkBox);
/* 3858 */       this.button = new JButton();
/* 3859 */       this.button.setOpaque(true);
/* 3860 */       this.button.addActionListener(new ActionListener() {
/*      */             public void actionPerformed(ActionEvent e) {
/* 3862 */               GUEDisabled.this.setCursor(new Cursor(3));
/*      */               
/*      */               try {
/* 3865 */                 GUEDisabled.ClientsTableRendererSupPayment.this.fireEditingStopped();
/* 3866 */                 if (GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 1) != null && GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 1).toString().trim().equals("") != true) {
/*      */                   
/* 3868 */                   if ("تحرير".equals(GUEDisabled.ClientsTableRendererSupPayment.this.button.getText())) {
/*      */                     
/* 3870 */                     GUEDisabled.this.setCursor(new Cursor(3));
/*      */                     try {
/* 3872 */                       GUEDisabled.ClientsTableRendererSupPayment.this.editFrame.setSize(600, 250);
/* 3873 */                       GUEDisabled.ClientsTableRendererSupPayment.this.editFrame.setLocationRelativeTo((Component)null);
/* 3874 */                       String[] dateAll = GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 2).toString().split("-");
/*      */                       
/* 3876 */                       JPanel panel = new JPanel();
/* 3877 */                       panel.setPreferredSize(new Dimension(200, 200));
/* 3878 */                       panel.setLayout((LayoutManager)null);
/*      */                       
/* 3880 */                       GUEDisabled.ClientsTableRendererSupPayment.this.YearPay = new JTextField(dateAll[0]);
/* 3881 */                       GUEDisabled.ClientsTableRendererSupPayment.this.YearPay.setBounds(133, 33, 95, 30);
/*      */                       
/* 3883 */                       GUEDisabled.ClientsTableRendererSupPayment.this.MonthPay = new JTextField(dateAll[1]);
/* 3884 */                       GUEDisabled.ClientsTableRendererSupPayment.this.MonthPay.setBounds(233, 33, 65, 30);
/*      */                       
/* 3886 */                       GUEDisabled.ClientsTableRendererSupPayment.this.DayPay = new JTextField(dateAll[2]);
/* 3887 */                       GUEDisabled.ClientsTableRendererSupPayment.this.DayPay.setBounds(313, 33, 65, 30);
/*      */                       
/* 3889 */                       GUEDisabled.ClientsTableRendererSupPayment.this.ValuePay = new JTextField(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 3).toString());
/* 3890 */                       GUEDisabled.ClientsTableRendererSupPayment.this.ValuePay.setBounds(450, 33, 65, 30);
/*      */                       
/* 3892 */                       JLabel label1 = new JLabel("قيمة المبلغ المدفوع :");
/* 3893 */                       label1.setBounds(450, 3, 125, 30);
/*      */                       
/* 3895 */                       JLabel label2 = new JLabel("اليوم:");
/* 3896 */                       label2.setBounds(313, 3, 95, 30);
/*      */                       
/* 3898 */                       JLabel label4 = new JLabel("الشهر:");
/* 3899 */                       label4.setBounds(233, 3, 95, 30);
/*      */                       
/* 3901 */                       JLabel label5 = new JLabel("السنة:");
/* 3902 */                       label5.setBounds(133, 3, 95, 30);
/*      */                       
/* 3904 */                       JLabel label3 = new JLabel("أو");
/* 3905 */                       label3.setBounds(183, 100, 95, 30);
/*      */                       
/* 3907 */                       JButton saveBtn = new JButton("حفظ");
/* 3908 */                       saveBtn.setBounds(33, 33, 95, 30);
/* 3909 */                       saveBtn.addActionListener(new ActionListener() {
/*      */                             public void actionPerformed(ActionEvent evt) {
/* 3911 */                               GUEDisabled.ClientsTableRendererSupPayment.this.saveBtnActionPerformed(evt);
/*      */                             }
/*      */                           });
/*      */                       
/* 3915 */                       JButton deleteBtn = new JButton("حذف هذا المبلغ");
/* 3916 */                       deleteBtn.setBounds(143, 130, 120, 30);
/* 3917 */                       deleteBtn.addActionListener(new ActionListener() {
/*      */                             public void actionPerformed(ActionEvent evt) {
/* 3919 */                               GUEDisabled.ClientsTableRendererSupPayment.this.deleteBtnActionPerformed(evt);
/*      */                             }
/*      */                           });
/*      */ 
/*      */                       
/* 3924 */                       panel.add(GUEDisabled.ClientsTableRendererSupPayment.this.ValuePay);
/* 3925 */                       panel.add(GUEDisabled.ClientsTableRendererSupPayment.this.DayPay);
/* 3926 */                       panel.add(GUEDisabled.ClientsTableRendererSupPayment.this.MonthPay);
/* 3927 */                       panel.add(GUEDisabled.ClientsTableRendererSupPayment.this.YearPay);
/* 3928 */                       panel.add(label1);
/* 3929 */                       panel.add(label2);
/* 3930 */                       panel.add(label4);
/* 3931 */                       panel.add(label5);
/* 3932 */                       panel.add(label3);
/* 3933 */                       panel.add(saveBtn);
/* 3934 */                       panel.add(deleteBtn);
/*      */                       
/* 3936 */                       GUEDisabled.ClientsTableRendererSupPayment.this.editFrame.add(panel);
/* 3937 */                       GUEDisabled.ClientsTableRendererSupPayment.this.editFrame.setVisible(true);
/*      */                     } finally {
/*      */                       
/* 3940 */                       GUEDisabled.this.setCursor(new Cursor(0));
/*      */                     } 
/*      */                   } 
/* 3943 */                   if ("طباعة فاتورة".equals(GUEDisabled.ClientsTableRendererSupPayment.this.button.getText())) {
/* 3944 */                     GUEDisabled.this.setCursor(new Cursor(3));
/*      */                     try {
/* 3946 */                       ArrayList<InfoPayment> receipt = new ArrayList<>();
/*      */ 
/*      */ 
/*      */                       
/* 3950 */                       InfoPayment setreceipt = new InfoPayment();
/*      */                       
/* 3952 */                       if (GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 4) != null && !"".equals(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 4).toString().trim())) {
/* 3953 */                         setreceipt.setSponsorsName(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 4).toString().trim());
/*      */                       } else {
/* 3955 */                         setreceipt.setSponsorsName("");
/*      */                       } 
/* 3957 */                       if (GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 3) != null && !"".equals(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 3).toString().trim())) {
/* 3958 */                         setreceipt.setValuePayment(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 3).toString().trim());
/*      */                       } else {
/* 3960 */                         setreceipt.setValuePayment("");
/*      */                       } 
/* 3962 */                       if (GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 2) != null && !"".equals(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 2).toString().trim())) {
/* 3963 */                         setreceipt.setDatePayment(GUEDisabled.ClientsTableRendererSupPayment.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupPayment.this.row, 2).toString().trim());
/*      */                       } else {
/* 3965 */                         setreceipt.setDatePayment("");
/*      */                       } 
/*      */                       
/* 3968 */                       receipt.add(setreceipt);
/*      */ 
/*      */                       
/* 3971 */                       if (!receipt.isEmpty()) {
/* 3972 */                         ReportsManager.getInstance().showReport("Reports/Disabled/ReceiptReport.jasper", new Hashtable<>(), "سند استلام", receipt);
/*      */                       }
/*      */                     } finally {
/* 3975 */                       GUEDisabled.this.setCursor(new Cursor(0));
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } finally {
/* 3980 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void deleteBtnActionPerformed(ActionEvent evt) {
/* 3989 */       GUEDisabled.this.setCursor(new Cursor(3));
/*      */       
/*      */       try {
/* 3992 */         GUEDisabled.this.pay = new InfoPayment(Integer.valueOf(this.table.getValueAt(this.row, 5).toString()).intValue(), GUEDisabled.this.TextGranteeIDPayment.getText().trim(), "", "", "", 0, 0, 0, "", "", "", "");
/* 3993 */         GUEDisabled.this.pay.PaymentDelete();
/* 3994 */         GUEDisabled.this.pay.setGPID("GranteePayments" + GUEDisabled.this.TextGranteeIDPayment.getText().trim() + "_" + Integer.valueOf(this.table.getValueAt(this.row, 5).toString()));
/* 3995 */         GUEDisabled.this.pay.PublicPaymentDelete();
/* 3996 */         GUEDisabled.this.ShowPayments();
/* 3997 */         this.editFrame.dispose();
/*      */       } finally {
/* 3999 */         GUEDisabled.this.setCursor(new Cursor(0));
/*      */       } 
/*      */     }
/*      */     private void saveBtnActionPerformed(ActionEvent evt) {
/* 4003 */       GUEDisabled.this.setCursor(new Cursor(3));
/*      */       try {
/* 4005 */         ChekCompletData chd = new ChekCompletData();
/* 4006 */         String[] IfEror = { "الرجاء إدخال المبلغ" };
/* 4007 */         String[] ChekTexts = { this.ValuePay.getText().trim() };
/* 4008 */         ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */         
/* 4010 */         String[] IfErorint = { "أدخل اليوم رقمًا", "أدخل الشهر رقمًا", "أدخل العام رقمًا" };
/* 4011 */         String[] ChekNumbers = { this.DayPay.getText().trim(), this.MonthPay.getText().trim(), this.YearPay.getText().trim() };
/* 4012 */         ArrayList<String> validInt = chd.ChekCompletDataNuumper(IfErorint, ChekNumbers);
/*      */         
/* 4014 */         if (valid.isEmpty() && validInt.isEmpty()) {
/* 4015 */           GUEDisabled.this.pay = new InfoPayment(Integer.valueOf(this.table.getValueAt(this.row, 5).toString()).intValue(), GUEDisabled.this.TextGranteeIDPayment.getText().trim(), "", "", "", Integer.valueOf(this.DayPay.getText().trim()).intValue(), Integer.valueOf(this.MonthPay.getText().trim()).intValue(), Integer.valueOf(this.YearPay.getText().trim()).intValue(), this.ValuePay.getText().trim(), "", "", "");
/* 4016 */           GUEDisabled.this.pay.PaymentUpdate();
/*      */           
/* 4018 */           GUEDisabled.this.pay.setGPID("GranteePayments" + GUEDisabled.this.TextGranteeIDPayment.getText().trim() + "_" + Integer.valueOf(this.table.getValueAt(this.row, 5).toString()));
/* 4019 */           GUEDisabled.this.pay.PublicPaymentUpdate();
/* 4020 */           GUEDisabled.this.ShowPayments();
/*      */         } else {
/* 4022 */           String eror = ""; int i;
/* 4023 */           for (i = 0; i < valid.size(); i++) {
/* 4024 */             eror = eror + (String)valid.get(i) + "<br>";
/*      */           }
/*      */           
/* 4027 */           for (i = 0; i < validInt.size(); i++) {
/* 4028 */             eror = eror + (String)validInt.get(i) + "<br>";
/*      */           }
/*      */           
/* 4031 */           (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 4036 */         GUEDisabled.this.setCursor(new Cursor(0));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 4042 */       this.table = table;
/* 4043 */       this.row = row;
/* 4044 */       this.col = column;
/*      */       
/* 4046 */       this.button.setForeground(Color.black);
/* 4047 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 4048 */       this.label = (value == null) ? "" : value.toString();
/* 4049 */       this.button.setText(this.label);
/* 4050 */       this.clicked = true;
/* 4051 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 4055 */       this.clicked = false;
/* 4056 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 4060 */       this.clicked = false;
/* 4061 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 4065 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */   
/*      */   class ClientsTableButtonRendererMainExpenses
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererMainExpenses() {
/* 4074 */       setOpaque(true);
/*      */     }
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 4078 */       setText((value == null) ? "" : value.toString());
/* 4079 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererMainExpenses extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/*      */     
/*      */     public ClientsTableRendererMainExpenses(JCheckBox checkBox) {
/* 4092 */       super(checkBox);
/* 4093 */       this.button = new JButton();
/* 4094 */       this.button.setOpaque(true);
/* 4095 */       this.button.addActionListener(new ActionListener() {
/*      */             public void actionPerformed(ActionEvent e) {
/*      */               try {
/* 4098 */                 GUEDisabled.this.setCursor(new Cursor(3));
/* 4099 */                 GUEDisabled.ClientsTableRendererMainExpenses.this.fireEditingStopped();
/* 4100 */                 if (GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 1) != null && GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 1).toString().trim().equals("") != true)
/*      */                 {
/* 4102 */                   GUEDisabled.this.TextExpenseValue.requestFocus();
/* 4103 */                   GUEDisabled.ButtonExpensesSend.setEnabled(true);
/*      */                   
/* 4105 */                   GUEDisabled.this.TextGranteeIDExpenses.setText(GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 4).toString());
/* 4106 */                   GUEDisabled.this.TextGranteeNameExpenses.setText(GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 3).toString());
/* 4107 */                   GUEDisabled.TextSponsorNOExpenses.setText(GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 2).toString());
/* 4108 */                   GUEDisabled.TextSponsorNameExpenses.setText(GUEDisabled.ClientsTableRendererMainExpenses.this.table.getValueAt(GUEDisabled.ClientsTableRendererMainExpenses.this.row, 1).toString());
/*      */                   
/* 4110 */                   GUEDisabled.this.ShowExpenses();
/*      */                 }
/*      */               
/*      */               } finally {
/*      */                 
/* 4115 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 4124 */       this.table = table;
/* 4125 */       this.row = row;
/* 4126 */       this.col = column;
/*      */       
/* 4128 */       this.button.setForeground(Color.black);
/* 4129 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 4130 */       this.label = (value == null) ? "" : value.toString();
/* 4131 */       this.button.setText(this.label);
/* 4132 */       this.clicked = true;
/* 4133 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 4137 */       this.clicked = false;
/* 4138 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 4142 */       this.clicked = false;
/* 4143 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 4147 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */   
/*      */   class ClientsTableButtonRendererSupExpense
/*      */     extends JButton
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public ClientsTableButtonRendererSupExpense() {
/* 4156 */       setOpaque(true);
/*      */     }
/*      */     
/*      */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 4160 */       setText((value == null) ? "" : value.toString());
/* 4161 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   public class ClientsTableRendererSupExpense extends DefaultCellEditor {
/*      */     private JButton button;
/*      */     private String label;
/*      */     private boolean clicked;
/*      */     private int row;
/*      */     private int col;
/*      */     private JTable table;
/* 4172 */     private JTextField DayEX = new JTextField();
/* 4173 */     private JTextField MonthEX = new JTextField();
/* 4174 */     private JTextField YearEX = new JTextField();
/* 4175 */     private JTextField RecipientEX = new JTextField();
/* 4176 */     private JTextField ValueEX = new JTextField();
/* 4177 */     private JFrame editFrame = new JFrame();
/*      */     
/*      */     public ClientsTableRendererSupExpense(JCheckBox checkBox) {
/* 4180 */       super(checkBox);
/* 4181 */       this.button = new JButton();
/* 4182 */       this.button.setOpaque(true);
/* 4183 */       this.button.addActionListener(new ActionListener() {
/*      */             public void actionPerformed(ActionEvent e) {
/*      */               try {
/* 4186 */                 GUEDisabled.this.setCursor(new Cursor(3));
/* 4187 */                 GUEDisabled.ClientsTableRendererSupExpense.this.fireEditingStopped();
/* 4188 */                 if (GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 1) != null && GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 1).toString().trim().equals("") != true) {
/*      */                   
/* 4190 */                   if ("تحرير".equals(GUEDisabled.ClientsTableRendererSupExpense.this.button.getText())) {
/* 4191 */                     GUEDisabled.this.setCursor(new Cursor(3));
/*      */                     try {
/* 4193 */                       GUEDisabled.ClientsTableRendererSupExpense.this.editFrame.setSize(700, 250);
/* 4194 */                       GUEDisabled.ClientsTableRendererSupExpense.this.editFrame.setLocationRelativeTo((Component)null);
/*      */                       
/* 4196 */                       JPanel panel = new JPanel();
/* 4197 */                       panel.setPreferredSize(new Dimension(200, 200));
/* 4198 */                       panel.setLayout((LayoutManager)null);
/* 4199 */                       String[] dateAll = GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 2).toString().split("-");
/*      */                       
/* 4201 */                       GUEDisabled.ClientsTableRendererSupExpense.this.YearEX = new JTextField(dateAll[0]);
/* 4202 */                       GUEDisabled.ClientsTableRendererSupExpense.this.YearEX.setBounds(133, 33, 95, 30);
/*      */                       
/* 4204 */                       GUEDisabled.ClientsTableRendererSupExpense.this.MonthEX = new JTextField(dateAll[1]);
/* 4205 */                       GUEDisabled.ClientsTableRendererSupExpense.this.MonthEX.setBounds(233, 33, 65, 30);
/*      */                       
/* 4207 */                       GUEDisabled.ClientsTableRendererSupExpense.this.DayEX = new JTextField(dateAll[2]);
/* 4208 */                       GUEDisabled.ClientsTableRendererSupExpense.this.DayEX.setBounds(313, 33, 65, 30);
/*      */                       
/* 4210 */                       GUEDisabled.ClientsTableRendererSupExpense.this.ValueEX = new JTextField(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 3).toString());
/* 4211 */                       GUEDisabled.ClientsTableRendererSupExpense.this.ValueEX.setBounds(450, 33, 95, 30);
/*      */                       
/* 4213 */                       GUEDisabled.ClientsTableRendererSupExpense.this.RecipientEX = new JTextField(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 4).toString());
/* 4214 */                       GUEDisabled.ClientsTableRendererSupExpense.this.RecipientEX.setBounds(560, 33, 95, 30);
/*      */                       
/* 4216 */                       JLabel label1 = new JLabel("قيمة المبلغ المصروف :");
/* 4217 */                       label1.setBounds(450, 3, 125, 30);
/*      */ 
/*      */                       
/* 4220 */                       JLabel label2 = new JLabel("اليوم:");
/* 4221 */                       label2.setBounds(313, 3, 95, 30);
/*      */                       
/* 4223 */                       JLabel label6 = new JLabel("الشهر:");
/* 4224 */                       label6.setBounds(233, 3, 95, 30);
/*      */                       
/* 4226 */                       JLabel label5 = new JLabel("السنة:");
/* 4227 */                       label5.setBounds(133, 3, 95, 30);
/*      */                       
/* 4229 */                       JLabel label3 = new JLabel("أو");
/* 4230 */                       label3.setBounds(183, 100, 95, 30);
/*      */                       
/* 4232 */                       JLabel label4 = new JLabel("المستلم :");
/* 4233 */                       label4.setBounds(560, 3, 125, 30);
/*      */                       
/* 4235 */                       JButton saveBtn = new JButton("حفظ");
/* 4236 */                       saveBtn.setBounds(33, 33, 95, 30);
/* 4237 */                       saveBtn.addActionListener(new ActionListener() {
/*      */                             public void actionPerformed(ActionEvent evt) {
/* 4239 */                               GUEDisabled.ClientsTableRendererSupExpense.this.saveBtnActionPerformed(evt);
/*      */                             }
/*      */                           });
/*      */                       
/* 4243 */                       JButton deleteBtn = new JButton("حذف هذا الخانة");
/* 4244 */                       deleteBtn.setBounds(143, 130, 120, 30);
/* 4245 */                       deleteBtn.addActionListener(new ActionListener() {
/*      */                             public void actionPerformed(ActionEvent evt) {
/* 4247 */                               GUEDisabled.ClientsTableRendererSupExpense.this.deleteBtnActionPerformed(evt);
/*      */                             }
/*      */                           });
/*      */                       
/* 4251 */                       panel.add(GUEDisabled.ClientsTableRendererSupExpense.this.RecipientEX);
/* 4252 */                       panel.add(GUEDisabled.ClientsTableRendererSupExpense.this.ValueEX);
/* 4253 */                       panel.add(GUEDisabled.ClientsTableRendererSupExpense.this.DayEX);
/* 4254 */                       panel.add(GUEDisabled.ClientsTableRendererSupExpense.this.MonthEX);
/* 4255 */                       panel.add(GUEDisabled.ClientsTableRendererSupExpense.this.YearEX);
/* 4256 */                       panel.add(label1);
/* 4257 */                       panel.add(label2);
/* 4258 */                       panel.add(label5);
/* 4259 */                       panel.add(label6);
/* 4260 */                       panel.add(label3);
/* 4261 */                       panel.add(label4);
/* 4262 */                       panel.add(saveBtn);
/* 4263 */                       panel.add(deleteBtn);
/*      */                       
/* 4265 */                       GUEDisabled.ClientsTableRendererSupExpense.this.editFrame.add(panel);
/* 4266 */                       GUEDisabled.ClientsTableRendererSupExpense.this.editFrame.setVisible(true);
/*      */                     } finally {
/* 4268 */                       GUEDisabled.this.setCursor(new Cursor(0));
/*      */                     } 
/*      */                   } 
/* 4271 */                   if ("طباعة فاتورة".equals(GUEDisabled.ClientsTableRendererSupExpense.this.button.getText())) {
/* 4272 */                     GUEDisabled.this.setCursor(new Cursor(3));
/*      */                     try {
/* 4274 */                       ArrayList<InfoExpense> disbursed = new ArrayList<>();
/*      */ 
/*      */ 
/*      */                       
/* 4278 */                       InfoExpense setdisbursed = new InfoExpense();
/* 4279 */                       if (GUEDisabled.this.TextGranteeNameExpenses.getText().trim() != null && !"".equals(GUEDisabled.this.TextGranteeNameExpenses.getText().trim())) {
/* 4280 */                         setdisbursed.setGranteesName(GUEDisabled.this.TextGranteeNameExpenses.getText().trim());
/*      */                       } else {
/* 4282 */                         setdisbursed.setGranteesName("");
/*      */                       } 
/*      */                       
/* 4285 */                       if (GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 4) != null && !"".equals(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 4).toString().trim())) {
/* 4286 */                         setdisbursed.setRecipientName(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 4).toString().trim());
/*      */                       } else {
/* 4288 */                         setdisbursed.setRecipientName("");
/*      */                       } 
/* 4290 */                       if (GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 3) != null && !"".equals(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 3).toString().trim())) {
/* 4291 */                         setdisbursed.setValueExpense(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 3).toString().trim());
/*      */                       } else {
/* 4293 */                         setdisbursed.setValueExpense("");
/*      */                       } 
/* 4295 */                       if (GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 2) != null && !"".equals(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 2).toString().trim())) {
/* 4296 */                         setdisbursed.setDateExpense(GUEDisabled.ClientsTableRendererSupExpense.this.table.getValueAt(GUEDisabled.ClientsTableRendererSupExpense.this.row, 2).toString().trim());
/*      */                       } else {
/* 4298 */                         setdisbursed.setDateExpense("");
/*      */                       } 
/*      */                       
/* 4301 */                       disbursed.add(setdisbursed);
/*      */ 
/*      */                       
/* 4304 */                       if (!disbursed.isEmpty()) {
/* 4305 */                         ReportsManager.getInstance().showReport("Reports/Disabled/DisbursedReport.jasper", new Hashtable<>(), "سند استلام", disbursed);
/*      */                       }
/*      */                     } finally {
/* 4308 */                       GUEDisabled.this.setCursor(new Cursor(0));
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } finally {
/*      */                 
/* 4314 */                 GUEDisabled.this.setCursor(new Cursor(0));
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void deleteBtnActionPerformed(ActionEvent evt) {
/* 4323 */       GUEDisabled.this.setCursor(new Cursor(3));
/*      */       try {
/* 4325 */         GUEDisabled.this.expe1 = new InfoExpense(Integer.valueOf(this.table.getValueAt(this.row, 5).toString()).intValue(), GUEDisabled.this.TextGranteeIDExpenses.getText().trim(), "", "", 0, 0, 0, "", "", "", "", "", 0);
/* 4326 */         GUEDisabled.this.expe1.ExpenseDelete();
/* 4327 */         GUEDisabled.this.ShowExpenses();
/* 4328 */         this.editFrame.dispose();
/*      */       } finally {
/* 4330 */         GUEDisabled.this.setCursor(new Cursor(0));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void saveBtnActionPerformed(ActionEvent evt) {
/* 4336 */       GUEDisabled.this.setCursor(new Cursor(3));
/*      */       try {
/* 4338 */         ChekCompletData chd = new ChekCompletData();
/* 4339 */         String[] IfEror = { "الرجاء إدخال المبلغ المصروف", "الرجاء إدخال اسم المستلم" };
/*      */         
/* 4341 */         String[] ChekTexts = { this.ValueEX.getText().trim(), this.RecipientEX.getText().trim() };
/* 4342 */         ArrayList<String> valid = chd.ChekCompletData(IfEror, ChekTexts);
/*      */         
/* 4344 */         String[] IfErorint = { "أدخل اليوم رقمًا", "أدخل الشهر رقمًا", "أدخل العام رقمًا" };
/* 4345 */         String[] ChekNumbers = { this.DayEX.getText().trim(), this.MonthEX.getText().trim(), this.YearEX.getText().trim() };
/* 4346 */         ArrayList<String> validInt = chd.ChekCompletDataNuumper(IfErorint, ChekNumbers);
/*      */         
/* 4348 */         if (valid.isEmpty() && validInt.isEmpty()) {
/* 4349 */           GUEDisabled.this.expe1 = new InfoExpense(Integer.valueOf(this.table.getValueAt(this.row, 5).toString()).intValue(), GUEDisabled.this.TextGranteeIDExpenses.getText().trim(), "", "", 
/* 4350 */               Integer.valueOf(this.DayEX.getText().trim()).intValue(), Integer.valueOf(this.MonthEX.getText().trim()).intValue(), Integer.valueOf(this.YearEX.getText().trim()).intValue(), this.ValueEX
/* 4351 */               .getText().trim(), this.RecipientEX.getText().trim(), "", "", "", 0);
/* 4352 */           GUEDisabled.this.expe1.ExpenseUpdate();
/*      */           
/* 4354 */           GUEDisabled.this.expe1.setGPID("GranteeExpenses" + GUEDisabled.this.TextGranteeIDExpenses.getText().trim() + "_" + Integer.valueOf(this.table.getValueAt(this.row, 5).toString()));
/* 4355 */           GUEDisabled.this.expe1.PublicExpensesUpdate();
/* 4356 */           GUEDisabled.this.ShowExpenses();
/*      */         } else {
/* 4358 */           String eror = ""; int i;
/* 4359 */           for (i = 0; i < valid.size(); i++) {
/* 4360 */             eror = eror + (String)valid.get(i) + "<br>";
/*      */           }
/*      */           
/* 4363 */           for (i = 0; i < validInt.size(); i++) {
/* 4364 */             eror = eror + (String)validInt.get(i) + "<br>";
/*      */           }
/*      */           
/* 4367 */           (new MessageInfo()).getERRMessage(eror, "  خطأ");
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 4372 */         GUEDisabled.this.setCursor(new Cursor(0));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 4379 */       this.table = table;
/* 4380 */       this.row = row;
/* 4381 */       this.col = column;
/*      */       
/* 4383 */       this.button.setForeground(Color.black);
/* 4384 */       this.button.setBackground(UIManager.getColor("Button.background"));
/* 4385 */       this.label = (value == null) ? "" : value.toString();
/* 4386 */       this.button.setText(this.label);
/* 4387 */       this.clicked = true;
/* 4388 */       return this.button;
/*      */     }
/*      */     
/*      */     public Object getCellEditorValue() {
/* 4392 */       this.clicked = false;
/* 4393 */       return new String(this.label);
/*      */     }
/*      */     
/*      */     public boolean stopCellEditing() {
/* 4397 */       this.clicked = false;
/* 4398 */       return super.stopCellEditing();
/*      */     }
/*      */     
/*      */     protected void fireEditingStopped() {
/* 4402 */       super.fireEditingStopped();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\GUEs\GUEDisabled.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */