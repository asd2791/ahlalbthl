/*     */ package GUEs;
/*     */ import JointInfo.InfoExpense;
/*     */ import JointInfo.InfoGrantees;
/*     */ import JointInfo.InfoPayment;
/*     */ import JointInfo.InfoSponsors;
/*     */ import Setings.TablesSeting;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.logging.Level;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class OverallReports extends JFrame {
/*     */   private JTextField[] textsCount;
/*     */   private JTextField[] textsDate;
/*     */   private JTextField[] textsDate2;
/*  36 */   private String[] ColomonsNames1 = new String[] { "الكافل", "اسم المستلم", "في تاريخ", "المبلغ المصروف", "عدد أفراد الأسرة", "حالة الأسرة", "القسم", "اسم المستفيد" };
/*  37 */   private int[] ColomonsSize1 = new int[] { 60, 60, 60, 60, 30, 60, 60, 60 };
/*     */   
/*  39 */   private String[] ColomonsNames2 = new String[] { "في تاريخ", "المبلغ", "القسم", "اسم المستفيد", "اسم الكافل" };
/*  40 */   private int[] ColomonsSize2 = new int[] { 30, 30, 60, 60, 30 };
/*     */ 
/*     */   
/*  43 */   private InfoGrantees gran = new InfoGrantees();
/*  44 */   private InfoPayment pay = new InfoPayment();
/*  45 */   private InfoSponsors spo = new InfoSponsors();
/*  46 */   private InfoExpense expe1 = new InfoExpense();
/*     */   private ArrayList<InfoGrantees> grantee;
/*     */   private ArrayList<InfoSponsors> sponsors;
/*  49 */   private Color MyGray = new Color(204, 204, 204);
/*  50 */   private Color MyWhite = new Color(255, 255, 255); private JComboBox BoxDate; private JComboBox BoxDate2; private JComboBox BoxFamilyCunte; private JComboBox BoxFamilyStuts; private JComboBox BoxFamilyType; private JComboBox BoxFamilyType2; private JTable TableExpense; private JTable TablePyments; private JTextField TextCountFrom; private JTextField TextCountTo; private JTextField TextFromDay; private JTextField TextFromDay2; private JTextField TextFromMonth; private JTextField TextFromMonth2;
/*  51 */   private int sel = -1; private JTextField TextFromYear; private JTextField TextFromYear2; private JTextField TextToDay; private JTextField TextToDay2; private JTextField TextToMonth; private JTextField TextToMonth2; private JTextField TextToYear; private JTextField TextToYear2; private JButton home; private JButton jButton1; private JButton jButton2;
/*     */   private JButton jButton3;
/*     */   private JButton jButton4;
/*     */   
/*     */   public OverallReports() {
/*  56 */     initComponents();
/*  57 */     setLocationRelativeTo(null);
/*  58 */     this.jTabbedPane1.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  59 */     this.jScrollPane5.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*     */     
/*  61 */     this.textsCount = new JTextField[] { this.TextCountFrom, this.TextCountTo };
/*  62 */     this.textsDate = new JTextField[] { this.TextFromYear, this.TextFromMonth, this.TextFromDay, this.TextToYear, this.TextToMonth, this.TextToDay };
/*  63 */     this.textsDate2 = new JTextField[] { this.TextFromYear2, this.TextFromMonth2, this.TextFromDay2, this.TextToYear2, this.TextToMonth2, this.TextToDay2 };
/*     */     
/*  65 */     CloseGUI(this.textsDate, this.MyGray, false);
/*  66 */     CloseGUI(this.textsCount, this.MyGray, false);
/*  67 */     CloseGUI(this.textsDate2, this.MyGray, false);
/*     */   }
/*     */   private JLabel jLabel1; private JLabel jLabel10; private JLabel jLabel11; private JLabel jLabel12; private JLabel jLabel13; private JLabel jLabel14; private JLabel jLabel18; private JLabel jLabel2; private JLabel jLabel37; private JLabel jLabel38; private JLabel jLabel39; private JLabel jLabel4; private JLabel jLabel40; private JLabel jLabel41; private JLabel jLabel42; private JLabel jLabel5; private JLabel jLabel62; private JLabel jLabel63; private JLabel jLabel7; private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel3;
/*     */   private JPanel jPanel7;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JScrollPane jScrollPane2;
/*     */   private JScrollPane jScrollPane5;
/*     */   private JTabbedPane jTabbedPane1;
/*     */   
/*     */   private void initComponents() {
/*  80 */     this.jTabbedPane1 = new JTabbedPane();
/*  81 */     this.jPanel1 = new JPanel();
/*  82 */     this.jLabel1 = new JLabel();
/*  83 */     this.jLabel4 = new JLabel();
/*  84 */     this.BoxFamilyCunte = new JComboBox();
/*  85 */     this.BoxFamilyStuts = new JComboBox();
/*  86 */     this.BoxDate = new JComboBox();
/*  87 */     this.TextCountFrom = new JTextField();
/*  88 */     this.jLabel7 = new JLabel();
/*  89 */     this.jLabel8 = new JLabel();
/*  90 */     this.jLabel37 = new JLabel();
/*  91 */     this.jLabel38 = new JLabel();
/*  92 */     this.jLabel39 = new JLabel();
/*  93 */     this.jLabel62 = new JLabel();
/*  94 */     this.TextFromYear = new JTextField();
/*  95 */     this.TextFromMonth = new JTextField();
/*  96 */     this.TextFromDay = new JTextField();
/*  97 */     this.TextToYear = new JTextField();
/*  98 */     this.TextToMonth = new JTextField();
/*  99 */     this.TextToDay = new JTextField();
/* 100 */     this.TextCountTo = new JTextField();
/* 101 */     this.jLabel9 = new JLabel();
/* 102 */     this.jLabel10 = new JLabel();
/* 103 */     this.jLabel11 = new JLabel();
/* 104 */     this.jLabel12 = new JLabel();
/* 105 */     this.BoxFamilyType = new JComboBox();
/* 106 */     this.jLabel2 = new JLabel();
/* 107 */     this.jButton1 = new JButton();
/* 108 */     this.jScrollPane5 = new JScrollPane();
/* 109 */     this.jPanel7 = new JPanel();
/* 110 */     this.jScrollPane1 = new JScrollPane();
/* 111 */     this.TableExpense = new JTable();
/* 112 */     this.jButton3 = new JButton();
/* 113 */     this.jPanel3 = new JPanel();
/* 114 */     this.jLabel5 = new JLabel();
/* 115 */     this.BoxDate2 = new JComboBox();
/* 116 */     this.jLabel14 = new JLabel();
/* 117 */     this.jLabel40 = new JLabel();
/* 118 */     this.jLabel41 = new JLabel();
/* 119 */     this.jLabel42 = new JLabel();
/* 120 */     this.jLabel63 = new JLabel();
/* 121 */     this.TextFromYear2 = new JTextField();
/* 122 */     this.TextFromMonth2 = new JTextField();
/* 123 */     this.TextFromDay2 = new JTextField();
/* 124 */     this.TextToYear2 = new JTextField();
/* 125 */     this.TextToMonth2 = new JTextField();
/* 126 */     this.TextToDay2 = new JTextField();
/* 127 */     this.jLabel18 = new JLabel();
/* 128 */     this.BoxFamilyType2 = new JComboBox();
/* 129 */     this.jButton2 = new JButton();
/* 130 */     this.jLabel13 = new JLabel();
/* 131 */     this.jButton4 = new JButton();
/* 132 */     this.jScrollPane2 = new JScrollPane();
/* 133 */     this.TablePyments = new JTable();
/* 134 */     this.home = new JButton();
/*     */     
/* 136 */     setDefaultCloseOperation(3);
/*     */     
/* 138 */     this.jTabbedPane1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 140 */             OverallReports.this.jTabbedPane1MouseClicked(evt);
/*     */           }
/*     */         });
/*     */     
/* 144 */     this.jPanel1.setLayout((LayoutManager)null);
/*     */     
/* 146 */     this.jLabel1.setText("حالة أسرة المستفيدين");
/* 147 */     this.jPanel1.add(this.jLabel1);
/* 148 */     this.jLabel1.setBounds(550, 40, 162, 27);
/*     */     
/* 150 */     this.jLabel4.setText("تاريخ صرف المبالغ");
/* 151 */     this.jPanel1.add(this.jLabel4);
/* 152 */     this.jLabel4.setBounds(103, 40, 200, 27);
/*     */     
/* 154 */     this.BoxFamilyCunte.setModel(new DefaultComboBoxModel<>(new String[] { "أي عدد", "عدد مخصص" }));
/* 155 */     this.BoxFamilyCunte.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent evt) {
/* 157 */             OverallReports.this.BoxFamilyCunteItemStateChanged(evt);
/*     */           }
/*     */         });
/* 160 */     this.jPanel1.add(this.BoxFamilyCunte);
/* 161 */     this.BoxFamilyCunte.setBounds(330, 70, 170, 37);
/*     */     
/* 163 */     this.BoxFamilyStuts.setModel(new DefaultComboBoxModel<>(new String[] { "الجميع", "أسرة ضعفها بسيط", "أسرة ضعفها متوسط", "أسرة ضعفها شديد" }));
/* 164 */     this.BoxFamilyStuts.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 166 */             OverallReports.this.BoxFamilyStutsKeyPressed(evt);
/*     */           }
/*     */         });
/* 169 */     this.jPanel1.add(this.BoxFamilyStuts);
/* 170 */     this.BoxFamilyStuts.setBounds(540, 70, 162, 37);
/*     */     
/* 172 */     this.BoxDate.setModel(new DefaultComboBoxModel<>(new String[] { "أي تاريخ", "تاريخ مخصص" }));
/* 173 */     this.BoxDate.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent evt) {
/* 175 */             OverallReports.this.BoxDateItemStateChanged(evt);
/*     */           }
/*     */         });
/* 178 */     this.jPanel1.add(this.BoxDate);
/* 179 */     this.BoxDate.setBounds(50, 70, 190, 37);
/*     */     
/* 181 */     this.TextCountFrom.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 183 */             OverallReports.this.TextCountFromKeyPressed(evt);
/*     */           }
/*     */         });
/* 186 */     this.jPanel1.add(this.TextCountFrom);
/* 187 */     this.TextCountFrom.setBounds(430, 170, 60, 40);
/*     */     
/* 189 */     this.jLabel7.setText("إلى :");
/* 190 */     this.jPanel1.add(this.jLabel7);
/* 191 */     this.jLabel7.setBounds(350, 140, 80, 20);
/*     */     
/* 193 */     this.jLabel8.setText("من :");
/* 194 */     this.jPanel1.add(this.jLabel8);
/* 195 */     this.jLabel8.setBounds(250, 180, 80, 30);
/*     */     
/* 197 */     this.jLabel37.setText("عام");
/* 198 */     this.jPanel1.add(this.jLabel37);
/* 199 */     this.jLabel37.setBounds(60, 140, 70, 20);
/*     */     
/* 201 */     this.jLabel38.setText("شهر");
/* 202 */     this.jPanel1.add(this.jLabel38);
/* 203 */     this.jLabel38.setBounds(140, 140, 50, 20);
/*     */     
/* 205 */     this.jLabel39.setText("يوم");
/* 206 */     this.jPanel1.add(this.jLabel39);
/* 207 */     this.jLabel39.setBounds(200, 140, 70, 20);
/*     */     
/* 209 */     this.jLabel62.setText("ضع التاريخ رقمًا");
/* 210 */     this.jPanel1.add(this.jLabel62);
/* 211 */     this.jLabel62.setBounds(100, 110, 150, 20);
/*     */     
/* 213 */     this.TextFromYear.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 215 */             OverallReports.this.TextFromYearKeyPressed(evt);
/*     */           }
/*     */         });
/* 218 */     this.jPanel1.add(this.TextFromYear);
/* 219 */     this.TextFromYear.setBounds(50, 170, 70, 40);
/*     */     
/* 221 */     this.TextFromMonth.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 223 */             OverallReports.this.TextFromMonthKeyPressed(evt);
/*     */           }
/*     */         });
/* 226 */     this.jPanel1.add(this.TextFromMonth);
/* 227 */     this.TextFromMonth.setBounds(130, 170, 50, 40);
/*     */     
/* 229 */     this.TextFromDay.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 231 */             OverallReports.this.TextFromDayKeyPressed(evt);
/*     */           }
/*     */         });
/* 234 */     this.jPanel1.add(this.TextFromDay);
/* 235 */     this.TextFromDay.setBounds(190, 170, 50, 40);
/*     */     
/* 237 */     this.TextToYear.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 239 */             OverallReports.this.TextToYearKeyPressed(evt);
/*     */           }
/*     */         });
/* 242 */     this.jPanel1.add(this.TextToYear);
/* 243 */     this.TextToYear.setBounds(50, 230, 70, 40);
/*     */     
/* 245 */     this.TextToMonth.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 247 */             OverallReports.this.TextToMonthKeyPressed(evt);
/*     */           }
/*     */         });
/* 250 */     this.jPanel1.add(this.TextToMonth);
/* 251 */     this.TextToMonth.setBounds(130, 230, 50, 40);
/*     */     
/* 253 */     this.TextToDay.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 255 */             OverallReports.this.TextToDayKeyPressed(evt);
/*     */           }
/*     */         });
/* 258 */     this.jPanel1.add(this.TextToDay);
/* 259 */     this.TextToDay.setBounds(190, 230, 50, 40);
/* 260 */     this.jPanel1.add(this.TextCountTo);
/* 261 */     this.TextCountTo.setBounds(340, 170, 60, 40);
/*     */     
/* 263 */     this.jLabel9.setText("ضع العدد رقمًا");
/* 264 */     this.jPanel1.add(this.jLabel9);
/* 265 */     this.jLabel9.setBounds(360, 120, 160, 20);
/*     */     
/* 267 */     this.jLabel10.setText("القسم");
/* 268 */     this.jPanel1.add(this.jLabel10);
/* 269 */     this.jLabel10.setBounds(750, 30, 110, 30);
/*     */     
/* 271 */     this.jLabel11.setText("من :");
/* 272 */     this.jPanel1.add(this.jLabel11);
/* 273 */     this.jLabel11.setBounds(450, 140, 80, 20);
/*     */     
/* 275 */     this.jLabel12.setText("إلى :");
/* 276 */     this.jPanel1.add(this.jLabel12);
/* 277 */     this.jLabel12.setBounds(250, 230, 80, 30);
/*     */     
/* 279 */     this.BoxFamilyType.setModel(new DefaultComboBoxModel<>(new String[] { "الجميع", "الأيتام", "المعاقين", "الأرامل", "الفقراء والمساكين" }));
/* 280 */     this.jPanel1.add(this.BoxFamilyType);
/* 281 */     this.BoxFamilyType.setBounds(720, 70, 162, 37);
/*     */     
/* 283 */     this.jLabel2.setText("عدد أفراد الأسرة");
/* 284 */     this.jPanel1.add(this.jLabel2);
/* 285 */     this.jLabel2.setBounds(370, 45, 170, 20);
/*     */     
/* 287 */     this.jButton1.setText("عرض حسب المعطيات السابقة");
/* 288 */     this.jButton1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 290 */             OverallReports.this.jButton1ActionPerformed(evt);
/*     */           }
/*     */         });
/* 293 */     this.jPanel1.add(this.jButton1);
/* 294 */     this.jButton1.setBounds(230, 290, 600, 50);
/*     */     
/* 296 */     this.TableExpense.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "الكافل", "اسم المستلم", "في تاريخ", "المبلغ المصروف", "عدد أفراد الأسرة", "حالة الأسرة", "القسم", "اسم المستفيد" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     this.jScrollPane1.setViewportView(this.TableExpense);
/*     */     
/* 306 */     GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
/* 307 */     this.jPanel7.setLayout(jPanel7Layout);
/* 308 */     jPanel7Layout.setHorizontalGroup(jPanel7Layout
/* 309 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 310 */         .addGroup(jPanel7Layout.createSequentialGroup()
/* 311 */           .addGap(25, 25, 25)
/* 312 */           .addComponent(this.jScrollPane1, -2, 1156, -2)
/* 313 */           .addContainerGap(26, 32767)));
/*     */     
/* 315 */     jPanel7Layout.setVerticalGroup(jPanel7Layout
/* 316 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 317 */         .addGroup(jPanel7Layout.createSequentialGroup()
/* 318 */           .addContainerGap()
/* 319 */           .addComponent(this.jScrollPane1, -2, 90, -2)
/* 320 */           .addContainerGap(20, 32767)));
/*     */ 
/*     */     
/* 323 */     this.jScrollPane5.setViewportView(this.jPanel7);
/*     */     
/* 325 */     this.jPanel1.add(this.jScrollPane5);
/* 326 */     this.jScrollPane5.setBounds(50, 350, 920, 130);
/*     */     
/* 328 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/* 329 */     this.jButton3.setText("تقرير");
/* 330 */     this.jButton3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 332 */             OverallReports.this.jButton3ActionPerformed(evt);
/*     */           }
/*     */         });
/* 335 */     this.jPanel1.add(this.jButton3);
/* 336 */     this.jButton3.setBounds(350, 500, 320, 42);
/*     */     
/* 338 */     this.jTabbedPane1.addTab("تقارير شاملة لمصروفات المستفيدين", this.jPanel1);
/*     */     
/* 340 */     this.jPanel3.setLayout((LayoutManager)null);
/*     */     
/* 342 */     this.jLabel5.setText("تاريخ دفع المبالغ");
/* 343 */     this.jPanel3.add(this.jLabel5);
/* 344 */     this.jLabel5.setBounds(420, 30, 200, 27);
/*     */     
/* 346 */     this.BoxDate2.setModel(new DefaultComboBoxModel<>(new String[] { "أي تاريخ", "تاريخ مخصص" }));
/* 347 */     this.BoxDate2.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent evt) {
/* 349 */             OverallReports.this.BoxDate2ItemStateChanged(evt);
/*     */           }
/*     */         });
/* 352 */     this.jPanel3.add(this.BoxDate2);
/* 353 */     this.BoxDate2.setBounds(360, 60, 190, 37);
/*     */     
/* 355 */     this.jLabel14.setText("من :");
/* 356 */     this.jPanel3.add(this.jLabel14);
/* 357 */     this.jLabel14.setBounds(560, 170, 80, 30);
/*     */     
/* 359 */     this.jLabel40.setText("عام");
/* 360 */     this.jPanel3.add(this.jLabel40);
/* 361 */     this.jLabel40.setBounds(370, 130, 70, 20);
/*     */     
/* 363 */     this.jLabel41.setText("شهر");
/* 364 */     this.jPanel3.add(this.jLabel41);
/* 365 */     this.jLabel41.setBounds(450, 130, 50, 20);
/*     */     
/* 367 */     this.jLabel42.setText("يوم");
/* 368 */     this.jPanel3.add(this.jLabel42);
/* 369 */     this.jLabel42.setBounds(510, 130, 70, 20);
/*     */     
/* 371 */     this.jLabel63.setText("ضع التاريخ رقمًا");
/* 372 */     this.jPanel3.add(this.jLabel63);
/* 373 */     this.jLabel63.setBounds(410, 100, 150, 20);
/*     */     
/* 375 */     this.TextFromYear2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 377 */             OverallReports.this.TextFromYear2KeyPressed(evt);
/*     */           }
/*     */         });
/* 380 */     this.jPanel3.add(this.TextFromYear2);
/* 381 */     this.TextFromYear2.setBounds(360, 160, 70, 40);
/*     */     
/* 383 */     this.TextFromMonth2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 385 */             OverallReports.this.TextFromMonth2KeyPressed(evt);
/*     */           }
/*     */         });
/* 388 */     this.jPanel3.add(this.TextFromMonth2);
/* 389 */     this.TextFromMonth2.setBounds(440, 160, 50, 40);
/*     */     
/* 391 */     this.TextFromDay2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 393 */             OverallReports.this.TextFromDay2KeyPressed(evt);
/*     */           }
/*     */         });
/* 396 */     this.jPanel3.add(this.TextFromDay2);
/* 397 */     this.TextFromDay2.setBounds(500, 160, 50, 40);
/*     */     
/* 399 */     this.TextToYear2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 401 */             OverallReports.this.TextToYear2KeyPressed(evt);
/*     */           }
/*     */         });
/* 404 */     this.jPanel3.add(this.TextToYear2);
/* 405 */     this.TextToYear2.setBounds(360, 220, 70, 40);
/*     */     
/* 407 */     this.TextToMonth2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 409 */             OverallReports.this.TextToMonth2KeyPressed(evt);
/*     */           }
/*     */         });
/* 412 */     this.jPanel3.add(this.TextToMonth2);
/* 413 */     this.TextToMonth2.setBounds(440, 220, 50, 40);
/*     */     
/* 415 */     this.TextToDay2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 417 */             OverallReports.this.TextToDay2KeyPressed(evt);
/*     */           }
/*     */         });
/* 420 */     this.jPanel3.add(this.TextToDay2);
/* 421 */     this.TextToDay2.setBounds(500, 220, 50, 40);
/*     */     
/* 423 */     this.jLabel18.setText("إلى :");
/* 424 */     this.jPanel3.add(this.jLabel18);
/* 425 */     this.jLabel18.setBounds(560, 220, 80, 30);
/*     */     
/* 427 */     this.BoxFamilyType2.setModel(new DefaultComboBoxModel<>(new String[] { "الجميع", "الأيتام", "المعاقين", "الأرامل", "الفقراء والمساكين" }));
/* 428 */     this.BoxFamilyType2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 430 */             OverallReports.this.BoxFamilyType2KeyPressed(evt);
/*     */           }
/*     */         });
/* 433 */     this.jPanel3.add(this.BoxFamilyType2);
/* 434 */     this.BoxFamilyType2.setBounds(720, 70, 162, 37);
/*     */     
/* 436 */     this.jButton2.setText("عرض حسب المعطيات السابقة");
/* 437 */     this.jButton2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 439 */             OverallReports.this.jButton2ActionPerformed(evt);
/*     */           }
/*     */         });
/* 442 */     this.jPanel3.add(this.jButton2);
/* 443 */     this.jButton2.setBounds(230, 290, 600, 50);
/*     */     
/* 445 */     this.jLabel13.setText("القسم");
/* 446 */     this.jPanel3.add(this.jLabel13);
/* 447 */     this.jLabel13.setBounds(750, 30, 110, 30);
/*     */     
/* 449 */     this.jButton4.setIcon(new ImageIcon(getClass().getResource("/images/printer.png")));
/* 450 */     this.jButton4.setText("تقرير");
/* 451 */     this.jButton4.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 453 */             OverallReports.this.jButton4ActionPerformed(evt);
/*     */           }
/*     */         });
/* 456 */     this.jPanel3.add(this.jButton4);
/* 457 */     this.jButton4.setBounds(350, 480, 320, 50);
/*     */     
/* 459 */     this.TablePyments.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null }, , { null, null, null, null, null }, , { null, null, null, null, null }, , { null, null, null, null, null },  }, (Object[])new String[] { "في تاريخ", "المبلغ", "القسم", "اسم المستفيد", "الكافل" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 470 */     this.jScrollPane2.setViewportView(this.TablePyments);
/*     */     
/* 472 */     this.jPanel3.add(this.jScrollPane2);
/* 473 */     this.jScrollPane2.setBounds(110, 380, 830, 90);
/*     */     
/* 475 */     this.jTabbedPane1.addTab("تقارير شاملة لمدفوعات الكفلاء", this.jPanel3);
/*     */     
/* 477 */     this.home.setIcon(new ImageIcon(getClass().getResource("/images/home.png")));
/* 478 */     this.home.setText("البداية");
/* 479 */     this.home.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 481 */             OverallReports.this.homeActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 485 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 486 */     getContentPane().setLayout(layout);
/* 487 */     layout.setHorizontalGroup(layout
/* 488 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 489 */         .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 490 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 491 */             .addGroup(layout.createSequentialGroup()
/* 492 */               .addContainerGap(-1, 32767)
/* 493 */               .addComponent(this.home, -2, 242, -2))
/* 494 */             .addGroup(layout.createSequentialGroup()
/* 495 */               .addGap(46, 46, 46)
/* 496 */               .addComponent(this.jTabbedPane1, -1, 1026, 32767)))
/* 497 */           .addContainerGap()));
/*     */     
/* 499 */     layout.setVerticalGroup(layout
/* 500 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 501 */         .addGroup(layout.createSequentialGroup()
/* 502 */           .addGap(23, 23, 23)
/* 503 */           .addComponent(this.jTabbedPane1, -2, 576, -2)
/* 504 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 505 */           .addComponent(this.home)
/* 506 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 509 */     pack();
/*     */   }
/*     */   
/*     */   public void OpenGUI(JTextField[] texts, JTextField textFocus, Color MyColor, boolean TextEnabled) {
/* 513 */     for (int i = 0; i < texts.length; i++) {
/* 514 */       texts[i].setText("");
/* 515 */       texts[i].setEnabled(TextEnabled);
/* 516 */       texts[i].setBackground(MyColor);
/*     */     } 
/* 518 */     textFocus.requestFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public void CloseGUI(JTextField[] texts, Color MyColor, boolean MyEnabled) {
/* 523 */     for (int i = 0; i < texts.length; i++) {
/* 524 */       texts[i].setText("");
/* 525 */       texts[i].setEnabled(MyEnabled);
/* 526 */       texts[i].setBackground(MyColor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void BoxFamilyStutsKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void TextFromYearKeyPressed(KeyEvent evt) {
/* 537 */     int key = evt.getKeyCode();
/* 538 */     if (key == 10) {
/* 539 */       this.TextToDay.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextFromMonthKeyPressed(KeyEvent evt) {
/* 544 */     int key = evt.getKeyCode();
/* 545 */     if (key == 10) {
/* 546 */       this.TextFromYear.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextFromDayKeyPressed(KeyEvent evt) {
/* 551 */     int key = evt.getKeyCode();
/* 552 */     if (key == 10) {
/* 553 */       this.TextFromMonth.requestFocus();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void TextToYearKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void TextToMonthKeyPressed(KeyEvent evt) {
/* 565 */     int key = evt.getKeyCode();
/* 566 */     if (key == 10) {
/* 567 */       this.TextToYear.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextToDayKeyPressed(KeyEvent evt) {
/* 572 */     int key = evt.getKeyCode();
/* 573 */     if (key == 10) {
/* 574 */       this.TextToMonth.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void BoxDateItemStateChanged(ItemEvent evt) {
/* 579 */     if (this.BoxDate.getSelectedItem().equals("أي تاريخ")) {
/* 580 */       CloseGUI(this.textsDate, this.MyGray, false);
/*     */     } else {
/* 582 */       OpenGUI(this.textsDate, this.TextFromDay, this.MyWhite, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void BoxFamilyCunteItemStateChanged(ItemEvent evt) {
/* 587 */     if (this.BoxFamilyCunte.getSelectedItem().equals("أي عدد")) {
/* 588 */       CloseGUI(this.textsCount, this.MyGray, false);
/*     */     } else {
/* 590 */       OpenGUI(this.textsCount, this.TextCountFrom, this.MyWhite, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 596 */     String[] CNPublicExpenses = { "Type", "FamilyStuets" };
/* 597 */     String ser = stringSe(CNPublicExpenses, new String[] { String.valueOf(this.BoxFamilyType.getSelectedIndex()), this.BoxFamilyStuts.getSelectedItem().toString() });
/* 598 */     String ser2 = "";
/* 599 */     if (!this.BoxFamilyCunte.getSelectedItem().toString().equals("أي عدد")) {
/* 600 */       ser2 = stringSeCount("FamilyCount", Integer.valueOf(this.TextCountFrom.getText().trim()).intValue(), Integer.valueOf(this.TextCountTo.getText().trim()).intValue(), String.valueOf(this.BoxFamilyCunte.getSelectedIndex()));
/*     */     }
/* 602 */     String ser3 = CllectSe(ser, ser2);
/* 603 */     ShowExpenses(ser3);
/*     */   }
/*     */   
/*     */   private void TextCountFromKeyPressed(KeyEvent evt) {
/* 607 */     int key = evt.getKeyCode();
/* 608 */     if (key == 10) {
/* 609 */       this.TextCountTo.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void BoxDate2ItemStateChanged(ItemEvent evt) {
/* 614 */     if (this.BoxDate2.getSelectedItem().equals("أي تاريخ")) {
/* 615 */       CloseGUI(this.textsDate2, this.MyGray, false);
/*     */     } else {
/* 617 */       OpenGUI(this.textsDate2, this.TextFromDay2, this.MyWhite, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void TextFromYear2KeyPressed(KeyEvent evt) {
/* 622 */     int key = evt.getKeyCode();
/* 623 */     if (key == 10) {
/* 624 */       this.TextToDay2.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextFromMonth2KeyPressed(KeyEvent evt) {
/* 629 */     int key = evt.getKeyCode();
/* 630 */     if (key == 10) {
/* 631 */       this.TextFromYear2.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextFromDay2KeyPressed(KeyEvent evt) {
/* 636 */     int key = evt.getKeyCode();
/* 637 */     if (key == 10) {
/* 638 */       this.TextFromMonth2.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextToYear2KeyPressed(KeyEvent evt) {
/* 643 */     int key = evt.getKeyCode();
/* 644 */     if (key == 10) {
/* 645 */       this.jButton2.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextToMonth2KeyPressed(KeyEvent evt) {
/* 650 */     int key = evt.getKeyCode();
/* 651 */     if (key == 10) {
/* 652 */       this.TextToYear2.requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void TextToDay2KeyPressed(KeyEvent evt) {
/* 657 */     int key = evt.getKeyCode();
/* 658 */     if (key == 10) {
/* 659 */       this.TextToMonth2.requestFocus();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void BoxFamilyType2KeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 669 */     String[] CNPublicPayments = { "Type" };
/* 670 */     String ser = stringSe(CNPublicPayments, new String[] { String.valueOf(this.BoxFamilyType2.getSelectedIndex()) });
/* 671 */     String ser2 = "";
/*     */     
/* 673 */     String ser3 = CllectSe(ser, ser2);
/* 674 */     ShowPayments(ser3);
/*     */   }
/*     */   
/*     */   private void jTabbedPane1MouseClicked(MouseEvent evt) {
/* 678 */     switch (this.jTabbedPane1.getSelectedIndex()) {
/*     */       case 0:
/* 680 */         if (this.sel != 0) {
/* 681 */           replaceTablesAndTexts();
/* 682 */           this.sel = 0;
/*     */         } 
/*     */         break;
/*     */       case 1:
/* 686 */         if (this.sel != 1) {
/* 687 */           replaceTablesAndTexts();
/* 688 */           this.sel = 1;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton3ActionPerformed(ActionEvent evt) {
/* 695 */     setCursor(new Cursor(3));
/*     */     
/*     */     try {
/* 698 */       ArrayList<InfoExpense> exr = new ArrayList<>();
/*     */ 
/*     */       
/* 701 */       for (int i = 0; i < this.TableExpense.getRowCount(); i++) {
/* 702 */         InfoExpense expR = new InfoExpense();
/* 703 */         if (this.TableExpense.getValueAt(i, 7) != null && !"".equals(this.TableExpense.getValueAt(i, 7).toString().trim())) {
/* 704 */           expR.setGranteesName(this.TableExpense.getValueAt(i, 7).toString().trim());
/*     */         } else {
/* 706 */           expR.setGranteesName("");
/*     */         } 
/* 708 */         if (this.TableExpense.getValueAt(i, 6) != null && !"".equals(this.TableExpense.getValueAt(i, 6).toString().trim())) {
/* 709 */           expR.setType(this.TableExpense.getValueAt(i, 6).toString().trim());
/*     */         } else {
/* 711 */           expR.setType("");
/*     */         } 
/* 713 */         if (this.TableExpense.getValueAt(i, 5) != null && !"".equals(this.TableExpense.getValueAt(i, 5).toString().trim())) {
/* 714 */           expR.setFamilyStuets(this.TableExpense.getValueAt(i, 5).toString().trim());
/*     */         } else {
/* 716 */           expR.setFamilyStuets("");
/*     */         } 
/* 718 */         if (this.TableExpense.getValueAt(i, 4) != null && !"".equals(this.TableExpense.getValueAt(i, 4).toString().trim())) {
/* 719 */           expR.setFamilyCount(Integer.valueOf(this.TableExpense.getValueAt(i, 4).toString().trim()).intValue());
/*     */         } else {
/* 721 */           expR.setFamilyCount(0);
/*     */         } 
/* 723 */         if (this.TableExpense.getValueAt(i, 3) != null && !"".equals(this.TableExpense.getValueAt(i, 3).toString().trim())) {
/* 724 */           expR.setValueExpense(this.TableExpense.getValueAt(i, 3).toString().trim());
/*     */         } else {
/* 726 */           expR.setValueExpense("");
/*     */         } 
/* 728 */         String[] dateAll = new String[0];
/* 729 */         if (this.TableExpense.getValueAt(i, 2) != null && !"".equals(this.TableExpense.getValueAt(i, 2).toString().trim()))
/*     */         {
/* 731 */           dateAll = this.TableExpense.getValueAt(i, 2).toString().split("-");
/*     */         }
/* 733 */         if (dateAll.length > 1) {
/* 734 */           expR.setExpenseDay(Integer.valueOf(dateAll[2]).intValue());
/*     */         } else {
/* 736 */           expR.setExpenseDay(0);
/*     */         } 
/* 738 */         if (dateAll.length > 1) {
/* 739 */           expR.setExpenseMonth(Integer.valueOf(dateAll[1]).intValue());
/*     */         } else {
/* 741 */           expR.setExpenseMonth(0);
/*     */         } 
/* 743 */         if (dateAll.length > 1) {
/* 744 */           expR.setExpenseYear(Integer.valueOf(dateAll[0]).intValue());
/*     */         } else {
/* 746 */           expR.setExpenseYear(0);
/*     */         } 
/*     */         
/* 749 */         if (this.TableExpense.getValueAt(i, 1) != null && !"".equals(this.TableExpense.getValueAt(i, 1).toString().trim())) {
/* 750 */           expR.setRecipientName(this.TableExpense.getValueAt(i, 1).toString().trim());
/*     */         } else {
/* 752 */           expR.setRecipientName("");
/*     */         } 
/* 754 */         if (this.TableExpense.getValueAt(i, 0) != null && !"".equals(this.TableExpense.getValueAt(i, 0).toString().trim())) {
/* 755 */           expR.setSponsorsName(this.TableExpense.getValueAt(i, 0).toString().trim());
/*     */         } else {
/* 757 */           expR.setSponsorsName("");
/*     */         } 
/* 759 */         exr.add(expR);
/*     */       } 
/* 761 */       if (!exr.isEmpty()) {
/* 762 */         ReportsManager.getInstance().showReport("Reports/Public/GranteesPublicReports.jasper", new Hashtable<>(), "مدفوعات الكفيل", exr);
/*     */       }
/*     */     } finally {
/* 765 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void jButton4ActionPerformed(ActionEvent evt) {
/* 770 */     setCursor(new Cursor(3));
/*     */     
/*     */     try {
/* 773 */       ArrayList<InfoPayment> payr = new ArrayList<>();
/*     */ 
/*     */       
/* 776 */       for (int i = 0; i < this.TablePyments.getRowCount(); i++) {
/* 777 */         InfoPayment payR = new InfoPayment();
/* 778 */         String[] dateAll = new String[0];
/* 779 */         if (this.TablePyments.getValueAt(i, 0) != null && !"".equals(this.TablePyments.getValueAt(i, 0).toString().trim()))
/*     */         {
/* 781 */           dateAll = this.TablePyments.getValueAt(i, 0).toString().split("-");
/*     */         }
/* 783 */         if (dateAll.length > 1) {
/* 784 */           payR.setPaymentDay(Integer.valueOf(dateAll[2]).intValue());
/*     */         } else {
/* 786 */           payR.setPaymentDay(0);
/*     */         } 
/* 788 */         if (dateAll.length > 1) {
/* 789 */           payR.setPaymentMonth(Integer.valueOf(dateAll[1]).intValue());
/*     */         } else {
/* 791 */           payR.setPaymentMonth(0);
/*     */         } 
/* 793 */         if (dateAll.length > 1) {
/* 794 */           payR.setPaymentYear(Integer.valueOf(dateAll[0]).intValue());
/*     */         } else {
/* 796 */           payR.setPaymentYear(0);
/*     */         } 
/*     */         
/* 799 */         if (this.TablePyments.getValueAt(i, 1) != null && !"".equals(this.TablePyments.getValueAt(i, 1).toString().trim())) {
/* 800 */           payR.setValuePayment(this.TablePyments.getValueAt(i, 1).toString().trim());
/*     */         } else {
/* 802 */           payR.setValuePayment("");
/*     */         } 
/* 804 */         if (this.TablePyments.getValueAt(i, 2) != null && !"".equals(this.TablePyments.getValueAt(i, 2).toString().trim())) {
/* 805 */           payR.setType(this.TablePyments.getValueAt(i, 2).toString().trim());
/*     */         } else {
/* 807 */           payR.setType("");
/*     */         } 
/* 809 */         if (this.TablePyments.getValueAt(i, 3) != null && !"".equals(this.TablePyments.getValueAt(i, 3).toString().trim())) {
/* 810 */           payR.setGranteesName(this.TablePyments.getValueAt(i, 3).toString().trim());
/*     */         } else {
/* 812 */           payR.setGranteesName("");
/*     */         } 
/*     */         
/* 815 */         if (this.TablePyments.getValueAt(i, 4) != null && !"".equals(this.TablePyments.getValueAt(i, 4).toString().trim())) {
/* 816 */           payR.setSponsorsName(this.TablePyments.getValueAt(i, 4).toString().trim());
/*     */         } else {
/* 818 */           payR.setSponsorsName("");
/*     */         } 
/*     */         
/* 821 */         payr.add(payR);
/*     */       } 
/* 823 */       if (!payr.isEmpty()) {
/* 824 */         ReportsManager.getInstance().showReport("Reports/Public/SponsorsPublicReports.jasper", new Hashtable<>(), "مدفوعات الكفيل", payr);
/*     */       }
/*     */     } finally {
/* 827 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void homeActionPerformed(ActionEvent evt) {
/*     */     try {
/* 833 */       setCursor(new Cursor(3));
/* 834 */       (new HumanitarianMain()).setVisible(true);
/* 835 */       dispose();
/*     */     } finally {
/* 837 */       setCursor(new Cursor(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void RemoveTable(JTable table, String[] ColomonsNames) {
/* 842 */     DefaultTableModel dtm = new DefaultTableModel();
/* 843 */     for (int i = 0; i < ColomonsNames.length; i++) {
/* 844 */       dtm.addColumn(ColomonsNames[i]);
/*     */     }
/* 846 */     table.setModel(dtm);
/*     */   }
/*     */   
/*     */   public void replaceTablesAndTexts() {
/* 850 */     RemoveTable(this.TablePyments, this.ColomonsNames2);
/* 851 */     RemoveTable(this.TableExpense, this.ColomonsNames1);
/*     */     
/* 853 */     CloseGUI(this.textsCount, this.MyGray, false);
/*     */     
/* 855 */     CloseGUI(this.textsDate, this.MyGray, false);
/* 856 */     CloseGUI(this.textsDate2, this.MyGray, false);
/* 857 */     this.BoxFamilyCunte.setSelectedIndex(0);
/* 858 */     this.BoxDate.setSelectedIndex(0);
/* 859 */     this.BoxFamilyStuts.setSelectedIndex(0);
/* 860 */     this.BoxFamilyType.setSelectedIndex(0);
/* 861 */     this.BoxFamilyType2.setSelectedIndex(0);
/* 862 */     this.BoxDate2.setSelectedIndex(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String CllectSe(String ser, String ser2) {
/* 868 */     if (ser.length() > 4) {
/* 869 */       ser = " WHERE " + ser.substring(0, ser.length() - 4) + ser2 + ";";
/* 870 */     } else if (ser2.length() > 4) {
/* 871 */       ser = " WHERE " + ser2.substring(5, ser2.length()) + ser2 + ";";
/*     */     } 
/*     */     
/* 874 */     return ser;
/*     */   }
/*     */   
/*     */   private String stringSeCount(String nameColomonCount, int countFrom, int countTo, String test) {
/* 878 */     String Sersh = "";
/* 879 */     if (!test.trim().isEmpty() && !test.trim().equals("أي عدد"))
/*     */     {
/* 881 */       Sersh = Sersh + " and " + nameColomonCount + ">=" + countFrom + " and " + nameColomonCount + "<=" + countTo;
/*     */     }
/* 883 */     return Sersh;
/*     */   }
/*     */   
/*     */   private String stringSe(String[] nameColomon, String... textString) {
/* 887 */     String Sersh = "";
/* 888 */     int in = 0;
/* 889 */     for (String textF : textString) {
/* 890 */       if (!textF.trim().isEmpty() && !textF.trim().equals("الجميع") && !textF.trim().equals("0")) {
/* 891 */         Sersh = Sersh + nameColomon[in] + "='" + textF + "' AND ";
/*     */       }
/* 893 */       in++;
/*     */     } 
/* 895 */     in = 0;
/* 896 */     return Sersh;
/*     */   }
/*     */   
/*     */   public void ShowExpenses(String ser) {
/*     */     try {
/* 901 */       InfoExpense expe = new InfoExpense();
/*     */       
/* 903 */       ArrayList<InfoExpense> expense = expe.getAllPublicExpenses(ser);
/* 904 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TableExpense, this.ColomonsNames1);
/* 905 */       this.TableExpense = (new TablesSeting()).ColomonSize(this.TableExpense, this.ColomonsSize1);
/* 906 */       for (int i = 0; i < expense.size(); i++) {
/* 907 */         String typa = "";
/* 908 */         if (((InfoExpense)expense.get(i)).getType().equals("1")) {
/* 909 */           typa = "قسم الأيتام";
/*     */         }
/* 911 */         if (((InfoExpense)expense.get(i)).getType().equals("2")) {
/* 912 */           typa = "قسم المعاقين";
/*     */         }
/* 914 */         if (((InfoExpense)expense.get(i)).getType().equals("3")) {
/* 915 */           typa = "قسم الأرامل";
/*     */         }
/* 917 */         if (((InfoExpense)expense.get(i)).getType().equals("4")) {
/* 918 */           typa = "قسم الفقراء";
/*     */         }
/* 920 */         if (this.BoxDate.getSelectedItem().toString().trim().equals("أي تاريخ")) {
/* 921 */           Object[] ary = { ((InfoExpense)expense.get(i)).getSponsorsName(), ((InfoExpense)expense.get(i)).getRecipientName(), ((InfoExpense)expense.get(i)).getExpenseYear() + "-" + ((InfoExpense)expense.get(i)).getExpenseMonth() + "-" + ((InfoExpense)expense.get(i)).getExpenseDay(), ((InfoExpense)expense.get(i)).getValueExpense(), Integer.valueOf(((InfoExpense)expense.get(i)).getFamilyCount()), ((InfoExpense)expense.get(i)).getFamilyStuets(), typa, ((InfoExpense)expense.get(i)).getGranteesName() };
/* 922 */           dtm.addRow(ary);
/*     */         } else {
/* 924 */           Date dateEx = new Date(((InfoExpense)expense.get(i)).getExpenseYear(), ((InfoExpense)expense.get(i)).getExpenseMonth(), ((InfoExpense)expense.get(i)).getExpenseDay());
/* 925 */           Date dateFrom = new Date(Integer.valueOf(this.TextFromYear.getText().trim()).intValue(), Integer.valueOf(this.TextFromMonth.getText().trim()).intValue(), Integer.valueOf(this.TextFromDay.getText().trim()).intValue());
/* 926 */           Date dateTo = new Date(Integer.valueOf(this.TextToYear.getText().trim()).intValue(), Integer.valueOf(this.TextToMonth.getText().trim()).intValue(), Integer.valueOf(this.TextToDay.getText().trim()).intValue());
/* 927 */           if ((dateEx.after(dateFrom) || dateEx.equals(dateFrom)) && (
/* 928 */             dateEx.before(dateTo) || dateEx.equals(dateTo))) {
/* 929 */             Object[] ary = { ((InfoExpense)expense.get(i)).getSponsorsName(), ((InfoExpense)expense.get(i)).getRecipientName(), ((InfoExpense)expense.get(i)).getExpenseYear() + "-" + ((InfoExpense)expense.get(i)).getExpenseMonth() + "-" + ((InfoExpense)expense.get(i)).getExpenseDay(), ((InfoExpense)expense.get(i)).getValueExpense(), Integer.valueOf(((InfoExpense)expense.get(i)).getFamilyCount()), ((InfoExpense)expense.get(i)).getFamilyStuets(), typa, ((InfoExpense)expense.get(i)).getGranteesName() };
/* 930 */             dtm.addRow(ary);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 935 */     } catch (Exception ex) {
/* 936 */       Logger.getLogger(OverallReports.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void ShowPayments(String ser) {
/*     */     try {
/* 943 */       InfoPayment pay = new InfoPayment();
/*     */       
/* 945 */       ArrayList<InfoPayment> payments = pay.getAllPublicPayments(ser);
/* 946 */       DefaultTableModel dtm = (new TablesSeting()).ColomonName(this.TablePyments, this.ColomonsNames2);
/* 947 */       this.TablePyments = (new TablesSeting()).ColomonSize(this.TablePyments, this.ColomonsSize2);
/* 948 */       for (int i = 0; i < payments.size(); i++) {
/* 949 */         String typa = "";
/* 950 */         if (((InfoPayment)payments.get(i)).getType().equals("1")) {
/* 951 */           typa = "قسم الأيتام";
/*     */         }
/* 953 */         if (((InfoPayment)payments.get(i)).getType().equals("2")) {
/* 954 */           typa = "قسم المعاقين";
/*     */         }
/* 956 */         if (((InfoPayment)payments.get(i)).getType().equals("3")) {
/* 957 */           typa = "قسم الأرامل";
/*     */         }
/* 959 */         if (((InfoPayment)payments.get(i)).getType().equals("4")) {
/* 960 */           typa = "قسم الفقراء";
/*     */         }
/* 962 */         if (this.BoxDate2.getSelectedItem().toString().trim().equals("أي تاريخ")) {
/*     */           
/* 964 */           Object[] ary = { ((InfoPayment)payments.get(i)).getPaymentYear() + "-" + ((InfoPayment)payments.get(i)).getPaymentMonth() + "-" + ((InfoPayment)payments.get(i)).getPaymentDay(), ((InfoPayment)payments.get(i)).getValuePayment(), typa, ((InfoPayment)payments.get(i)).getGranteesName(), ((InfoPayment)payments.get(i)).getSponsorsName() };
/* 965 */           dtm.addRow(ary);
/*     */         } else {
/* 967 */           Date datePay = new Date(((InfoPayment)payments.get(i)).getPaymentYear(), ((InfoPayment)payments.get(i)).getPaymentMonth(), ((InfoPayment)payments.get(i)).getPaymentDay());
/* 968 */           Date dateFrom = new Date(Integer.valueOf(this.TextFromYear2.getText().trim()).intValue(), Integer.valueOf(this.TextFromMonth2.getText().trim()).intValue(), Integer.valueOf(this.TextFromDay2.getText().trim()).intValue());
/* 969 */           Date dateTo = new Date(Integer.valueOf(this.TextToYear2.getText().trim()).intValue(), Integer.valueOf(this.TextToMonth2.getText().trim()).intValue(), Integer.valueOf(this.TextToDay2.getText().trim()).intValue());
/* 970 */           if ((datePay.after(dateFrom) || datePay.equals(dateFrom)) && (
/* 971 */             datePay.before(dateTo) || datePay.equals(dateTo)))
/*     */           {
/* 973 */             Object[] ary = { ((InfoPayment)payments.get(i)).getPaymentYear() + "-" + ((InfoPayment)payments.get(i)).getPaymentMonth() + "-" + ((InfoPayment)payments.get(i)).getPaymentDay(), ((InfoPayment)payments.get(i)).getValuePayment(), typa, ((InfoPayment)payments.get(i)).getGranteesName(), ((InfoPayment)payments.get(i)).getSponsorsName() };
/* 974 */             dtm.addRow(ary);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 979 */     } catch (Exception ex) {
/* 980 */       Logger.getLogger(OverallReports.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 990 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 992 */             (new OverallReports()).setVisible(true);
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\GUEs\OverallReports.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */