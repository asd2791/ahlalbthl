/*     */ package JointInfo;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoGrantees
/*     */ {
/*  23 */   private DBConnect c = new DBConnect();
/*  24 */   private Searching ser = new Searching();
/*     */   
/*     */   private Statement s;
/*     */   
/*     */   private int id;
/*     */   
/*     */   private String GranteeName;
/*     */   
/*     */   private String RegestryType;
/*     */   
/*     */   private String RegestryID;
/*     */   
/*     */   private String DateBirth;
/*     */   
/*     */   private String CityName;
/*     */   
/*     */   private String CrownGrantee;
/*     */   private Image Kroki;
/*     */   private String GranteeConnect;
/*     */   private String GranteeAccount;
/*     */   private String SponsorsName;
/*     */   private String SponsorsID;
/*     */   private String FamilyCount;
/*     */   private String FamilyStuets;
/*     */   private String Type;
/*     */   
/*     */   public InfoGrantees() {}
/*     */   
/*     */   public InfoGrantees(int id, String GranteeName, String RegestryType, String RegestryID, String DateBirth, String CityName, String CrownGrantee, String GranteeConnect, String GranteeAccount, String SponsorsName, String SponsorsID, String FamilyCount, String FamilyStuets, String Type) {
/*  53 */     this.id = id;
/*  54 */     this.GranteeName = GranteeName;
/*  55 */     this.RegestryType = RegestryType;
/*  56 */     this.RegestryID = RegestryID;
/*  57 */     this.DateBirth = DateBirth;
/*  58 */     this.CityName = CityName;
/*  59 */     this.CrownGrantee = CrownGrantee;
/*  60 */     this.GranteeConnect = GranteeConnect;
/*  61 */     this.GranteeAccount = GranteeAccount;
/*  62 */     this.SponsorsName = SponsorsName;
/*  63 */     this.SponsorsID = SponsorsID;
/*  64 */     this.FamilyCount = FamilyCount;
/*  65 */     this.FamilyStuets = FamilyStuets;
/*  66 */     this.Type = Type;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  70 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  74 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getGranteeName() {
/*  78 */     return this.GranteeName;
/*     */   }
/*     */   
/*     */   public void setGranteeName(String GranteeName) {
/*  82 */     this.GranteeName = GranteeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRegestryType() {
/*  87 */     return this.RegestryType;
/*     */   }
/*     */   
/*     */   public void setRegestryType(String RegestryType) {
/*  91 */     this.RegestryType = RegestryType;
/*     */   }
/*     */   
/*     */   public String getRegestryID() {
/*  95 */     return this.RegestryID;
/*     */   }
/*     */   
/*     */   public void setRegestryID(String RegestryID) {
/*  99 */     this.RegestryID = RegestryID;
/*     */   }
/*     */   
/*     */   public String getDateBirth() {
/* 103 */     return this.DateBirth;
/*     */   }
/*     */   
/*     */   public void setDateBirth(String DateBirth) {
/* 107 */     this.DateBirth = DateBirth;
/*     */   }
/*     */   
/*     */   public String getCityName() {
/* 111 */     return this.CityName;
/*     */   }
/*     */   
/*     */   public void setCityName(String CityName) {
/* 115 */     this.CityName = CityName;
/*     */   }
/*     */   
/*     */   public Image getKroki() {
/* 119 */     return this.Kroki;
/*     */   }
/*     */   
/*     */   public void setKroki(Image Kroki) {
/* 123 */     this.Kroki = Kroki;
/*     */   }
/*     */   
/*     */   public String getCrownGrantee() {
/* 127 */     return this.CrownGrantee;
/*     */   }
/*     */   
/*     */   public void setCrownGrantee(String CrownGrantee) {
/* 131 */     this.CrownGrantee = CrownGrantee;
/*     */   }
/*     */   
/*     */   public String getGranteeConnect() {
/* 135 */     return this.GranteeConnect;
/*     */   }
/*     */   
/*     */   public void setGranteeConnect(String GranteeConnect) {
/* 139 */     this.GranteeConnect = GranteeConnect;
/*     */   }
/*     */   
/*     */   public String getGranteeAccount() {
/* 143 */     return this.GranteeAccount;
/*     */   }
/*     */   
/*     */   public void setGranteeAccount(String GranteeAccount) {
/* 147 */     this.GranteeAccount = GranteeAccount;
/*     */   }
/*     */   
/*     */   public String getSponsorsName() {
/* 151 */     return this.SponsorsName;
/*     */   }
/*     */   
/*     */   public void setSponsorsName(String SponsorsName) {
/* 155 */     this.SponsorsName = SponsorsName;
/*     */   }
/*     */   
/*     */   public String getSponsorsID() {
/* 159 */     return this.SponsorsID;
/*     */   }
/*     */   
/*     */   public void setSponsorsID(String SponsorsID) {
/* 163 */     this.SponsorsID = SponsorsID;
/*     */   }
/*     */   
/*     */   public String getFamilyCount() {
/* 167 */     return this.FamilyCount;
/*     */   }
/*     */   
/*     */   public void setFamilyCount(String FamilyCount) {
/* 171 */     this.FamilyCount = FamilyCount;
/*     */   }
/*     */   
/*     */   public String getFamilyStuets() {
/* 175 */     return this.FamilyStuets;
/*     */   }
/*     */   
/*     */   public void setFamilyStuets(String FamilyStuets) {
/* 179 */     this.FamilyStuets = FamilyStuets;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void AddGrantee() {
/*     */     try {
/* 186 */       String sql = "INSERT INTO Grantees (id,GranteesName,RegestryType,RegestryID,DateBirth,CityName,CrownGrantee,GranteeConnect,GranteeAccount,FamilyCount,FamilyStuets,Type) VALUES (NULL,'" + this.GranteeName + "','" + this.RegestryType + "','" + this.RegestryID + "','" + this.DateBirth + "','" + this.CityName + "','" + this.CrownGrantee + "','" + this.GranteeConnect + "','" + this.GranteeAccount + "','" + this.FamilyCount + "','" + this.FamilyStuets + "','" + this.Type + "');";
/*     */ 
/*     */ 
/*     */       
/* 190 */       this.s = this.c.connect();
/* 191 */       this.s.executeUpdate(sql);
/* 192 */       this.s.close();
/* 193 */     } catch (SQLException ex) {
/* 194 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<InfoGrantees> getAllGrantees(String type) throws Exception {
/* 201 */     ArrayList<InfoGrantees> grantee = new ArrayList<>();
/*     */     try {
/* 203 */       this.s = this.c.connect();
/* 204 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Grantees WHERE Type='" + type + "';");
/*     */       
/* 206 */       while (rs.next()) {
/* 207 */         InfoGrantees gran = new InfoGrantees();
/* 208 */         gran.setId(rs.getInt("id"));
/* 209 */         gran.setGranteeName(rs.getString("GranteesName"));
/* 210 */         gran.setRegestryType(rs.getString("RegestryType"));
/* 211 */         gran.setRegestryID(rs.getString("RegestryID"));
/* 212 */         gran.setDateBirth(rs.getString("DateBirth"));
/* 213 */         gran.setCityName(rs.getString("CityName"));
/* 214 */         gran.setCrownGrantee(rs.getString("CrownGrantee"));
/* 215 */         gran.setGranteeConnect(rs.getString("GranteeConnect"));
/* 216 */         gran.setGranteeAccount(rs.getString("GranteeAccount"));
/* 217 */         gran.setSponsorsName(rs.getString("SponsorsName"));
/* 218 */         gran.setSponsorsID(rs.getString("SponsorsID"));
/* 219 */         gran.setFamilyCount(rs.getString("FamilyCount"));
/* 220 */         gran.setFamilyStuets(rs.getString("FamilyStuets"));
/* 221 */         grantee.add(gran);
/*     */       } 
/* 223 */     } catch (SQLException sc) {
/* 224 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 226 */       this.c.close();
/*     */     } 
/* 228 */     return grantee;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLastID() throws Exception {
/* 233 */     int LastID = 0;
/*     */     
/*     */     try {
/* 236 */       this.s = this.c.connect();
/* 237 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Grantees");
/* 238 */       while (rs.next()) {
/* 239 */         LastID = rs.getInt("id");
/*     */       }
/* 241 */     } catch (SQLException sc) {
/* 242 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 244 */       this.c.close();
/*     */     } 
/* 246 */     return LastID;
/*     */   }
/*     */ 
/*     */   
/*     */   public void GranteeDelete(String GranteeID) {
/*     */     try {
/* 252 */       this.s = this.c.connect();
/* 253 */       this.s.executeUpdate("DELETE FROM Grantees WHERE id='" + GranteeID + "';");
/* 254 */       this.s.executeUpdate("DELETE FROM Sponsors WHERE IDGrantees='" + GranteeID + "';");
/* 255 */       this.s.close();
/* 256 */     } catch (SQLException ex) {
/* 257 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void GranteeUpdate() {
/*     */     try {
/* 264 */       String sql = "UPDATE Grantees SET GranteesName='" + this.GranteeName + "' , RegestryType='" + this.RegestryType + "' , RegestryID='" + this.RegestryID + "' " + ", DateBirth='" + this.DateBirth + "' , CityName='" + this.CityName + "' , CrownGrantee='" + this.CrownGrantee + "', GranteeConnect='" + this.GranteeConnect + "'" + " , GranteeAccount='" + this.GranteeAccount + "', FamilyCount='" + this.FamilyCount + "', FamilyStuets='" + this.FamilyStuets + "' WHERE id='" + this.id + "';";
/*     */ 
/*     */       
/* 267 */       this.s = this.c.connect();
/* 268 */       this.s.executeUpdate(sql);
/* 269 */       this.s.close();
/* 270 */     } catch (SQLException ex) {
/* 271 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<InfoGrantees> getGrantee(String search, String sql, String type) throws Exception {
/* 277 */     ArrayList<InfoGrantees> grantee = new ArrayList<>();
/*     */     try {
/* 279 */       this.s = this.c.connect();
/* 280 */       ResultSet rs = this.s.executeQuery(sql);
/*     */       
/* 282 */       while (rs.next()) {
/* 283 */         InfoGrantees gran = new InfoGrantees();
/* 284 */         if (this.ser.Comparison(search, rs.getString("GranteesName")) && rs.getString("Type").equals(type)) {
/* 285 */           gran.setId(rs.getInt("id"));
/* 286 */           gran.setGranteeName(rs.getString("GranteesName"));
/* 287 */           gran.setRegestryType(rs.getString("RegestryType"));
/* 288 */           gran.setRegestryID(rs.getString("RegestryID"));
/* 289 */           gran.setDateBirth(rs.getString("DateBirth"));
/* 290 */           gran.setCityName(rs.getString("CityName"));
/* 291 */           gran.setCrownGrantee(rs.getString("CrownGrantee"));
/* 292 */           gran.setGranteeConnect(rs.getString("GranteeConnect"));
/* 293 */           gran.setGranteeAccount(rs.getString("GranteeAccount"));
/* 294 */           gran.setSponsorsName(rs.getString("SponsorsName"));
/* 295 */           gran.setSponsorsID(rs.getString("SponsorsID"));
/* 296 */           gran.setFamilyCount(rs.getString("FamilyCount"));
/* 297 */           gran.setFamilyStuets(rs.getString("FamilyStuets"));
/* 298 */           grantee.add(gran);
/*     */         }
/*     */       
/*     */       } 
/* 302 */     } catch (SQLException sc) {
/* 303 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 305 */       this.c.close();
/*     */     } 
/* 307 */     return grantee;
/*     */   }
/*     */ 
/*     */   
/*     */   public void AddTables(String LastID) {
/*     */     try {
/* 313 */       String sql1 = "CREATE TABLE GranteePayments" + LastID.trim() + " (\n" + "id INTEGER PRIMARY KEY\n" + ", SponsorName TEXT\n" + ", PaymentsValue TEXT\n" + ", DayPayments TEXT\n" + ", MonthPayments TEXT\n" + ", YearPayments TEXT\n" + ");";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 321 */       String sql2 = "CREATE TABLE GranteeExpenses" + LastID.trim() + " (\n" + "id INTEGER PRIMARY KEY\n" + ", RecipientName TEXT\n" + ", ExpensesValue TEXT\n" + ", DayExpenses TEXT\n" + ", MonthExpenses TEXT\n" + ", YearExpenses TEXT\n" + ");";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       String sql3 = "CREATE TABLE GranteeSponsors" + LastID.trim() + " (\n" + "id INTEGER PRIMARY KEY\n" + ", SponsorName TEXT\n" + ", DateSponsor TEXT\n" + ");";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 334 */       this.s = this.c.connect();
/* 335 */       this.s.executeUpdate(sql1);
/* 336 */       this.s.executeUpdate(sql2);
/* 337 */       this.s.executeUpdate(sql3);
/* 338 */       this.s.close();
/* 339 */     } catch (SQLException ex) {
/* 340 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void DeleteTables(String LastID) {
/*     */     try {
/* 347 */       String sql1 = "DROP TABLE GranteePayments" + LastID.trim() + ";";
/* 348 */       String sql2 = "DROP TABLE GranteeExpenses" + LastID.trim() + ";";
/* 349 */       String sql3 = "DROP TABLE GranteeSponsors" + LastID.trim() + " ;";
/* 350 */       this.s = this.c.connect();
/* 351 */       this.s.executeUpdate(sql1);
/* 352 */       this.s.executeUpdate(sql2);
/* 353 */       this.s.executeUpdate(sql3);
/* 354 */       this.s.close();
/* 355 */     } catch (SQLException ex) {
/* 356 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\InfoGrantees.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */