/*     */ package JointInfo;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoExpense
/*     */ {
/*  21 */   private DBConnect db = new DBConnect();
/*     */   private Statement s;
/*  23 */   private Searching ser = new Searching();
/*     */   
/*     */   private int id;
/*     */   
/*     */   private String IDGrantees;
/*     */   private String GranteesName;
/*     */   private String IDSponsors;
/*     */   private String SponsorsName;
/*     */   private int ExpenseDay;
/*     */   private int ExpenseMonth;
/*     */   private int ExpenseYear;
/*     */   private String ValueExpense;
/*     */   private String RecipientName;
/*     */   private String FamilyStuets;
/*     */   private String Type;
/*     */   private String DateExpense;
/*     */   private String GPID;
/*     */   private int FamilyCount;
/*     */   
/*     */   public InfoExpense() {}
/*     */   
/*     */   public InfoExpense(int id, String IDGrantees, String GranteesName, String SponsorsName, int ExpenseDay, int ExpenseMonth, int ExpenseYear, String ValueExpense, String RecipientName, String FamilyStuets, String Type, String GPID, int FamilyCount) {
/*  45 */     this.id = id;
/*  46 */     this.IDGrantees = IDGrantees;
/*  47 */     this.GranteesName = GranteesName;
/*  48 */     this.SponsorsName = SponsorsName;
/*  49 */     this.ExpenseDay = ExpenseDay;
/*  50 */     this.ExpenseMonth = ExpenseMonth;
/*  51 */     this.ExpenseYear = ExpenseYear;
/*  52 */     this.ValueExpense = ValueExpense;
/*  53 */     this.RecipientName = RecipientName;
/*  54 */     this.FamilyStuets = FamilyStuets;
/*  55 */     this.Type = Type;
/*  56 */     this.GPID = GPID;
/*  57 */     this.FamilyCount = FamilyCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getId() {
/*  62 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  66 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getIDGrantees() {
/*  70 */     return this.IDGrantees;
/*     */   }
/*     */   
/*     */   public void setIDGrantees(String IDGrantees) {
/*  74 */     this.IDGrantees = IDGrantees;
/*     */   }
/*     */   
/*     */   public String getGranteesName() {
/*  78 */     return this.GranteesName;
/*     */   }
/*     */   
/*     */   public void setGranteesName(String GranteesName) {
/*  82 */     this.GranteesName = GranteesName;
/*     */   }
/*     */   
/*     */   public String getIDSponsors() {
/*  86 */     return this.IDSponsors;
/*     */   }
/*     */   
/*     */   public void setIDSponsors(String IDSponsors) {
/*  90 */     this.IDSponsors = IDSponsors;
/*     */   }
/*     */   
/*     */   public String getSponsorsName() {
/*  94 */     return this.SponsorsName;
/*     */   }
/*     */   
/*     */   public void setSponsorsName(String SponsorsName) {
/*  98 */     this.SponsorsName = SponsorsName;
/*     */   }
/*     */   
/*     */   public String getDateExpense() {
/* 102 */     return this.DateExpense;
/*     */   }
/*     */   
/*     */   public void setDateExpense(String DateExpense) {
/* 106 */     this.DateExpense = DateExpense;
/*     */   }
/*     */   
/*     */   public String getValueExpense() {
/* 110 */     return this.ValueExpense;
/*     */   }
/*     */   
/*     */   public void setValueExpense(String ValueExpense) {
/* 114 */     this.ValueExpense = ValueExpense;
/*     */   }
/*     */   
/*     */   public String getRecipientName() {
/* 118 */     return this.RecipientName;
/*     */   }
/*     */   
/*     */   public void setRecipientName(String RecipientName) {
/* 122 */     this.RecipientName = RecipientName;
/*     */   }
/*     */   
/*     */   public int getExpenseDay() {
/* 126 */     return this.ExpenseDay;
/*     */   }
/*     */   
/*     */   public void setExpenseDay(int ExpenseDay) {
/* 130 */     this.ExpenseDay = ExpenseDay;
/*     */   }
/*     */   
/*     */   public int getExpenseMonth() {
/* 134 */     return this.ExpenseMonth;
/*     */   }
/*     */   
/*     */   public void setExpenseMonth(int ExpenseMonth) {
/* 138 */     this.ExpenseMonth = ExpenseMonth;
/*     */   }
/*     */   
/*     */   public int getExpenseYear() {
/* 142 */     return this.ExpenseYear;
/*     */   }
/*     */   
/*     */   public void setExpenseYear(int ExpenseYear) {
/* 146 */     this.ExpenseYear = ExpenseYear;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFamilyStuets() {
/* 152 */     return this.FamilyStuets;
/*     */   }
/*     */   
/*     */   public void setFamilyStuets(String FamilyStuets) {
/* 156 */     this.FamilyStuets = FamilyStuets;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 160 */     return this.Type;
/*     */   }
/*     */   
/*     */   public void setType(String Type) {
/* 164 */     this.Type = Type;
/*     */   }
/*     */   
/*     */   public String getGPID() {
/* 168 */     return this.GPID;
/*     */   }
/*     */   
/*     */   public void setGPID(String GPID) {
/* 172 */     this.GPID = GPID;
/*     */   }
/*     */   
/*     */   public int getFamilyCount() {
/* 176 */     return this.FamilyCount;
/*     */   }
/*     */   
/*     */   public void setFamilyCount(int FamilyCount) {
/* 180 */     this.FamilyCount = FamilyCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void AddExpense() {
/*     */     try {
/* 189 */       this.s = this.db.connect();
/* 190 */       String sql1 = "INSERT INTO GranteeExpenses" + this.IDGrantees + " (id, RecipientName, ExpensesValue, DayExpenses, MonthExpenses, YearExpenses) " + " VALUES (NULL,'" + this.RecipientName + "','" + this.ValueExpense + "','" + this.ExpenseDay + "','" + this.ExpenseMonth + "','" + this.ExpenseYear + "')";
/*     */       
/* 192 */       this.s.executeUpdate(sql1);
/* 193 */       this.db.close();
/* 194 */     } catch (Exception ex) {
/* 195 */       Logger.getLogger(InfoExpense.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<InfoExpense> getAllExpenses() throws Exception {
/* 201 */     ArrayList<InfoExpense> sponsors = new ArrayList<>();
/*     */     try {
/* 203 */       this.s = this.db.connect();
/* 204 */       ResultSet rs = this.s.executeQuery("SELECT * FROM GranteeExpenses" + this.IDGrantees + "  ORDER BY id DESC");
/*     */       
/* 206 */       while (rs.next()) {
/* 207 */         InfoExpense spon = new InfoExpense();
/* 208 */         spon.setId(rs.getInt("id"));
/* 209 */         spon.setRecipientName(rs.getString("RecipientName"));
/* 210 */         spon.setValueExpense(rs.getString("ExpensesValue"));
/* 211 */         spon.setExpenseDay(rs.getInt("DayExpenses"));
/* 212 */         spon.setExpenseMonth(rs.getInt("MonthExpenses"));
/* 213 */         spon.setExpenseYear(rs.getInt("YearExpenses"));
/* 214 */         sponsors.add(spon);
/*     */       } 
/* 216 */     } catch (SQLException sc) {
/* 217 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 219 */       this.db.close();
/*     */     } 
/* 221 */     return sponsors;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<InfoExpense> getAllPublicExpenses(String ser) throws Exception {
/* 226 */     ArrayList<InfoExpense> sponsors = new ArrayList<>();
/*     */     try {
/* 228 */       this.s = this.db.connect();
/* 229 */       ResultSet rs = this.s.executeQuery("SELECT * FROM PublicExpenses" + ser);
/*     */       
/* 231 */       while (rs.next()) {
/* 232 */         InfoExpense spon = new InfoExpense();
/* 233 */         spon.setId(rs.getInt("id"));
/* 234 */         spon.setSponsorsName(rs.getString("SponsorName"));
/* 235 */         spon.setRecipientName(rs.getString("RecipientName"));
/* 236 */         spon.setGranteesName(rs.getString("GranteeName"));
/* 237 */         spon.setValueExpense(rs.getString("ExpensesValue"));
/* 238 */         spon.setExpenseDay(rs.getInt("DayExpenses"));
/* 239 */         spon.setExpenseMonth(rs.getInt("MonthExpenses"));
/* 240 */         spon.setExpenseYear(rs.getInt("YearExpenses"));
/* 241 */         spon.setFamilyStuets(rs.getString("FamilyStuets"));
/* 242 */         spon.setType(rs.getString("Type"));
/* 243 */         spon.setFamilyCount(rs.getInt("FamilyCount"));
/* 244 */         sponsors.add(spon);
/*     */       } 
/* 246 */     } catch (SQLException sc) {
/* 247 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 249 */       this.db.close();
/*     */     } 
/* 251 */     return sponsors;
/*     */   }
/*     */   
/*     */   public void ExpenseDelete() {
/*     */     try {
/* 256 */       this.s = this.db.connect();
/* 257 */       this.s.executeUpdate("DELETE FROM GranteeExpenses" + this.IDGrantees + " WHERE id='" + this.id + "';");
/* 258 */       this.s.close();
/* 259 */     } catch (SQLException ex) {
/* 260 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void ExpenseUpdate() {
/*     */     try {
/* 267 */       String sql = "UPDATE GranteeExpenses" + this.IDGrantees + " SET RecipientName='" + this.RecipientName + "' , ExpensesValue='" + this.ValueExpense + "', DayExpenses='" + this.ExpenseDay + "', MonthExpenses='" + this.ExpenseMonth + "', YearExpenses='" + this.ExpenseYear + "' WHERE id='" + this.id + "';";
/*     */       
/* 269 */       this.s = this.db.connect();
/* 270 */       this.s.executeUpdate(sql);
/* 271 */       this.s.close();
/* 272 */     } catch (SQLException ex) {
/* 273 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void AddPublicExpenses() {
/*     */     try {
/* 279 */       this.s = this.db.connect();
/* 280 */       String sql1 = "INSERT INTO PublicExpenses (id , SponsorName, RecipientName, GranteeName, ExpensesValue, DayExpenses, MonthExpenses, YearExpenses, FamilyStuets, Type, GPID,FamilyCount)  VALUES (NULL,'" + this.SponsorsName + "','" + this.RecipientName + "','" + this.GranteesName + "','" + this.ValueExpense + "','" + this.ExpenseDay + "','" + this.ExpenseMonth + "','" + this.ExpenseYear + "','" + this.FamilyStuets + "','" + this.Type + "','" + this.GPID + "','" + this.FamilyCount + "' )";
/*     */       
/* 282 */       this.s.executeUpdate(sql1);
/* 283 */       this.db.close();
/* 284 */     } catch (Exception ex) {
/* 285 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLastID() {
/* 290 */     int LastID = 0;
/*     */     try {
/* 292 */       this.s = this.db.connect();
/* 293 */       ResultSet rs = this.s.executeQuery("SELECT * FROM GranteeExpenses" + this.IDGrantees + "");
/* 294 */       while (rs.next()) {
/* 295 */         LastID = rs.getInt("id");
/*     */       }
/* 297 */     } catch (Exception ex) {
/* 298 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 300 */       this.db.close();
/*     */     } 
/* 302 */     return LastID;
/*     */   }
/*     */   
/*     */   public String getFStuts() {
/* 306 */     String FamilyStuets = "";
/*     */     try {
/* 308 */       this.s = this.db.connect();
/* 309 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Grantees WHERE id='" + this.IDGrantees + "';");
/* 310 */       while (rs.next()) {
/* 311 */         FamilyStuets = rs.getString("FamilyStuets");
/*     */       }
/* 313 */     } catch (Exception ex) {
/* 314 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 316 */       this.db.close();
/*     */     } 
/* 318 */     return FamilyStuets;
/*     */   }
/*     */   public String getFCount() {
/* 321 */     String FCount = "";
/*     */     try {
/* 323 */       this.s = this.db.connect();
/* 324 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Grantees WHERE id='" + this.IDGrantees + "';");
/* 325 */       while (rs.next()) {
/* 326 */         FCount = rs.getString("FamilyCount");
/*     */       }
/* 328 */     } catch (Exception ex) {
/* 329 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 331 */       this.db.close();
/*     */     } 
/* 333 */     return FCount;
/*     */   }
/*     */   
/*     */   public void PublicExpensesUpdate() {
/*     */     try {
/* 338 */       String sql = "UPDATE PublicExpenses SET ExpensesValue='" + this.ValueExpense + "' , DayExpenses='" + this.ExpenseDay + "', MonthExpenses='" + this.ExpenseMonth + "', YearExpenses='" + this.ExpenseYear + "' WHERE GPID='" + this.GPID + "';";
/*     */       
/* 340 */       this.s = this.db.connect();
/* 341 */       this.s.executeUpdate(sql);
/* 342 */       this.s.close();
/* 343 */     } catch (SQLException ex) {
/* 344 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\InfoExpense.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */