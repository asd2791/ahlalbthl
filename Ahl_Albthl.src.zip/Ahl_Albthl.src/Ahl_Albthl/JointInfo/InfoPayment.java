/*     */ package JointInfo;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoPayment
/*     */ {
/*  21 */   private DBConnect db = new DBConnect();
/*     */   private Statement s;
/*  23 */   private Searching ser = new Searching();
/*     */   
/*     */   private int id;
/*     */   
/*     */   private String IDGrantees;
/*     */   
/*     */   private String GranteesName;
/*     */   
/*     */   private String IDSponsors;
/*     */   
/*     */   private String SponsorsName;
/*     */   private int PaymentDay;
/*     */   private int PaymentMonth;
/*     */   private int PaymentYear;
/*     */   private String ValuePayment;
/*     */   private String FamilyStuets;
/*     */   private String Type;
/*     */   private String DatePayment;
/*     */   private String GPID;
/*     */   
/*     */   public InfoPayment() {}
/*     */   
/*     */   public InfoPayment(int id, String IDGrantees, String GranteesName, String IDSponsors, String SponsorsName, int PaymentDay, int PaymentMonth, int PaymentYear, String ValuePayment, String FamilyStuets, String Type, String GPID) {
/*  46 */     this.id = id;
/*  47 */     this.IDGrantees = IDGrantees;
/*  48 */     this.GranteesName = GranteesName;
/*  49 */     this.IDSponsors = IDSponsors;
/*  50 */     this.SponsorsName = SponsorsName;
/*  51 */     this.PaymentDay = PaymentDay;
/*  52 */     this.PaymentMonth = PaymentMonth;
/*  53 */     this.PaymentYear = PaymentYear;
/*  54 */     this.ValuePayment = ValuePayment;
/*  55 */     this.FamilyStuets = Type;
/*  56 */     this.Type = Type;
/*  57 */     this.GPID = GPID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getId() {
/*  63 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  67 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getIDGrantees() {
/*  71 */     return this.IDGrantees;
/*     */   }
/*     */   
/*     */   public void setIDGrantees(String IDGrantees) {
/*  75 */     this.IDGrantees = IDGrantees;
/*     */   }
/*     */   
/*     */   public String getGranteesName() {
/*  79 */     return this.GranteesName;
/*     */   }
/*     */   
/*     */   public void setGranteesName(String GranteesName) {
/*  83 */     this.GranteesName = GranteesName;
/*     */   }
/*     */   
/*     */   public String getIDSponsors() {
/*  87 */     return this.IDSponsors;
/*     */   }
/*     */   
/*     */   public void setIDSponsors(String IDSponsors) {
/*  91 */     this.IDSponsors = IDSponsors;
/*     */   }
/*     */   
/*     */   public String getSponsorsName() {
/*  95 */     return this.SponsorsName;
/*     */   }
/*     */   
/*     */   public void setSponsorsName(String SponsorsName) {
/*  99 */     this.SponsorsName = SponsorsName;
/*     */   }
/*     */   
/*     */   public int getPaymentDay() {
/* 103 */     return this.PaymentDay;
/*     */   }
/*     */   
/*     */   public void setPaymentDay(int PaymentDay) {
/* 107 */     this.PaymentDay = PaymentDay;
/*     */   }
/*     */   
/*     */   public int getPaymentMonth() {
/* 111 */     return this.PaymentMonth;
/*     */   }
/*     */   
/*     */   public void setPaymentMonth(int PaymentMonth) {
/* 115 */     this.PaymentMonth = PaymentMonth;
/*     */   }
/*     */   
/*     */   public int getPaymentYear() {
/* 119 */     return this.PaymentYear;
/*     */   }
/*     */   
/*     */   public void setPaymentYear(int TextPaymentYear) {
/* 123 */     this.PaymentYear = TextPaymentYear;
/*     */   }
/*     */   
/*     */   public String getValuePayment() {
/* 127 */     return this.ValuePayment;
/*     */   }
/*     */   
/*     */   public void setValuePayment(String ValuePayment) {
/* 131 */     this.ValuePayment = ValuePayment;
/*     */   }
/*     */   
/*     */   public String getFamilyStuets() {
/* 135 */     return this.FamilyStuets;
/*     */   }
/*     */   
/*     */   public void setFamilyStuets(String FamilyStuets) {
/* 139 */     this.FamilyStuets = FamilyStuets;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 143 */     return this.Type;
/*     */   }
/*     */   
/*     */   public void setType(String Type) {
/* 147 */     this.Type = Type;
/*     */   }
/*     */   
/*     */   public String getDatePayment() {
/* 151 */     return this.DatePayment;
/*     */   }
/*     */   
/*     */   public void setDatePayment(String DatePayment) {
/* 155 */     this.DatePayment = DatePayment;
/*     */   }
/*     */   
/*     */   public String getGPID() {
/* 159 */     return this.GPID;
/*     */   }
/*     */   
/*     */   public void setGPID(String GPID) {
/* 163 */     this.GPID = GPID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void AddPayment() {
/*     */     try {
/* 171 */       this.s = this.db.connect();
/* 172 */       String sql1 = "INSERT INTO GranteePayments" + this.IDGrantees + " (id, SponsorName, PaymentsValue, DayPayments, MonthPayments, YearPayments) " + " VALUES (NULL,'" + this.SponsorsName + "','" + this.ValuePayment + "','" + this.PaymentDay + "','" + this.PaymentMonth + "','" + this.PaymentYear + "')";
/*     */       
/* 174 */       this.s.executeUpdate(sql1);
/* 175 */       this.db.close();
/* 176 */     } catch (Exception ex) {
/* 177 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<InfoPayment> getAllPayments() throws Exception {
/* 183 */     ArrayList<InfoPayment> sponsors = new ArrayList<>();
/*     */     try {
/* 185 */       this.s = this.db.connect();
/* 186 */       ResultSet rs = this.s.executeQuery("SELECT * FROM GranteePayments" + this.IDGrantees + "  ORDER BY id DESC");
/*     */       
/* 188 */       while (rs.next()) {
/* 189 */         InfoPayment spon = new InfoPayment();
/* 190 */         spon.setId(rs.getInt("id"));
/* 191 */         spon.setSponsorsName(rs.getString("SponsorName"));
/* 192 */         spon.setValuePayment(rs.getString("PaymentsValue"));
/* 193 */         spon.setPaymentDay(rs.getInt("DayPayments"));
/* 194 */         spon.setPaymentMonth(rs.getInt("MonthPayments"));
/* 195 */         spon.setPaymentYear(rs.getInt("YearPayments"));
/* 196 */         sponsors.add(spon);
/*     */       } 
/* 198 */     } catch (SQLException sc) {
/* 199 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 201 */       this.db.close();
/*     */     } 
/* 203 */     return sponsors;
/*     */   }
/*     */   
/*     */   public void PaymentDelete() {
/*     */     try {
/* 208 */       this.s = this.db.connect();
/* 209 */       this.s.executeUpdate("DELETE FROM GranteePayments" + this.IDGrantees + " WHERE id='" + this.id + "';");
/* 210 */       this.s.close();
/* 211 */     } catch (SQLException ex) {
/* 212 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void PaymentUpdate() {
/*     */     try {
/* 219 */       String sql = "UPDATE GranteePayments" + this.IDGrantees + " SET PaymentsValue='" + this.ValuePayment + "' , DayPayments='" + this.PaymentDay + "', MonthPayments='" + this.PaymentMonth + "', YearPayments='" + this.PaymentYear + "' WHERE id='" + this.id + "';";
/*     */       
/* 221 */       this.s = this.db.connect();
/* 222 */       this.s.executeUpdate(sql);
/* 223 */       this.s.close();
/* 224 */     } catch (SQLException ex) {
/* 225 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void AddPublicPayment() {
/*     */     try {
/* 231 */       this.s = this.db.connect();
/* 232 */       String sql1 = "INSERT INTO PublicPayments (id , SponsorName , GranteeName, PaymentsValue, DayPayments, MonthPayments, YearPayments, Type, GPID)  VALUES (NULL,'" + this.SponsorsName + "','" + this.GranteesName + "','" + this.ValuePayment + "','" + this.PaymentDay + "','" + this.PaymentMonth + "','" + this.PaymentYear + "','" + this.Type + "','" + this.GPID + "')";
/*     */       
/* 234 */       this.s.executeUpdate(sql1);
/* 235 */       this.db.close();
/* 236 */     } catch (Exception ex) {
/* 237 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLastID() {
/* 242 */     int LastID = 0;
/*     */     try {
/* 244 */       this.s = this.db.connect();
/* 245 */       ResultSet rs = this.s.executeQuery("SELECT * FROM GranteePayments" + this.IDGrantees + "");
/* 246 */       while (rs.next()) {
/* 247 */         LastID = rs.getInt("id");
/*     */       }
/* 249 */     } catch (Exception ex) {
/* 250 */       Logger.getLogger(InfoPayment.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 252 */       this.db.close();
/*     */     } 
/* 254 */     return LastID;
/*     */   }
/*     */   
/*     */   public void PublicPaymentUpdate() {
/*     */     try {
/* 259 */       String sql = "UPDATE PublicPayments SET PaymentsValue='" + this.ValuePayment + "' , DayPayments='" + this.PaymentDay + "', MonthPayments='" + this.PaymentMonth + "', YearPayments='" + this.PaymentYear + "' WHERE GPID='" + this.GPID + "';";
/*     */       
/* 261 */       this.s = this.db.connect();
/* 262 */       this.s.executeUpdate(sql);
/* 263 */       this.s.close();
/* 264 */     } catch (SQLException ex) {
/* 265 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void PublicPaymentDelete() {
/*     */     try {
/* 271 */       this.s = this.db.connect();
/* 272 */       this.s.executeUpdate("DELETE FROM PublicPayments WHERE GPID='" + this.GPID + "';");
/* 273 */       this.s.close();
/* 274 */     } catch (SQLException ex) {
/* 275 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<InfoPayment> getAllPublicPayments(String ser) throws Exception {
/* 281 */     ArrayList<InfoPayment> sponsors = new ArrayList<>();
/*     */     try {
/* 283 */       this.s = this.db.connect();
/* 284 */       ResultSet rs = this.s.executeQuery("SELECT * FROM PublicPayments " + ser);
/*     */       
/* 286 */       while (rs.next()) {
/* 287 */         InfoPayment spon = new InfoPayment();
/* 288 */         spon.setId(rs.getInt("id"));
/* 289 */         spon.setSponsorsName(rs.getString("SponsorName"));
/* 290 */         spon.setGranteesName(rs.getString("GranteeName"));
/* 291 */         spon.setValuePayment(rs.getString("PaymentsValue"));
/* 292 */         spon.setPaymentDay(rs.getInt("DayPayments"));
/* 293 */         spon.setPaymentMonth(rs.getInt("MonthPayments"));
/* 294 */         spon.setPaymentYear(rs.getInt("YearPayments"));
/* 295 */         spon.setFamilyStuets(rs.getString("FamilyStuets"));
/* 296 */         spon.setType(rs.getString("Type"));
/* 297 */         sponsors.add(spon);
/*     */       } 
/* 299 */     } catch (SQLException sc) {
/* 300 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 302 */       this.db.close();
/*     */     } 
/* 304 */     return sponsors;
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\InfoPayment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */