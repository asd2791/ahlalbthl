/*    */ package JointInfo;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.DefaultTableCellRenderer;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeaderRenderer
/*    */   implements TableCellRenderer
/*    */ {
/*    */   DefaultTableCellRenderer renderer;
/*    */   
/*    */   public HeaderRenderer(JTable table) {
/* 19 */     this
/* 20 */       .renderer = (DefaultTableCellRenderer)table.getTableHeader().getDefaultRenderer();
/* 21 */     this.renderer.setHorizontalAlignment(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
/* 28 */     return this.renderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\HeaderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */