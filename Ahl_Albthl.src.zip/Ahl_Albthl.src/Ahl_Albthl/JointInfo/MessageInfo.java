/*    */ package JointInfo;
/*    */ 
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageInfo
/*    */ {
/*    */   public int getSelectMessage(String ms, String tital) {
/* 14 */     String messageS = "<html><body><div width='200px' align='right'>" + ms + "</div></body></html>";
/* 15 */     JLabel messageLabel = new JLabel(messageS);
/* 16 */     int reply = JOptionPane.showConfirmDialog(null, messageLabel, tital, 0);
/* 17 */     return reply;
/*    */   }
/*    */ 
/*    */   
/*    */   public void getERRMessage(String ms, String tital) {
/* 22 */     String messageE = "<html><body><div width='200px' align='right'>" + ms + "</div></body></html>";
/* 23 */     JLabel messageLabel = new JLabel(messageE);
/* 24 */     JOptionPane.showMessageDialog(null, messageLabel, tital, 0);
/*    */   }
/*    */   
/*    */   public void getCorrectMessage(String ms, String tital) {
/* 28 */     String messageC = "<html><body><div width='200px' align='right'>" + ms + "</div></body></html>";
/* 29 */     JLabel messageLabel = new JLabel(messageC);
/* 30 */     JOptionPane.showMessageDialog(null, messageLabel, tital, -1);
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\MessageInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */