/*     */ package JointInfo;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoSponsors
/*     */ {
/*  22 */   private DBConnect db = new DBConnect();
/*     */   private Statement s;
/*  24 */   private Searching ser = new Searching();
/*     */   
/*     */   private int id;
/*     */   
/*     */   private String IDGrantees;
/*     */   private String GranteesName;
/*     */   private String SponsorsName;
/*     */   private String DateSponsors;
/*     */   private String SponsorsConnect;
/*     */   private String ValueSponsor;
/*     */   private String RegestryID;
/*     */   private String SponsorsAccount;
/*     */   private String Status;
/*     */   private String Type;
/*     */   private String FamilyCount;
/*     */   private String FamilyStuets;
/*     */   
/*     */   public InfoSponsors() {}
/*     */   
/*     */   public InfoSponsors(int id, String IDGrantees, String GranteesName, String SponsorsName, String DateSponsors, String SponsorsConnect, String ValueSponsor, String RegestryID, String SponsorsAccount, String Status, String Type) {
/*  44 */     this.id = id;
/*  45 */     this.IDGrantees = IDGrantees;
/*  46 */     this.GranteesName = GranteesName;
/*  47 */     this.SponsorsName = SponsorsName;
/*  48 */     this.DateSponsors = DateSponsors;
/*  49 */     this.SponsorsConnect = SponsorsConnect;
/*  50 */     this.ValueSponsor = ValueSponsor;
/*  51 */     this.RegestryID = RegestryID;
/*  52 */     this.SponsorsAccount = SponsorsAccount;
/*  53 */     this.Status = Status;
/*  54 */     this.Type = Type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getId() {
/*  59 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  63 */     this.id = id;
/*     */   }
/*     */   
/*     */   public String getIDGrantees() {
/*  67 */     return this.IDGrantees;
/*     */   }
/*     */   
/*     */   public void setIDGrantees(String IDGrantees) {
/*  71 */     this.IDGrantees = IDGrantees;
/*     */   }
/*     */   
/*     */   public String getGranteesName() {
/*  75 */     return this.GranteesName;
/*     */   }
/*     */   
/*     */   public void setGranteesName(String GranteesName) {
/*  79 */     this.GranteesName = GranteesName;
/*     */   }
/*     */   
/*     */   public String getSponsorsName() {
/*  83 */     return this.SponsorsName;
/*     */   }
/*     */   
/*     */   public void setSponsorsName(String SponsorsName) {
/*  87 */     this.SponsorsName = SponsorsName;
/*     */   }
/*     */   
/*     */   public String getDateSponsors() {
/*  91 */     return this.DateSponsors;
/*     */   }
/*     */   
/*     */   public void setDateSponsors(String DateSponsors) {
/*  95 */     this.DateSponsors = DateSponsors;
/*     */   }
/*     */   
/*     */   public String getSponsorsConnect() {
/*  99 */     return this.SponsorsConnect;
/*     */   }
/*     */   
/*     */   public void setSponsorsConnect(String SponsorsConnect) {
/* 103 */     this.SponsorsConnect = SponsorsConnect;
/*     */   }
/*     */   
/*     */   public String getValueSponsor() {
/* 107 */     return this.ValueSponsor;
/*     */   }
/*     */   
/*     */   public void setValueSponsor(String ValueSponsor) {
/* 111 */     this.ValueSponsor = ValueSponsor;
/*     */   }
/*     */   
/*     */   public String getRegestryID() {
/* 115 */     return this.RegestryID;
/*     */   }
/*     */   
/*     */   public void setRegestryID(String RegestryID) {
/* 119 */     this.RegestryID = RegestryID;
/*     */   }
/*     */   
/*     */   public String getSponsorsAccount() {
/* 123 */     return this.SponsorsAccount;
/*     */   }
/*     */   
/*     */   public void setSponsorsAccount(String SponsorsAccount) {
/* 127 */     this.SponsorsAccount = SponsorsAccount;
/*     */   }
/*     */   
/*     */   public String getStatus() {
/* 131 */     return this.Status;
/*     */   }
/*     */   
/*     */   public void setStatus(String Status) {
/* 135 */     this.Status = Status;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 139 */     return this.Type;
/*     */   }
/*     */   
/*     */   public void setType(String Type) {
/* 143 */     this.Type = Type;
/*     */   }
/*     */   
/*     */   public String getFamilyCount() {
/* 147 */     return this.FamilyCount;
/*     */   }
/*     */   
/*     */   public void setFamilyCount(String FamilyCount) {
/* 151 */     this.FamilyCount = FamilyCount;
/*     */   }
/*     */   
/*     */   public String getFamilyStuets() {
/* 155 */     return this.FamilyStuets;
/*     */   }
/*     */   
/*     */   public void setFamilyStuets(String FamilyStuets) {
/* 159 */     this.FamilyStuets = FamilyStuets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void AddSponsors() {
/*     */     try {
/* 167 */       this.s = this.db.connect();
/* 168 */       String sql1 = "INSERT INTO Sponsors (id, IDGrantees, GranteesName, SponsorsName, DateSponsors, SponsorsConnect, ValueSponsor, RegestryID, SponsorsAccount, Type)  VALUES (NULL,'" + this.IDGrantees + "','" + this.GranteesName + "','" + this.SponsorsName + "','" + this.DateSponsors + "','" + this.SponsorsConnect + "','" + this.ValueSponsor + "','" + this.RegestryID + "','" + this.SponsorsAccount + "','" + this.Type + "')";
/*     */       
/* 170 */       this.s.executeUpdate(sql1);
/* 171 */     } catch (Exception ex) {
/* 172 */       Logger.getLogger(InfoSponsors.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 174 */       this.db.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void SendSponsorToGranteesTable() {
/*     */     try {
/* 181 */       int LastID = getLastID();
/* 182 */       this.s = this.db.connect();
/* 183 */       String sql2 = "UPDATE Grantees SET SponsorsName='" + this.SponsorsName + "' , SponsorsID='" + LastID + "' WHERE id='" + this.IDGrantees + "';";
/* 184 */       this.s.executeUpdate(sql2);
/* 185 */     } catch (Exception ex) {
/* 186 */       Logger.getLogger(InfoSponsors.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 188 */       this.db.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void RemoveSponsorInGranteesTable() {
/*     */     try {
/* 195 */       this.s = this.db.connect();
/* 196 */       String sql2 = "UPDATE Grantees SET SponsorsName='' , SponsorsID='' WHERE id='" + this.IDGrantees + "';";
/* 197 */       String sql3 = "DELETE FROM Sponsors WHERE IDGrantees='" + this.IDGrantees + "';";
/* 198 */       this.s.executeUpdate(sql2);
/* 199 */       this.s.executeUpdate(sql3);
/* 200 */     } catch (Exception ex) {
/* 201 */       Logger.getLogger(InfoSponsors.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 203 */       this.db.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void AddSponsorToNamesSponsorGrantee() {
/*     */     try {
/* 210 */       this.s = this.db.connect();
/* 211 */       String sql3 = "INSERT INTO GranteeSponsors" + this.IDGrantees + "  (id, SponsorName, DateSponsor) " + " VALUES (NULL,'" + this.SponsorsName + "','" + this.DateSponsors + "')";
/*     */       
/* 213 */       this.s.executeUpdate(sql3);
/* 214 */     } catch (Exception ex) {
/* 215 */       Logger.getLogger(InfoSponsors.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 217 */       this.db.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getLastID() throws Exception {
/* 222 */     int LastID = 0;
/*     */     
/*     */     try {
/* 225 */       this.s = this.db.connect();
/* 226 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Sponsors");
/* 227 */       while (rs.next()) {
/* 228 */         LastID = rs.getInt("id");
/*     */       }
/* 230 */     } catch (SQLException sc) {
/* 231 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 233 */       this.db.close();
/*     */     } 
/* 235 */     return LastID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<InfoSponsors> getAllSponsors() throws Exception {
/* 241 */     ArrayList<InfoSponsors> sponsors = new ArrayList<>();
/*     */     try {
/* 243 */       this.s = this.db.connect();
/* 244 */       ResultSet rs = this.s.executeQuery("SELECT * FROM Sponsors WHERE Type='" + this.Type + "'");
/*     */       
/* 246 */       while (rs.next()) {
/* 247 */         InfoSponsors spon = new InfoSponsors();
/* 248 */         spon.setId(rs.getInt("id"));
/* 249 */         spon.setSponsorsName(rs.getString("SponsorsName"));
/* 250 */         spon.setGranteesName(rs.getString("GranteesName"));
/* 251 */         spon.setRegestryID(rs.getString("RegestryID"));
/* 252 */         spon.setIDGrantees(rs.getString("IDGrantees"));
/* 253 */         sponsors.add(spon);
/*     */       } 
/* 255 */     } catch (SQLException sc) {
/* 256 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 258 */       this.db.close();
/*     */     } 
/* 260 */     return sponsors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<InfoSponsors> getSponsor(String search, String sql, String type) throws Exception {
/* 266 */     ArrayList<InfoSponsors> sponsors = new ArrayList<>();
/*     */     try {
/* 268 */       this.s = this.db.connect();
/* 269 */       ResultSet rs = this.s.executeQuery(sql);
/*     */       
/* 271 */       while (rs.next()) {
/* 272 */         InfoSponsors spon = new InfoSponsors();
/* 273 */         if (this.ser.Comparison(search, rs.getString("SponsorsName")) && rs.getString("Type").equals(type))
/*     */         {
/* 275 */           spon.setId(rs.getInt("id"));
/* 276 */           spon.setSponsorsName(rs.getString("SponsorsName"));
/* 277 */           spon.setSponsorsConnect(rs.getString("SponsorsConnect"));
/* 278 */           spon.setRegestryID(rs.getString("RegestryID"));
/* 279 */           spon.setIDGrantees(rs.getString("IDGrantees"));
/* 280 */           spon.setGranteesName(rs.getString("GranteesName"));
/* 281 */           sponsors.add(spon);
/*     */         }
/*     */       
/*     */       } 
/* 285 */     } catch (SQLException sc) {
/* 286 */       throw new Exception(sc.getMessage(), sc);
/*     */     } finally {
/* 288 */       this.db.close();
/*     */     } 
/* 290 */     return sponsors;
/*     */   }
/*     */   
/*     */   public void GranteeUpdateInSponsors() {
/*     */     try {
/* 295 */       String sql = "UPDATE Sponsors SET GranteesName='" + this.GranteesName + "'  WHERE IDGrantees='" + this.IDGrantees + "';";
/* 296 */       this.s = this.db.connect();
/* 297 */       this.s.executeUpdate(sql);
/* 298 */     } catch (SQLException ex) {
/* 299 */       Logger.getLogger(InfoGrantees.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } finally {
/* 301 */       this.db.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\InfoSponsors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */