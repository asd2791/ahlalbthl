/*    */ package JointInfo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChekCompletData
/*    */ {
/*    */   public ArrayList<String> ChekCompletData(String[] IfEror, String[] ChekTexts) {
/* 17 */     ArrayList<String> MassageErore = new ArrayList<>();
/*    */     
/* 19 */     for (int i = 0; i < IfEror.length; i++) {
/* 20 */       if (ChekTexts[i].trim().equals("")) {
/* 21 */         MassageErore.add(IfEror[i]);
/*    */       }
/*    */     } 
/*    */     
/* 25 */     return MassageErore;
/*    */   }
/*    */   
/*    */   public ArrayList<String> ChekCompletDataNuumper(String[] IfEror, String[] ChekNumber) {
/* 29 */     ArrayList<String> MassageErore = new ArrayList<>();
/*    */     
/* 31 */     for (int i = 0; i < IfEror.length; i++) {
/*    */       try {
/* 33 */         Integer.parseInt(ChekNumber[i]);
/*    */       }
/* 35 */       catch (NumberFormatException e) {
/* 36 */         MassageErore.add(IfEror[i]);
/*    */       } 
/*    */     } 
/* 39 */     return MassageErore;
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\ChekCompletData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */