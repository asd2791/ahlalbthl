/*    */ package JointInfo;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DBConnect
/*    */ {
/*    */   Connection c;
/*    */   Statement s;
/* 17 */   String url = "jdbc:sqlite:Bases/AlbthlData";
/* 18 */   private Connection connection = null;
/*    */   
/*    */   public Statement connect() {
/*    */     try {
/* 22 */       Class.forName("org.sqlite.JDBC");
/* 23 */     } catch (ClassNotFoundException classNotFoundException) {}
/*    */     
/*    */     try {
/* 26 */       this.connection = DriverManager.getConnection(this.url);
/* 27 */       this.s = this.connection.createStatement();
/*    */     }
/* 29 */     catch (SQLException sQLException) {}
/*    */ 
/*    */     
/* 32 */     return this.s;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 37 */     if (this.connection != null) {
/*    */       try {
/* 39 */         this.connection.close();
/* 40 */         this.connection = null;
/* 41 */       } catch (SQLException ex) {
/* 42 */         System.err.println(ex.getMessage());
/* 43 */         ex.printStackTrace();
/*    */       } 
/*    */     }
/* 46 */     if (this.s != null)
/*    */       try {
/* 48 */         this.s.close();
/* 49 */         this.s = null;
/* 50 */       } catch (SQLException ex) {
/* 51 */         System.err.println(ex.getMessage());
/* 52 */         ex.printStackTrace();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\DBConnect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */