/*     */ package JointInfo;
/*     */ 
/*     */ public class Searching
/*     */ {
/*   5 */   private String[] spl = new String[] { "ا", "أ", "آ", "إ", "ء", "ئ", "ى", "ة", "ه", " بن ", " " };
/*     */   
/*     */   private String[] words;
/*     */   
/*   9 */   private String like1 = " LIKE ";
/*  10 */   private String and = " AND ";
/*     */   private String NameColumn;
/*     */   private String LikeAll;
/*     */   
/*     */   private String LikeString(String stri, String NameCo) {
/*  15 */     this.NameColumn = NameCo;
/*  16 */     this.LikeAll = LikeSyntax(stri);
/*  17 */     this.LikeAll = this.LikeAll.substring(0, this.LikeAll.length() - 4);
/*     */     
/*  19 */     return this.LikeAll;
/*     */   }
/*     */ 
/*     */   
/*     */   private String deletBen(String jmlh) {
/*  24 */     for (int i = 0; i < 1; i++) {
/*  25 */       this.words = jmlh.split(" ");
/*     */     }
/*  27 */     jmlh = "";
/*  28 */     for (int i2 = 0; i2 < this.words.length; i2++) {
/*  29 */       if (!this.words[i2].equals("بن") && !this.words[i2].equals("ابن") && 
/*  30 */         !this.words[i2].equals("إبن") && !this.words[i2].equals("أبن") && 
/*  31 */         !this.words[i2].equals("آبن"))
/*     */       {
/*  33 */         jmlh = jmlh + " " + this.words[i2];
/*     */       }
/*     */     } 
/*  36 */     return jmlh;
/*     */   }
/*     */   
/*     */   private String LikeSyntax(String jmlh) {
/*     */     int i;
/*  41 */     for (i = 0; i < this.spl.length; i++) {
/*  42 */       this.words = jmlh.split(this.spl[i]);
/*  43 */       jmlh = "";
/*  44 */       for (int i2 = 0; i2 < this.words.length; i2++) {
/*  45 */         jmlh = jmlh + " " + this.words[i2];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  50 */     jmlh = "";
/*  51 */     for (i = 0; i < this.words.length; i++) {
/*     */       
/*  53 */       if (!this.words[i].equals("") && !this.words[i].equals("بن"))
/*     */       {
/*  55 */         jmlh = jmlh + this.NameColumn + this.like1 + "'%" + this.words[i] + "%'" + this.and;
/*     */       }
/*     */     } 
/*  58 */     return jmlh;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String LaterChange(String jmlh) {
/*  64 */     String replace = jmlh.replace("أ", "ا");
/*  65 */     replace = replace.replace("آ", "ا");
/*  66 */     replace = replace.replace("إ", "ا");
/*  67 */     replace = replace.replace("ء", "ا");
/*  68 */     replace = replace.replace("ئ", "ا");
/*  69 */     replace = replace.replace("ى", "ا");
/*  70 */     replace = replace.replace("ة", "ه");
/*     */     
/*  72 */     return replace;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean Comparison(String serch, String Result) {
/*     */     boolean bo;
/*  79 */     serch = deletBen(serch);
/*  80 */     Result = deletBen(Result);
/*     */     
/*  82 */     serch = LaterChange(serch);
/*  83 */     Result = LaterChange(Result);
/*     */ 
/*     */     
/*  86 */     int cmp = Double.compare(serch.length(), Result.length());
/*  87 */     if (cmp == -1) {
/*  88 */       bo = Result.contains(serch);
/*     */     } else {
/*  90 */       bo = serch.contains(Result);
/*     */     } 
/*  92 */     return bo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String stringSe(String nameTable, String[] nameColomon, String... textString) {
/* 104 */     String Sersh = "";
/* 105 */     int in = 0;
/* 106 */     for (String textF : textString) {
/* 107 */       if (!textF.trim().isEmpty() && 
/* 108 */         !textF.trim().equals("الجميع")) {
/* 109 */         Sersh = Sersh + LikeString(textF, nameColomon[in]) + "AND ";
/*     */       }
/*     */       
/* 112 */       in++;
/*     */     } 
/* 114 */     in = 0;
/*     */     
/* 116 */     if (Sersh.length() > 4) {
/* 117 */       Sersh = "SELECT * FROM " + nameTable.trim() + " WHERE " + Sersh.substring(0, Sersh.length() - 4) + ";";
/*     */     }
/*     */     
/* 120 */     return Sersh;
/*     */   }
/*     */ }


/* Location:              C:\Program Files (x86)\Ahl_Albthl\Ahl_Albthl_3.jar!\JointInfo\Searching.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */